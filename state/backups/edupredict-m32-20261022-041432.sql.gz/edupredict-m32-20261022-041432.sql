/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: edupredict
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `account_deletion_requests`
--

DROP TABLE IF EXISTS `account_deletion_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_deletion_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `processed_by` bigint(20) unsigned DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_deletion_requests_processed_by_foreign` (`processed_by`),
  KEY `account_deletion_requests_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `account_deletion_requests_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `account_deletion_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_deletion_requests`
--

LOCK TABLES `account_deletion_requests` WRITE;
/*!40000 ALTER TABLE `account_deletion_requests` DISABLE KEYS */;
INSERT INTO `account_deletion_requests` VALUES
(1,7,NULL,'rejected',1,'2026-10-10 12:49:36',NULL,'2026-10-09 23:15:04','2026-10-10 12:49:36');
/*!40000 ALTER TABLE `account_deletion_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `audit_logs_action_index` (`action`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-06 13:30:38'),
(2,5,'prediction_requested','App\\Models\\Prediction',61,'{\"student_id\":1,\"model_version\":\"placeholder-heuristic-v0\",\"dropout_risk\":\"moderate\"}','172.18.0.1','2026-10-06 13:45:25'),
(3,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-06 14:23:35'),
(4,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-06 15:04:14'),
(5,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-06 17:21:25'),
(6,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-06 20:36:15'),
(7,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-06 20:57:36'),
(8,1,'questionnaire_item_saved','App\\Models\\QuestionnaireItem',21,'{\"construct\":\"study_habits\",\"is_active\":true}','172.18.0.1','2026-10-06 20:59:17'),
(9,1,'questionnaire_item_saved','App\\Models\\QuestionnaireItem',21,'{\"construct\":\"study_habits\",\"is_active\":true}','172.18.0.1','2026-10-06 21:00:00'),
(10,4,'login','App\\Models\\User',4,'[]','172.18.0.1','2026-10-06 21:06:35'),
(11,4,'login','App\\Models\\User',4,'[]','172.18.0.1','2026-10-08 19:26:52'),
(12,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-08 19:27:44'),
(13,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-08 19:28:05'),
(14,5,'prediction_requested','App\\Models\\Prediction',62,'{\"student_id\":1,\"model_version\":\"placeholder-heuristic-v0\",\"dropout_risk\":\"moderate\"}','172.18.0.1','2026-10-08 19:28:10'),
(15,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-08 20:12:21'),
(16,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-08 20:13:33'),
(17,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-08 20:17:00'),
(18,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-08 20:47:52'),
(19,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-08 22:03:55'),
(20,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-08 22:07:49'),
(21,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-09 01:58:37'),
(22,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 01:58:38'),
(23,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 01:58:38'),
(24,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 01:58:39'),
(25,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 02:16:15'),
(26,3,'student_record_viewed','App\\Models\\Student',12,'{\"role\":\"department_head\"}','172.18.0.1','2026-10-09 02:18:07'),
(27,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-09 02:19:11'),
(28,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 02:19:23'),
(29,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 03:20:49'),
(30,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 03:45:18'),
(31,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-09 03:56:08'),
(32,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 04:31:11'),
(33,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-09 05:07:41'),
(34,7,'prediction_requested','App\\Models\\Prediction',63,'{\"student_id\":2,\"model_version\":\"placeholder-heuristic-v0\",\"dropout_risk\":\"moderate\"}','172.18.0.1','2026-10-09 05:14:55'),
(35,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-09 05:17:54'),
(36,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 05:18:10'),
(37,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 05:33:54'),
(38,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 13:19:37'),
(39,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 13:24:56'),
(40,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 13:28:17'),
(41,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 13:29:04'),
(42,3,'student_record_viewed','App\\Models\\Student',1,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:29:48'),
(43,3,'student_record_viewed','App\\Models\\Student',30,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:32:25'),
(44,3,'student_record_viewed','App\\Models\\Student',3,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:32:29'),
(45,3,'student_record_viewed','App\\Models\\Student',21,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:32:47'),
(46,3,'student_record_viewed','App\\Models\\Student',1,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:33:06'),
(47,3,'student_record_viewed','App\\Models\\Student',30,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 13:33:13'),
(48,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 14:16:54'),
(49,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 14:17:16'),
(50,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-09 14:36:44'),
(51,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-09 14:38:07'),
(52,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-09 14:38:22'),
(53,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-09 14:38:33'),
(54,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-09 14:38:42'),
(55,3,'student_record_viewed','App\\Models\\Student',1,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-09 14:38:48'),
(56,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 14:39:17'),
(57,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 14:43:59'),
(58,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 14:44:05'),
(59,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 14:51:55'),
(60,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 14:53:33'),
(61,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 23:07:12'),
(62,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-09 23:13:23'),
(63,7,'account_deletion_requested','App\\Models\\AccountDeletionRequest',1,'[]','172.18.0.1','2026-10-09 23:15:04'),
(64,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-09 23:15:21'),
(65,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-09 23:41:13'),
(66,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 00:54:23'),
(67,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 11:12:24'),
(68,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 11:12:36'),
(69,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-10 11:15:48'),
(70,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 12:22:49'),
(71,1,'account_deletion_processed','App\\Models\\AccountDeletionRequest',1,'{\"decision\":\"rejected\",\"account_user_id\":7}','172.18.0.1','2026-10-10 12:49:36'),
(72,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 13:22:58'),
(73,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 13:57:21'),
(74,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 14:43:04'),
(75,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 14:44:45'),
(76,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 14:56:12'),
(77,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 14:56:31'),
(78,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 15:09:43'),
(79,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 15:57:22'),
(80,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 17:28:27'),
(81,1,'account_created','App\\Models\\User',67,'{\"role\":\"department_head\"}','172.18.0.1','2026-10-10 17:30:58'),
(82,1,'account_deactivated','App\\Models\\User',67,'[]','172.18.0.1','2026-10-10 17:31:16'),
(83,1,'account_activated','App\\Models\\User',67,'[]','172.18.0.1','2026-10-10 17:31:58'),
(84,1,'account_created','App\\Models\\User',68,'{\"role\":\"dean\"}','172.18.0.1','2026-10-10 17:32:30'),
(85,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-10 17:33:13'),
(86,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 17:33:23'),
(87,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-10 17:59:46'),
(88,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-10 18:01:37'),
(89,1,'account_deactivated','App\\Models\\User',4,'[]','172.18.0.1','2026-10-10 18:01:51'),
(90,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-11 23:26:07'),
(91,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-11 23:45:09'),
(92,8,'login','App\\Models\\User',8,'[]','172.18.0.1','2026-10-11 23:46:53'),
(93,7,'login','App\\Models\\User',7,'[]','172.18.0.1','2026-10-19 15:49:03'),
(94,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-19 16:06:27'),
(95,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-20 14:25:22'),
(96,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-20 14:36:25'),
(97,3,'student_record_viewed','App\\Models\\Student',1,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-20 14:40:10'),
(98,3,'student_record_viewed','App\\Models\\Student',30,'{\"role\":\"department_head\",\"surface\":\"department_students_modal\"}','172.18.0.1','2026-10-20 14:42:05'),
(99,2,'login','App\\Models\\User',2,'[]','172.18.0.1','2026-10-20 14:46:36'),
(100,3,'login','App\\Models\\User',3,'[]','172.18.0.1','2026-10-20 14:47:17'),
(101,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-20 14:50:41'),
(102,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-20 15:46:33'),
(103,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 00:12:29'),
(104,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 00:22:06'),
(105,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 00:27:29'),
(106,1,'account_deactivated','App\\Models\\User',10,'[]','172.18.0.1','2026-10-22 00:31:33'),
(107,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 01:45:22'),
(113,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 02:10:20'),
(114,1,'eligible_student_saved','App\\Models\\InstitutionStudent',65,'{\"student_number\":\"20230570\",\"mode\":\"create\"}','172.18.0.1','2026-10-22 02:13:05'),
(115,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 02:14:01'),
(116,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:15:58'),
(117,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:16:27'),
(118,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:16:32'),
(119,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:16:37'),
(120,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:16:42'),
(121,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:17:38'),
(122,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\"}','172.18.0.1','2026-10-22 02:17:42'),
(123,69,'student_registered','App\\Models\\User',69,'{\"student_number\":\"20230570\"}','172.18.0.1','2026-10-22 02:23:31'),
(124,5,'login','App\\Models\\User',5,'[]','172.18.0.1','2026-10-22 02:54:13'),
(125,9,'login','App\\Models\\User',9,'[]','172.18.0.1','2026-10-22 02:55:42'),
(126,1,'login','App\\Models\\User',1,'[]','172.18.0.1','2026-10-22 03:08:34'),
(127,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\",\"is_active\":false}','172.18.0.1','2026-10-22 03:08:51'),
(128,1,'intervention_saved','App\\Models\\Intervention',1,'{\"code\":\"academic_tutoring\",\"is_active\":true}','172.18.0.1','2026-10-22 03:09:31'),
(129,69,'login','App\\Models\\User',69,'[]','172.18.0.1','2026-10-22 03:15:42');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('edupredict-cache-356a192b7913b04c54574d18c28d46e6395428ab','i:2;',1792605544),
('edupredict-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer','i:1792605544;',1792605544),
('edupredict-cache-a72b20062ec2c47ab2ceb97ac1bee818f8b6c6cb','i:1;',1792612614),
('edupredict-cache-a72b20062ec2c47ab2ceb97ac1bee818f8b6c6cb:timer','i:1792612614;',1792612614),
('edupredict-cache-ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4','i:1;',1791528903),
('edupredict-cache-ac3478d69a3c81fa62e60f5c3696165a4e5e6ac4:timer','i:1791528903;',1791528903),
('edupredict-cache-action_phrasing:648a2fc6214aaf344a30bfec6079e19e9c3973d637cbea65c78327a82d5b8f54','s:721:\"{\"actions\":[{\"code\":\"study_skills_workshop\",\"text\":\"Invite the student to a study‑skills workshop, with the adviser deciding if it fits.\"},{\"code\":\"scholarship_advising\",\"text\":\"Provide the student with advising on existing campus scholarship options as a referral, not an award.\"},{\"code\":\"guidance_counselling\",\"text\":\"Refer the student to the guidance office for a supportive conversation, without clinical assessment.\"},{\"code\":\"time_management_coaching\",\"text\":\"Offer brief time‑management coaching to help the student plan study time as a supportive option.\"},{\"code\":\"adviser_check_in\",\"text\":\"Schedule a check‑in with the assigned adviser to discuss the term’s progress, without automated follow‑up.\"}]}\";',1794086126),
('edupredict-cache-action_phrasing:ec7feba5dfc4bd0a8911c75249fda5e9ef87566ad02f7369e16938e42094bf1a','s:1092:\"{\"actions\":[{\"code\":\"academic_tutoring\",\"text\":\"You may suggest scheduled subject tutoring to support their learning in specific classes. This conversation is a supportive option to explore together, rather than a formal academic decision.\"},{\"code\":\"study_skills_workshop\",\"text\":\"You can invite the student to attend a study-skills workshop focused on building effective learning habits. Please consider whether this invitation aligns well with their current needs.\"},{\"code\":\"adviser_check_in\",\"text\":\"Scheduling a check-in offers a chance to discuss how the term is progressing in a supportive space. This conversation does not trigger any automated administrative actions.\"},{\"code\":\"engagement_reconnect\",\"text\":\"You might encourage reconnecting with a class routine, peer group, or a supportive conversation. This invitation is meant to foster connection without pressure.\"},{\"code\":\"guidance_counselling\",\"text\":\"You can offer a referral to the guidance office for a supportive conversation. This referral connects them to resources and is not a clinical or diagnostic assessment.\"}]}\";',1794050937),
('edupredict-cache-ai_daily_calls:2026-10-08','i:1;',1791475200),
('edupredict-cache-ai_daily_calls:2026-10-09','i:1;',1791561600),
('edupredict-cache-ai_daily_calls:2026-10-11','i:0;',1791734400),
('edupredict-cache-ai_minute:2026-10-08-19-28','i:2;',1791458950),
('edupredict-cache-ai_minute:2026-10-08-19-28:timer','i:1791458950;',1791458950),
('edupredict-cache-ai_minute:2026-10-09-05-14','i:1;',1791494155),
('edupredict-cache-ai_minute:2026-10-09-05-14:timer','i:1791494155;',1791494155),
('edupredict-cache-ai_minute:2026-10-09-05-15','i:1;',1791494179),
('edupredict-cache-ai_minute:2026-10-09-05-15:timer','i:1791494179;',1791494179),
('edupredict-cache-ai_minute:2026-10-11-23-46','i:1;',1791733673),
('edupredict-cache-ai_minute:2026-10-11-23-46:timer','i:1791733673;',1791733673),
('edupredict-cache-career_explanation:2787d5c81c4322b6148cfb1eedf15d49b058b26682a8c0f1059478db093ed057','s:1538:\"{ \"explanations\": [ { \"psoc_code\": \"2521\", \"text\": \"The BSCS graduate with a GWA of 1.75 or better shows strong SQL knowledge, aligning well with database design and administration tasks. However, the missing database skill suggests additional training in database concepts may be needed. The high compatibility score indicates a good fit overall.\" }, { \"psoc_code\": \"2512\", \"text\": \"The candidate\'s SQL proficiency matches part of the software developer role, but gaps in algorithms and programming lower the fit. The 73% compatibility reflects moderate alignment. Further development in programming fundamentals would improve suitability.\" }, { \"psoc_code\": \"2511\", \"text\": \"No matched skills were identified for the systems analyst position, and key competencies such as analysis, programming, and requirements gathering are missing. The 60% compatibility score indicates a limited match. Additional coursework or experience in these areas would be required.\" }, { \"psoc_code\": \"2514\", \"text\": \"The applications programmer role requires debugging and programming skills, none of which were matched for this graduate. With a 60% compatibility score, the fit is modest. Building programming and debugging expertise would enhance eligibility.\" }, { \"psoc_code\": \"2519\", \"text\": \"The software and applications developers NEC role expects programming ability, which is not present in the matched skills list. The 60% compatibility reflects a basic alignment. Acquiring programming proficiency would be essential for this career path.\" } ] }\";',1794086119),
('edupredict-cache-career_explanation:404c8d863247d80ef1e7ef52e9ec7713cf0eb67a395de6e409bfc3dc0e8b3642','s:1413:\"{\n  \"explanations\": [\n    {\n      \"psoc_code\": \"2521\",\n      \"text\": \"The position requires strong SQL abilities, which the candidate has demonstrated through their matched skill set. Yet, the profile shows a missing skill in database management, suggesting room for further development.\"\n    },\n    {\n      \"psoc_code\": \"3514\",\n      \"text\": \"This career focuses on web-related tasks, and the candidate’s HTML proficiency directly supports those requirements. The absence of broader web skills indicates a potential area for growth.\"\n    },\n    {\n      \"psoc_code\": \"2512\",\n      \"text\": \"SQL knowledge provides a foundation for software development roles, aligning with one of the required competencies. However, gaps in algorithmic thinking and programming indicate additional learning is needed.\"\n    },\n    {\n      \"psoc_code\": \"2513\",\n      \"text\": \"The role emphasizes both web and multimedia creation, and the candidate’s HTML background satisfies the core requirement. Lacking programming and full‑stack web capabilities may limit suitability for this position.\"\n    },\n    {\n      \"psoc_code\": \"1330\",\n      \"text\": \"This management-oriented role calls for leadership and technical oversight, yet the candidate currently lacks relevant skills in both areas. Consequently, while the position does not align strongly with existing qualifications, targeted training could bridge the gap.\"\n    }\n  ]\n}\";',1794325626),
('edupredict-cache-career_explanation:f506b508a9c5b7252655e146c6bbcb37449e8bc9210075d976105a6273476222','s:1346:\"{\"explanations\":[{\"psoc_code\":\"1330\",\"text\":\"This career match shows a 57 compatibility score for the BSIS program with a GWA band of 1.76-2.25. Currently, there are no matched skills listed, while the profile is missing the management and programming skills needed for ICT Service Managers.\"},{\"psoc_code\":\"2166\",\"text\":\"The Graphic and Multimedia Designers role has a compatibility score of 57 for the BSIS program with a GWA band of 1.76-2.25. The assessment reports no matched skills, and it identifies design and multimedia as missing skills.\"},{\"psoc_code\":\"2511\",\"text\":\"Systems Analysts is a potential match with a compatibility score of 57 based on the BSIS program and GWA band of 1.76-2.25. There are no currently matched skills, and analysis, programming, and requirements are flagged as missing skills.\"},{\"psoc_code\":\"2512\",\"text\":\"With a compatibility score of 57, the BSIS program with a GWA band of 1.76-2.25 is assessed for Software Developers. The data shows no matched skills, and algorithms, programming, and sql are listed as missing skills.\"},{\"psoc_code\":\"2513\",\"text\":\"Web and Multimedia Developers is indicated as a match with a compatibility score of 57 for the BSIS program and GWA band of 1.76-2.25. No skills are currently matched, and the assessment specifies that html, programming, and web skills are missing.\"}]}\";',1794050910),
('edupredict-cache-faculty@edupredict.test|172.18.0.1','i:1;',1791558840),
('edupredict-cache-faculty@edupredict.test|172.18.0.1:timer','i:1791558840;',1791558840),
('edupredict-cache-student@edupredict.test|172.18.0.1','i:1;',1791488548),
('edupredict-cache-student@edupredict.test|172.18.0.1:timer','i:1791488548;',1791488548),
('edupredict-cache-syn-0001m|172.18.0.1','i:1;',1792396171),
('edupredict-cache-syn-0001m|172.18.0.1:timer','i:1792396171;',1792396171);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `career_matches`
--

DROP TABLE IF EXISTS `career_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `career_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prediction_id` bigint(20) unsigned NOT NULL,
  `psoc_occupation_id` bigint(20) unsigned NOT NULL,
  `compatibility_score` decimal(5,2) NOT NULL,
  `explanation` text NOT NULL,
  `explanation_source` varchar(16) NOT NULL,
  `matched_skills` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`matched_skills`)),
  `missing_skills` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`missing_skills`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `career_matches_prediction_id_psoc_occupation_id_unique` (`prediction_id`,`psoc_occupation_id`),
  KEY `career_matches_psoc_occupation_id_foreign` (`psoc_occupation_id`),
  KEY `career_matches_prediction_id_compatibility_score_index` (`prediction_id`,`compatibility_score`),
  CONSTRAINT `career_matches_prediction_id_foreign` FOREIGN KEY (`prediction_id`) REFERENCES `predictions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `career_matches_psoc_occupation_id_foreign` FOREIGN KEY (`psoc_occupation_id`) REFERENCES `psoc_occupations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career_matches`
--

LOCK TABLES `career_matches` WRITE;
/*!40000 ALTER TABLE `career_matches` DISABLE KEYS */;
INSERT INTO `career_matches` VALUES
(1,61,12,57.00,'ICT Service Managers (PSOC 1330) is a broad occupational category, not a job offer. The BSIS program and a compatibility score of 57 out of 100 are the basis of this match. The program link is the main overlap in this estimate. Skill tags not yet on the profile: management, programming.','template','[]','[\"management\",\"programming\"]','2026-10-06 13:45:57','2026-10-06 13:45:57'),
(2,61,43,57.00,'Graphic and Multimedia Designers (PSOC 2166) is a broad occupational category, not a job offer. The BSIS program and a compatibility score of 57 out of 100 are the basis of this match. The program link is the main overlap in this estimate. Skill tags not yet on the profile: design, multimedia.','template','[]','[\"design\",\"multimedia\"]','2026-10-06 13:45:57','2026-10-06 13:45:57'),
(3,61,1,57.00,'Systems Analysts (PSOC 2511) is a broad occupational category, not a job offer. The BSIS program and a compatibility score of 57 out of 100 are the basis of this match. The program link is the main overlap in this estimate. Skill tags not yet on the profile: analysis, programming, requirements.','template','[]','[\"analysis\",\"programming\",\"requirements\"]','2026-10-06 13:45:57','2026-10-06 13:45:57'),
(4,61,2,57.00,'Software Developers (PSOC 2512) is a broad occupational category, not a job offer. The BSIS program and a compatibility score of 57 out of 100 are the basis of this match. The program link is the main overlap in this estimate. Skill tags not yet on the profile: algorithms, programming, sql.','template','[]','[\"algorithms\",\"programming\",\"sql\"]','2026-10-06 13:45:57','2026-10-06 13:45:57'),
(5,61,3,57.00,'Web and Multimedia Developers (PSOC 2513) is a broad occupational category, not a job offer. The BSIS program and a compatibility score of 57 out of 100 are the basis of this match. The program link is the main overlap in this estimate. Skill tags not yet on the profile: html, programming, web.','template','[]','[\"html\",\"programming\",\"web\"]','2026-10-06 13:45:57','2026-10-06 13:45:57'),
(6,62,12,57.00,'This career match shows a 57 compatibility score for the BSIS program with a GWA band of 1.76-2.25. Currently, there are no matched skills listed, while the profile is missing the management and programming skills needed for ICT Service Managers.','ai','[]','[\"management\",\"programming\"]','2026-10-08 19:28:30','2026-10-08 19:28:30'),
(7,62,43,57.00,'The Graphic and Multimedia Designers role has a compatibility score of 57 for the BSIS program with a GWA band of 1.76-2.25. The assessment reports no matched skills, and it identifies design and multimedia as missing skills.','ai','[]','[\"design\",\"multimedia\"]','2026-10-08 19:28:30','2026-10-08 19:28:30'),
(8,62,1,57.00,'Systems Analysts is a potential match with a compatibility score of 57 based on the BSIS program and GWA band of 1.76-2.25. There are no currently matched skills, and analysis, programming, and requirements are flagged as missing skills.','ai','[]','[\"analysis\",\"programming\",\"requirements\"]','2026-10-08 19:28:30','2026-10-08 19:28:30'),
(9,62,2,57.00,'With a compatibility score of 57, the BSIS program with a GWA band of 1.76-2.25 is assessed for Software Developers. The data shows no matched skills, and algorithms, programming, and sql are listed as missing skills.','ai','[]','[\"algorithms\",\"programming\",\"sql\"]','2026-10-08 19:28:30','2026-10-08 19:28:30'),
(10,62,3,57.00,'Web and Multimedia Developers is indicated as a match with a compatibility score of 57 for the BSIS program and GWA band of 1.76-2.25. No skills are currently matched, and the assessment specifies that html, programming, and web skills are missing.','ai','[]','[\"html\",\"programming\",\"web\"]','2026-10-08 19:28:30','2026-10-08 19:28:30'),
(11,63,6,80.00,'The BSCS graduate with a GWA of 1.75 or better shows strong SQL knowledge, aligning well with database design and administration tasks. However, the missing database skill suggests additional training in database concepts may be needed. The high compatibility score indicates a good fit overall.','ai','[\"sql\"]','[\"database\"]','2026-10-09 05:15:19','2026-10-09 05:15:19'),
(12,63,2,73.00,'The candidate\'s SQL proficiency matches part of the software developer role, but gaps in algorithms and programming lower the fit. The 73% compatibility reflects moderate alignment. Further development in programming fundamentals would improve suitability.','ai','[\"sql\"]','[\"algorithms\",\"programming\"]','2026-10-09 05:15:19','2026-10-09 05:15:19'),
(13,63,1,60.00,'No matched skills were identified for the systems analyst position, and key competencies such as analysis, programming, and requirements gathering are missing. The 60% compatibility score indicates a limited match. Additional coursework or experience in these areas would be required.','ai','[]','[\"analysis\",\"programming\",\"requirements\"]','2026-10-09 05:15:19','2026-10-09 05:15:19'),
(14,63,4,60.00,'The applications programmer role requires debugging and programming skills, none of which were matched for this graduate. With a 60% compatibility score, the fit is modest. Building programming and debugging expertise would enhance eligibility.','ai','[]','[\"debugging\",\"programming\"]','2026-10-09 05:15:19','2026-10-09 05:15:19'),
(15,63,5,60.00,'The software and applications developers NEC role expects programming ability, which is not present in the matched skills list. The 60% compatibility reflects a basic alignment. Acquiring programming proficiency would be essential for this career path.','ai','[]','[\"programming\"]','2026-10-09 05:15:19','2026-10-09 05:15:19'),
(16,2,6,70.00,'The position requires strong SQL abilities, which the candidate has demonstrated through their matched skill set. Yet, the profile shows a missing skill in database management, suggesting room for further development.','ai','[\"sql\"]','[\"database\"]','2026-10-11 23:47:06','2026-10-11 23:47:06'),
(17,2,11,70.00,'This career focuses on web-related tasks, and the candidate’s HTML proficiency directly supports those requirements. The absence of broader web skills indicates a potential area for growth.','ai','[\"html\"]','[\"web\"]','2026-10-11 23:47:06','2026-10-11 23:47:06'),
(18,2,2,63.00,'SQL knowledge provides a foundation for software development roles, aligning with one of the required competencies. However, gaps in algorithmic thinking and programming indicate additional learning is needed.','ai','[\"sql\"]','[\"algorithms\",\"programming\"]','2026-10-11 23:47:06','2026-10-11 23:47:06'),
(19,2,3,63.00,'The role emphasizes both web and multimedia creation, and the candidate’s HTML background satisfies the core requirement. Lacking programming and full‑stack web capabilities may limit suitability for this position.','ai','[\"html\"]','[\"programming\",\"web\"]','2026-10-11 23:47:06','2026-10-11 23:47:06'),
(20,2,12,50.00,'This management-oriented role calls for leadership and technical oversight, yet the candidate currently lacks relevant skills in both areas. Consequently, while the position does not align strongly with existing qualifications, targeted training could bridge the gap.','ai','[]','[\"management\",\"programming\"]','2026-10-11 23:47:06','2026-10-11 23:47:06');
/*!40000 ALTER TABLE `career_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colleges`
--

DROP TABLE IF EXISTS `colleges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `colleges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `colleges_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colleges`
--

LOCK TABLES `colleges` WRITE;
/*!40000 ALTER TABLE `colleges` DISABLE KEYS */;
INSERT INTO `colleges` VALUES
(1,'College of Computer Studies','CCS',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(2,'College of Business Administration','CBA',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(3,'College of Education','CED',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(4,'College of Engineering','COE',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(5,'College of Liberal Arts and Sciences','CLAS',1,'2026-10-06 06:53:24','2026-10-09 01:58:15');
/*!40000 ALTER TABLE `colleges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consents`
--

DROP TABLE IF EXISTS `consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `version` varchar(32) NOT NULL,
  `accepted_at` timestamp NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consents_user_id_version_index` (`user_id`,`version`),
  CONSTRAINT `consents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consents`
--

LOCK TABLES `consents` WRITE;
/*!40000 ALTER TABLE `consents` DISABLE KEYS */;
INSERT INTO `consents` VALUES
(1,1,'v1','2026-10-06 06:53:26','127.0.0.1','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(2,2,'v1','2026-10-06 06:53:26','127.0.0.1','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(3,3,'v1','2026-10-06 06:53:26','127.0.0.1','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(4,4,'v1','2026-10-06 06:53:26','127.0.0.1','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(5,5,'v1','2026-10-06 06:53:26','127.0.0.1','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(6,69,'v2','2026-10-22 02:23:31','172.18.0.1','2026-10-22 02:23:31','2026-10-22 02:23:31');
/*!40000 ALTER TABLE `consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `college_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_code_unique` (`code`),
  KEY `departments_college_id_index` (`college_id`),
  CONSTRAINT `departments_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES
(1,5,'Communication','CLAS-COMM',1,'2026-10-09 01:58:15','2026-10-22 02:05:58'),
(2,5,'Public Administration','CLAS-PA',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(3,5,'Computer Studies','CLAS-CS',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(4,5,'Mathematics','CLAS-MATH',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(5,5,'Psychology','CLAS-PSY',1,'2026-10-09 01:58:15','2026-10-09 01:58:15');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_reports`
--

DROP TABLE IF EXISTS `grade_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `school_year` varchar(16) NOT NULL,
  `semester` varchar(32) NOT NULL,
  `source` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT 1,
  `supersedes_id` bigint(20) unsigned DEFAULT NULL,
  `original_file_path` varchar(255) DEFAULT NULL,
  `detected_gpa` decimal(8,4) DEFAULT NULL,
  `warnings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`warnings`)),
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `superseded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grade_reports_student_id_school_year_semester_index` (`student_id`,`school_year`,`semester`),
  KEY `grade_reports_status_index` (`status`),
  KEY `grade_reports_supersedes_id_foreign` (`supersedes_id`),
  KEY `grade_reports_student_id_status_superseded_at_index` (`student_id`,`status`,`superseded_at`),
  CONSTRAINT `grade_reports_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grade_reports_supersedes_id_foreign` FOREIGN KEY (`supersedes_id`) REFERENCES `grade_reports` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade_reports`
--

LOCK TABLES `grade_reports` WRITE;
/*!40000 ALTER TABLE `grade_reports` DISABLE KEYS */;
INSERT INTO `grade_reports` VALUES
(1,2,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:27',NULL,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(2,3,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:28',NULL,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(3,4,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:28',NULL,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(4,5,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:28',NULL,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(5,6,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:29',NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(6,7,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:29',NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(7,8,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:29',NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,9,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:30',NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(9,10,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:30',NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(10,11,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:30',NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,12,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:31',NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(12,13,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:31',NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(13,14,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:32',NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(14,15,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:32',NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(15,16,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:32',NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,17,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:33',NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(17,18,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:33',NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(18,19,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:33',NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(19,20,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:34',NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(20,21,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:34',NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(21,22,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:34',NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(22,23,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:35',NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(23,24,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:35',NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(24,25,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:36',NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(25,26,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:36',NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(26,27,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:36',NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(27,28,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:37',NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(28,29,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:37',NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(29,30,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:37',NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(30,31,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:38',NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(31,32,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:38',NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(32,33,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:39',NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(33,34,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:39',NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(34,35,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:39',NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(35,36,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:40',NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(36,37,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:40',NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(37,38,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:40',NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(38,39,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:41',NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(39,40,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:41',NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(40,41,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:41',NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(41,42,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:42',NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(42,43,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:42',NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(43,44,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:42',NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(44,45,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:43',NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(45,46,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:43',NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(46,47,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:43',NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(47,48,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:44',NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(48,49,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:44',NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(49,50,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:44',NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(50,51,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:45',NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(51,52,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:45',NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(52,53,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:46',NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(53,54,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:46',NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(54,55,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:46',NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(55,56,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:47',NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(56,57,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:47',NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(57,58,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:47',NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(58,59,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:48',NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(59,60,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:48',NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(60,61,'2024-2025','Second','manual','confirmed',1,NULL,NULL,NULL,NULL,'2026-10-06 06:53:48',NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(62,1,'2025-2026','First','pasted','confirmed',1,NULL,NULL,2.3300,'[]','2026-10-06 20:50:02',NULL,'2026-10-06 20:50:01','2026-10-06 20:50:02'),
(63,2,'2024-2025','First','pasted','confirmed',1,NULL,NULL,1.4000,'[\"Instructor and section columns were left out of 8 rows. Check that each subject name is complete.\"]','2026-10-09 05:13:08',NULL,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(64,62,'2024-2025','Second','pasted','confirmed',1,NULL,NULL,1.4400,'[\"Instructor and section columns were left out of 7 rows. Check that each subject name is complete.\"]','2026-10-22 03:57:54',NULL,'2026-10-22 03:57:54','2026-10-22 03:57:54');
/*!40000 ALTER TABLE `grade_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_students`
--

DROP TABLE IF EXISTS `institution_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `institution_students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_number` varchar(32) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `program_id` bigint(20) unsigned NOT NULL,
  `year_level` tinyint(3) unsigned NOT NULL,
  `birthdate` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_registered` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `institution_students_student_number_unique` (`student_number`),
  KEY `institution_students_last_name_first_name_index` (`last_name`,`first_name`),
  KEY `institution_students_program_id_index` (`program_id`),
  CONSTRAINT `institution_students_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_students`
--

LOCK TABLES `institution_students` WRITE;
/*!40000 ALTER TABLE `institution_students` DISABLE KEYS */;
INSERT INTO `institution_students` VALUES
(1,'2024-00001','Student','Sam',3,3,NULL,'student@edupredict.test',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(2,'2024-88888','Applicant','Una',3,1,NULL,'una.applicant@edupredict.test',0,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(3,'SYN-0001','Bautista','Mara',2,2,NULL,'synthetic1@edupredict.test',1,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(4,'SYN-0002','Reyes','Nico',3,3,NULL,'synthetic2@edupredict.test',1,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(5,'SYN-0003','Navarro','Bea',4,4,NULL,'synthetic3@edupredict.test',1,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(6,'SYN-0004','Lim','Carlo',5,1,NULL,'synthetic4@edupredict.test',1,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(7,'SYN-0005','Dela Cruz','Rico',6,2,NULL,'synthetic5@edupredict.test',1,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,'SYN-0006','Cruz','Paolo',7,3,NULL,'synthetic6@edupredict.test',1,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(9,'SYN-0007','Student','Synthetic7',8,4,NULL,'synthetic7@edupredict.test',1,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(10,'SYN-0008','Student','Synthetic8',9,1,NULL,'synthetic8@edupredict.test',1,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,'SYN-0009','Student','Synthetic9',1,2,NULL,'synthetic9@edupredict.test',1,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(12,'SYN-0010','Ramos','Liza',2,3,NULL,'synthetic10@edupredict.test',1,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(13,'SYN-0011','Student','Synthetic11',3,4,NULL,'synthetic11@edupredict.test',1,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(14,'SYN-0012','Student','Synthetic12',4,1,NULL,'synthetic12@edupredict.test',1,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(15,'SYN-0013','Student','Synthetic13',5,2,NULL,'synthetic13@edupredict.test',1,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,'SYN-0014','Student','Synthetic14',6,3,NULL,'synthetic14@edupredict.test',1,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(17,'SYN-0015','Student','Synthetic15',7,4,NULL,'synthetic15@edupredict.test',1,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(18,'SYN-0016','Student','Synthetic16',8,1,NULL,'synthetic16@edupredict.test',1,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(19,'SYN-0017','Student','Synthetic17',9,2,NULL,'synthetic17@edupredict.test',1,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(20,'SYN-0018','Student','Synthetic18',1,3,NULL,'synthetic18@edupredict.test',1,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(21,'SYN-0019','Student','Synthetic19',2,4,NULL,'synthetic19@edupredict.test',1,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(22,'SYN-0020','Student','Synthetic20',3,1,NULL,'synthetic20@edupredict.test',1,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(23,'SYN-0021','Student','Synthetic21',4,2,NULL,'synthetic21@edupredict.test',1,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(24,'SYN-0022','Student','Synthetic22',5,3,NULL,'synthetic22@edupredict.test',1,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(25,'SYN-0023','Student','Synthetic23',6,4,NULL,'synthetic23@edupredict.test',1,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(26,'SYN-0024','Student','Synthetic24',7,1,NULL,'synthetic24@edupredict.test',1,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(27,'SYN-0025','Student','Synthetic25',8,2,NULL,'synthetic25@edupredict.test',1,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(28,'SYN-0026','Student','Synthetic26',9,3,NULL,'synthetic26@edupredict.test',1,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(29,'SYN-0027','Student','Synthetic27',1,4,NULL,'synthetic27@edupredict.test',1,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(30,'SYN-0028','Student','Synthetic28',2,1,NULL,'synthetic28@edupredict.test',1,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(31,'SYN-0029','Student','Synthetic29',3,2,NULL,'synthetic29@edupredict.test',1,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(32,'SYN-0030','Student','Synthetic30',4,3,NULL,'synthetic30@edupredict.test',1,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(33,'SYN-0031','Student','Synthetic31',5,4,NULL,'synthetic31@edupredict.test',1,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(34,'SYN-0032','Student','Synthetic32',6,1,NULL,'synthetic32@edupredict.test',1,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(35,'SYN-0033','Student','Synthetic33',7,2,NULL,'synthetic33@edupredict.test',1,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(36,'SYN-0034','Student','Synthetic34',8,3,NULL,'synthetic34@edupredict.test',1,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(37,'SYN-0035','Student','Synthetic35',9,4,NULL,'synthetic35@edupredict.test',1,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(38,'SYN-0036','Student','Synthetic36',1,1,NULL,'synthetic36@edupredict.test',1,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(39,'SYN-0037','Student','Synthetic37',2,2,NULL,'synthetic37@edupredict.test',1,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(40,'SYN-0038','Student','Synthetic38',3,3,NULL,'synthetic38@edupredict.test',1,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(41,'SYN-0039','Student','Synthetic39',4,4,NULL,'synthetic39@edupredict.test',1,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(42,'SYN-0040','Student','Synthetic40',5,1,NULL,'synthetic40@edupredict.test',1,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(43,'SYN-0041','Student','Synthetic41',6,2,NULL,'synthetic41@edupredict.test',1,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(44,'SYN-0042','Student','Synthetic42',7,3,NULL,'synthetic42@edupredict.test',1,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(45,'SYN-0043','Student','Synthetic43',8,4,NULL,'synthetic43@edupredict.test',1,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(46,'SYN-0044','Student','Synthetic44',9,1,NULL,'synthetic44@edupredict.test',1,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(47,'SYN-0045','Student','Synthetic45',1,2,NULL,'synthetic45@edupredict.test',1,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(48,'SYN-0046','Student','Synthetic46',2,3,NULL,'synthetic46@edupredict.test',1,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(49,'SYN-0047','Student','Synthetic47',3,4,NULL,'synthetic47@edupredict.test',1,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(50,'SYN-0048','Student','Synthetic48',4,1,NULL,'synthetic48@edupredict.test',1,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(51,'SYN-0049','Student','Synthetic49',5,2,NULL,'synthetic49@edupredict.test',1,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(52,'SYN-0050','Student','Synthetic50',6,3,NULL,'synthetic50@edupredict.test',1,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(53,'SYN-0051','Student','Synthetic51',7,4,NULL,'synthetic51@edupredict.test',1,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(54,'SYN-0052','Student','Synthetic52',8,1,NULL,'synthetic52@edupredict.test',1,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(55,'SYN-0053','Student','Synthetic53',9,2,NULL,'synthetic53@edupredict.test',1,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(56,'SYN-0054','Student','Synthetic54',1,3,NULL,'synthetic54@edupredict.test',1,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(57,'SYN-0055','Student','Synthetic55',2,4,NULL,'synthetic55@edupredict.test',1,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(58,'SYN-0056','Student','Synthetic56',3,1,NULL,'synthetic56@edupredict.test',1,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(59,'SYN-0057','Student','Synthetic57',4,2,NULL,'synthetic57@edupredict.test',1,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(60,'SYN-0058','Student','Synthetic58',5,3,NULL,'synthetic58@edupredict.test',1,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(61,'SYN-0059','Student','Synthetic59',6,4,NULL,'synthetic59@edupredict.test',1,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(62,'SYN-0060','Student','Synthetic60',7,1,NULL,'synthetic60@edupredict.test',1,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(65,'20230570','Calma','Keith Andrea',3,4,'2005-05-28','keithandrea258@gmail.com',1,'2026-10-22 02:13:05','2026-10-22 02:23:31');
/*!40000 ALTER TABLE `institution_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interventions`
--

DROP TABLE IF EXISTS `interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `interventions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `targets_factor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`targets_factor`)),
  `min_risk_level` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `interventions_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interventions`
--

LOCK TABLES `interventions` WRITE;
/*!40000 ALTER TABLE `interventions` DISABLE KEYS */;
INSERT INTO `interventions` VALUES
(1,'academic_tutoring','Academic tutoring','A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','[\"gwa\",\"failed_subjects\"]','moderate',1,'2026-10-06 06:53:26','2026-10-22 03:09:31'),
(2,'peer_mentoring','Peer mentoring','A peer mentor can meet with the student about staying connected to the program. An adviser decides whether to offer the referral.','[\"engagement\",\"motivation\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(3,'financial_aid_referral','Financial-aid referral','The student can be pointed to the campus financial-aid office to ask about aid options. Staff do not see household income in this suggestion.','[\"income_bracket\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(4,'scholarship_advising','Scholarship advising','An adviser can help the student look at scholarship options the campus already offers. This is a referral, not an award.','[\"scholarship\",\"income_bracket\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(5,'guidance_counselling','Guidance counselling referral','A faculty adviser can offer a referral to the guidance office for a supportive conversation. This is not a clinical or diagnostic assessment.','[\"motivation\",\"engagement\",\"procrastination\",\"general\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(6,'study_skills_workshop','Study-skills workshop','The student can be invited to a study-skills workshop. An adviser decides whether the invitation fits.','[\"study_habits\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(7,'time_management_coaching','Time-management coaching','Short coaching on planning study time can be offered. It is a support option, not a judgment of the student.','[\"time_management\",\"procrastination\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(8,'ojt_placement','OJT and internship placement support','The department can help the student look for an OJT or internship placement. This is not a job offer.','[\"internships\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(9,'career_guidance','Career-guidance session','A career-guidance session can walk through broad occupational directions. It does not promise employment.','[\"certifications\",\"technical_skills\",\"projects\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(10,'adviser_check_in','Adviser check-in','The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','[\"engagement\",\"motivation\",\"disengagement\",\"general\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(11,'program_fit_conversation','Program-fit conversation','An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','[\"program_fit\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(12,'attendance_monitoring','Attendance monitoring','The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','[\"engagement\",\"disengagement\"]','high',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(13,'device_access_support','Learning-device access support','The student can be told how to ask about a shared learning device on campus. This suggestion does not include device ownership details.','[\"device_access\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(14,'internet_access_support','Internet access support','The student can be pointed to campus places with a reliable connection. An adviser decides whether to mention it.','[\"internet_access\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(15,'study_space_referral','Study-space referral','The student can be invited to use a campus study space. This is a practical option, not a finding about the household.','[\"study_space\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(16,'workload_review','Workload review','An adviser can talk with the student about balancing work hours and the current subject load. It does not change enrollment by itself.','[\"employment_status\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(17,'skills_coaching','Skills coaching','Coaching can focus on a skill or certification the profile does not show yet. It is practice support, not an employability guarantee.','[\"technical_skills\",\"certifications\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(18,'engagement_reconnect','Campus engagement reconnect','The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','[\"engagement\",\"disengagement\"]','moderate',1,'2026-10-06 06:53:26','2026-10-06 06:53:26');
/*!40000 ALTER TABLE `interventions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_10_05_100000_create_colleges_table',1),
(5,'2026_10_05_100001_create_programs_table',1),
(6,'2026_10_05_100002_add_role_fields_to_users_table',1),
(7,'2026_10_05_100003_create_institution_students_table',1),
(8,'2026_10_05_100004_create_students_table',1),
(9,'2026_10_05_100005_create_grade_reports_table',1),
(10,'2026_10_05_100006_create_subject_grades_table',1),
(11,'2026_10_05_100007_create_socioeconomic_profiles_table',1),
(12,'2026_10_05_100008_create_skills_experiences_table',1),
(13,'2026_10_05_100009_create_predictions_table',1),
(14,'2026_10_05_100010_create_consents_table',1),
(15,'2026_10_05_100011_create_audit_logs_table',1),
(16,'2026_10_05_100012_add_extraction_fields_to_grade_reports_table',1),
(17,'2026_10_05_100013_create_questionnaire_tables',1),
(18,'2026_10_06_100014_create_notifications_table',1),
(19,'2026_10_06_100015_create_career_tables',1),
(20,'2026_10_06_100016_create_intervention_tables',1),
(21,'2026_10_06_100017_create_account_deletion_requests_table',1),
(22,'2026_10_09_100018_add_departments_and_clas_pilot_scope',2),
(23,'2026_10_09_150000_version_questionnaire_definitions',3),
(24,'2026_10_09_160000_create_structured_skill_records',4),
(25,'2026_10_09_170000_add_grade_versions_and_incomplete_flag',5),
(26,'2026_10_22_100030_add_protected_value_to_questionnaire_answers',6),
(27,'2026_10_22_110031_add_is_active_to_interventions',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
('3753b790-c15d-4a7d-921f-e2a9c02d0da2','App\\Notifications\\AdviseePredictionReady','App\\Models\\User',4,'{\"prediction_id\":61,\"student_id\":1,\"title\":\"New advisee prediction\",\"message\":\"Sam Student requested a new prediction.\",\"url\":\"http:\\/\\/localhost:8000\\/students\\/1\"}',NULL,'2026-10-06 13:45:25','2026-10-06 13:45:25'),
('531d600c-7c89-42e5-b383-b94dd7e9ca01','App\\Notifications\\AdviseePredictionReady','App\\Models\\User',4,'{\"prediction_id\":62,\"student_id\":1,\"title\":\"New advisee prediction\",\"message\":\"Sam Student requested a new prediction.\",\"url\":\"http:\\/\\/localhost:8000\\/students\\/1\"}',NULL,'2026-10-08 19:28:10','2026-10-08 19:28:10');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `predictions`
--

DROP TABLE IF EXISTS `predictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `predictions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `model_version` varchar(64) NOT NULL,
  `employability_score` decimal(5,2) NOT NULL,
  `dropout_probability` decimal(6,4) NOT NULL,
  `dropout_risk` varchar(16) NOT NULL,
  `confidence` varchar(16) NOT NULL,
  `program_shift_flag` varchar(32) NOT NULL DEFAULT 'none',
  `factors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`factors`)),
  `feature_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`feature_snapshot`)),
  `assessment_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`assessment_snapshot`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `predictions_requested_by_foreign` (`requested_by`),
  KEY `predictions_student_id_created_at_index` (`student_id`,`created_at`),
  KEY `predictions_dropout_risk_index` (`dropout_risk`),
  CONSTRAINT `predictions_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  CONSTRAINT `predictions_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predictions`
--

LOCK TABLES `predictions` WRITE;
/*!40000 ALTER TABLE `predictions` DISABLE KEYS */;
INSERT INTO `predictions` VALUES
(1,2,7,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(2,3,8,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(3,4,9,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(4,5,10,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(5,6,11,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":2,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(6,7,12,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(7,8,13,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(8,9,14,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(9,10,15,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(10,11,16,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":3,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(11,12,17,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(12,13,18,'placeholder-heuristic-v0',81.00,0.1200,'low','low','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(13,14,19,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(14,15,20,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(15,16,21,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":4,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(16,17,22,'placeholder-heuristic-v0',62.00,0.4100,'moderate','low','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(17,18,23,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(18,19,24,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(19,20,25,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(20,21,26,'placeholder-heuristic-v0',48.00,0.7200,'high','low','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":1,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(21,22,27,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(22,23,28,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(23,24,29,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(24,25,30,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(25,26,31,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":2,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(26,27,32,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(27,28,33,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(28,29,34,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(29,30,35,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(30,31,36,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":3,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(31,32,37,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(32,33,38,'placeholder-heuristic-v0',81.00,0.1200,'low','low','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(33,34,39,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(34,35,40,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(35,36,41,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":4,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(36,37,42,'placeholder-heuristic-v0',62.00,0.4100,'moderate','low','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(37,38,43,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(38,39,44,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(39,40,45,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(40,41,46,'placeholder-heuristic-v0',48.00,0.7200,'high','low','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":1,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(41,42,47,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(42,43,48,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(43,44,49,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(44,45,50,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(45,46,51,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":2,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(46,47,52,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(47,48,53,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(48,49,54,'placeholder-heuristic-v0',81.00,0.1200,'low','low','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(49,50,55,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(50,51,56,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":3,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(51,52,57,'placeholder-heuristic-v0',62.00,0.4100,'moderate','normal','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(52,53,58,'placeholder-heuristic-v0',81.00,0.1200,'low','low','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(53,54,59,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(54,55,60,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(55,56,61,'placeholder-heuristic-v0',48.00,0.7200,'high','normal','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":4,\"synthetic\":true}',NULL,'2026-10-01 00:00:00'),
(56,57,62,'placeholder-heuristic-v0',62.00,0.4100,'moderate','low','program_fit','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":1,\"synthetic\":true}',NULL,'2026-06-01 00:00:00'),
(57,58,63,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','mixed','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":2,\"synthetic\":true}',NULL,'2026-02-01 00:00:00'),
(58,59,64,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":3,\"synthetic\":true}',NULL,'2025-10-01 00:00:00'),
(59,60,65,'placeholder-heuristic-v0',81.00,0.1200,'low','normal','none','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":0.25}]','{\"gwa_band\":\"1.75-2.00\",\"failed_subjects\":0,\"year_level\":4,\"synthetic\":true}',NULL,'2025-06-01 00:00:00'),
(60,61,66,'placeholder-heuristic-v0',48.00,0.7200,'high','low','disengagement','[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.35},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.25}]','{\"gwa_band\":\"2.75-3.00\",\"failed_subjects\":1,\"year_level\":1,\"synthetic\":true}',NULL,'2025-02-01 00:00:00'),
(61,1,5,'placeholder-heuristic-v0',56.70,0.5767,'moderate','low','disengagement','{\"employability\":[{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":8},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"+\",\"magnitude\":8},{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":7.7},{\"feature\":\"internships\",\"label\":\"Internships or OJT\",\"direction\":\"+\",\"magnitude\":6},{\"feature\":\"procrastination\",\"label\":\"Procrastination\",\"direction\":\"-\",\"magnitude\":6},{\"feature\":\"engagement\",\"label\":\"Engagement\",\"direction\":\"+\",\"magnitude\":3},{\"feature\":\"income_bracket\",\"label\":\"Household income band\",\"direction\":\"-\",\"magnitude\":3},{\"feature\":\"time_management\",\"label\":\"Time management\",\"direction\":\"-\",\"magnitude\":3},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":2},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":2},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"+\",\"magnitude\":2}],\"dropout\":[{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.12},{\"feature\":\"procrastination\",\"label\":\"Procrastination\",\"direction\":\"-\",\"magnitude\":0.105},{\"feature\":\"time_management\",\"label\":\"Time management\",\"direction\":\"-\",\"magnitude\":0.055},{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.0517},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"+\",\"magnitude\":0.05},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":0.05},{\"feature\":\"motivation\",\"label\":\"Motivation\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"income_bracket\",\"label\":\"Household income band\",\"direction\":\"-\",\"magnitude\":0.03},{\"feature\":\"internships\",\"label\":\"Internships or OJT\",\"direction\":\"+\",\"magnitude\":0.03},{\"feature\":\"engagement\",\"label\":\"Engagement\",\"direction\":\"-\",\"magnitude\":0.025},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":0.01},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"+\",\"magnitude\":0.01}],\"program_shift\":{\"flag\":\"disengagement\",\"label\":\"Broader disengagement\",\"message\":\"This pattern looks more like engagement, motivation, consistency, or performance across subjects than a program-fit concern. Those are areas where support could help.\",\"engagement\":\"Stable\",\"factors\":[{\"feature\":\"time_management\",\"label\":\"Time management\",\"note\":\"Consistency is an area where support could help\"}]}}','{\"gwa\":2.23,\"failed_subjects\":1,\"semesters_completed\":1,\"limited_history\":true,\"scholarship_status\":\"full\",\"has_scholarship\":true,\"employment_status\":\"unemployed\",\"income_bracket\":\"below_10k\",\"household_size\":6,\"living_arrangement\":\"boarding\",\"internet_access\":\"unreliable\",\"device_access\":\"yes\",\"study_space\":\"yes\",\"technical_skill_count\":0,\"certification_count\":0,\"internship_count\":1,\"project_count\":0,\"work_experience_count\":0,\"construct_scores\":{\"study_habits\":37.5,\"time_management\":31.25,\"motivation\":50,\"procrastination\":87.5,\"engagement\":68.75},\"major_gwa\":null,\"other_gwa\":2.23,\"major_failed_subjects\":0,\"other_failed_subjects\":1,\"major_units\":0,\"other_units\":21}',NULL,'2026-10-06 13:45:23'),
(62,1,5,'placeholder-heuristic-v0',56.00,0.5927,'moderate','low','disengagement','{\"employability\":[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":9},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":8},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"+\",\"magnitude\":8},{\"feature\":\"internships\",\"label\":\"Internships or OJT\",\"direction\":\"+\",\"magnitude\":6},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":4},{\"feature\":\"engagement\",\"label\":\"Engagement\",\"direction\":\"-\",\"magnitude\":3},{\"feature\":\"income_bracket\",\"label\":\"Household income band\",\"direction\":\"-\",\"magnitude\":3},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"-\",\"magnitude\":3},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":2},{\"feature\":\"internet_access\",\"label\":\"Internet access\",\"direction\":\"+\",\"magnitude\":2}],\"dropout\":[{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"-\",\"magnitude\":0.12},{\"feature\":\"procrastination\",\"label\":\"Procrastination\",\"direction\":\"-\",\"magnitude\":0.06},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":0.06},{\"feature\":\"engagement\",\"label\":\"Engagement\",\"direction\":\"-\",\"magnitude\":0.055},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"+\",\"magnitude\":0.05},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"-\",\"magnitude\":0.05},{\"feature\":\"motivation\",\"label\":\"Motivation\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"time_management\",\"label\":\"Time management\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"-\",\"magnitude\":0.0377},{\"feature\":\"income_bracket\",\"label\":\"Household income band\",\"direction\":\"-\",\"magnitude\":0.03},{\"feature\":\"internships\",\"label\":\"Internships or OJT\",\"direction\":\"+\",\"magnitude\":0.03},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":0.01},{\"feature\":\"internet_access\",\"label\":\"Internet access\",\"direction\":\"+\",\"magnitude\":0.01}],\"program_shift\":{\"flag\":\"disengagement\",\"label\":\"Broader disengagement\",\"message\":\"This pattern looks more like engagement, motivation, consistency, or performance across subjects than a program-fit concern. Those are areas where support could help.\",\"engagement\":\"Needs support\",\"factors\":[{\"feature\":\"engagement\",\"label\":\"Engagement\",\"note\":\"An area where support could help\"}]}}','{\"gwa\":2.1,\"failed_subjects\":1,\"semesters_completed\":1,\"limited_history\":true,\"scholarship_status\":\"government\",\"has_scholarship\":true,\"employment_status\":\"unemployed\",\"income_bracket\":\"below_10k\",\"household_size\":6,\"living_arrangement\":\"with_family\",\"internet_access\":\"yes\",\"device_access\":\"yes\",\"study_space\":\"no\",\"technical_skill_count\":0,\"certification_count\":0,\"internship_count\":1,\"project_count\":0,\"work_experience_count\":0,\"construct_scores\":{\"study_habits\":25,\"time_management\":50,\"motivation\":50,\"procrastination\":50,\"engagement\":31.25},\"major_gwa\":null,\"other_gwa\":2.1,\"major_failed_subjects\":0,\"other_failed_subjects\":1,\"major_units\":0,\"other_units\":24}',NULL,'2026-10-08 19:28:10'),
(63,2,7,'placeholder-heuristic-v0',72.70,0.3960,'moderate','normal','none','{\"employability\":[{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":13.4},{\"feature\":\"technical_skills\",\"label\":\"Technical skills\",\"direction\":\"+\",\"magnitude\":4.5},{\"feature\":\"failed_subjects\",\"label\":\"Failed subjects\",\"direction\":\"+\",\"magnitude\":4},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":3.2},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":2},{\"feature\":\"internet_access\",\"label\":\"Internet access\",\"direction\":\"+\",\"magnitude\":2},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"-\",\"magnitude\":2},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"+\",\"magnitude\":2}],\"dropout\":[{\"feature\":\"procrastination\",\"label\":\"Procrastination\",\"direction\":\"-\",\"magnitude\":0.06},{\"feature\":\"study_habits\",\"label\":\"Study habits\",\"direction\":\"-\",\"magnitude\":0.056},{\"feature\":\"gwa\",\"label\":\"General weighted average\",\"direction\":\"+\",\"magnitude\":0.05},{\"feature\":\"engagement\",\"label\":\"Engagement\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"motivation\",\"label\":\"Motivation\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"scholarship\",\"label\":\"Scholarship\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"time_management\",\"label\":\"Time management\",\"direction\":\"-\",\"magnitude\":0.04},{\"feature\":\"device_access\",\"label\":\"Device access\",\"direction\":\"+\",\"magnitude\":0.01},{\"feature\":\"internet_access\",\"label\":\"Internet access\",\"direction\":\"+\",\"magnitude\":0.01},{\"feature\":\"study_space\",\"label\":\"Study space\",\"direction\":\"+\",\"magnitude\":0.01}],\"program_shift\":{\"flag\":\"none\",\"label\":\"No shift pattern\",\"message\":\"No program-shift pattern stands out in this estimate.\",\"engagement\":\"Moderate\",\"factors\":[]}}','{\"gwa\":1.66,\"failed_subjects\":0,\"semesters_completed\":2,\"limited_history\":false,\"scholarship_status\":\"none\",\"has_scholarship\":false,\"employment_status\":\"unemployed\",\"income_bracket\":\"20k_40k\",\"household_size\":4,\"living_arrangement\":\"with_family\",\"internet_access\":\"yes\",\"device_access\":\"yes\",\"study_space\":\"yes\",\"technical_skill_count\":3,\"certification_count\":0,\"internship_count\":0,\"project_count\":0,\"work_experience_count\":0,\"construct_scores\":{\"study_habits\":30,\"time_management\":50,\"motivation\":50,\"procrastination\":50,\"engagement\":50},\"major_gwa\":2.38,\"other_gwa\":1.48,\"major_failed_subjects\":0,\"other_failed_subjects\":0,\"major_units\":8,\"other_units\":33}','{\"skills_experience\":{\"version\":1,\"section_saved\":true,\"technical_skills\":[{\"name\":\"HTML\"},{\"name\":\"PHP\"},{\"name\":\"SQL\"}],\"certifications\":[],\"work_experience\":[]},\"grades\":{\"version\":1,\"has_grades\":true,\"rounded_gwa\":1.66,\"gwa_provisional\":false,\"failed_subjects\":0,\"incomplete_subjects\":0,\"reports\":[{\"grade_report_id\":63,\"report_version\":1,\"school_year\":\"2024-2025\",\"semester\":\"First\",\"source\":\"pasted\",\"confirmed_at\":\"2026-10-09T05:13:08+08:00\",\"subjects\":[{\"subject_code\":\"CCS 104\",\"subject_name\":\"DATA STRUCTURES AND ALGORITHMS\",\"units\":3,\"final_grade\":\"1.25\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"CCS 105\",\"subject_name\":\"INFORMATION MANAGEMENT\",\"units\":5,\"final_grade\":\"1.50\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"CCS 112\",\"subject_name\":\"OPERATING SYSTEM & APPLICATION\",\"units\":3,\"final_grade\":\"2.00\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"CCS 125\",\"subject_name\":\"SYSTEM ANALYSIS AND DESIGN\",\"units\":3,\"final_grade\":\"1.25\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"GEC 005\",\"subject_name\":\"PURPOSIVE COMMUNICATION\",\"units\":3,\"final_grade\":\"1.00\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"GEC 007\",\"subject_name\":\"SCIENCE, TECHNOLOGY & SOCIETY\",\"units\":3,\"final_grade\":\"1.25\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"IS 101\",\"subject_name\":\"FINANCIAL MANAGEMENT\",\"units\":3,\"final_grade\":\"1.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"PATHFIT 3\",\"subject_name\":\"DANCE AND FITNESS\",\"units\":2,\"final_grade\":\"1.00\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false}]},{\"grade_report_id\":1,\"report_version\":1,\"school_year\":\"2024-2025\",\"semester\":\"Second\",\"source\":\"manual\",\"confirmed_at\":\"2026-10-06T06:53:27+08:00\",\"subjects\":[{\"subject_code\":\"CCS 106\",\"subject_name\":\"Applications Development\",\"units\":5,\"final_grade\":\"2.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"GEE 002\",\"subject_name\":\"Living in the IT Era\",\"units\":3,\"final_grade\":\"1.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"PATHFIT 4\",\"subject_name\":\"Sports and Fitness\",\"units\":2,\"final_grade\":\"1.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"PR 002\",\"subject_name\":\"Quantitative Methods\",\"units\":3,\"final_grade\":\"1.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false},{\"subject_code\":\"IS 106\",\"subject_name\":\"IS Major Elective 1\",\"units\":3,\"final_grade\":\"1.75\",\"remarks\":\"PASSED\",\"is_failed\":false,\"is_incomplete\":false}]}]}}','2026-10-09 05:14:55');
/*!40000 ALTER TABLE `predictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `programs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `college_id` bigint(20) unsigned NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `programs_code_unique` (`code`),
  KEY `programs_college_id_index` (`college_id`),
  KEY `programs_department_id_foreign` (`department_id`),
  KEY `programs_is_active_index` (`is_active`),
  CONSTRAINT `programs_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `programs_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES
(1,5,3,'Bachelor of Science in Information Technology','BSIT',1,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(2,5,3,'Bachelor of Science in Computer Science','BSCS',1,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(3,5,3,'Bachelor of Science in Information Systems','BSIS',1,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(4,2,NULL,'Bachelor of Science in Business Administration','BSBA',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(5,2,NULL,'Bachelor of Science in Accountancy','BSA',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(6,3,NULL,'Bachelor of Secondary Education','BSED',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(7,3,NULL,'Bachelor of Elementary Education','BEED',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(8,4,NULL,'Bachelor of Science in Computer Engineering','BSCpE',0,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(9,5,1,'BA Communication','ABCOMM',1,'2026-10-06 06:53:24','2026-10-09 01:58:15'),
(10,5,2,'Bachelor of Public Administration','BPA',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(11,5,3,'Bachelor of Science in Entertainment and Multimedia Computing','BSEMC',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(12,5,4,'Bachelor of Science in Mathematics','BSMATH',1,'2026-10-09 01:58:15','2026-10-09 01:58:15'),
(13,5,5,'Bachelor of Science in Psychology','BSPSYCH',1,'2026-10-09 01:58:15','2026-10-09 01:58:15');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psoc_occupations`
--

DROP TABLE IF EXISTS `psoc_occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `psoc_occupations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `psoc_code` varchar(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `major_group` varchar(120) NOT NULL,
  `description` text NOT NULL,
  `skill_tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`skill_tags`)),
  `related_program_codes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`related_program_codes`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `psoc_occupations_psoc_code_unique` (`psoc_code`),
  KEY `psoc_occupations_major_group_index` (`major_group`),
  KEY `psoc_occupations_title_index` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psoc_occupations`
--

LOCK TABLES `psoc_occupations` WRITE;
/*!40000 ALTER TABLE `psoc_occupations` DISABLE KEYS */;
INSERT INTO `psoc_occupations` VALUES
(1,'2511','Systems Analysts','Information and communications technology','Study how an organization uses information systems and propose improvements.','[\"analysis\",\"requirements\",\"programming\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(2,'2512','Software Developers','Information and communications technology','Design, build, and test software applications.','[\"programming\",\"algorithms\",\"sql\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(3,'2513','Web and Multimedia Developers','Information and communications technology','Build websites and multimedia applications.','[\"html\",\"programming\",\"web\"]','[\"BSIT\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(4,'2514','Applications Programmers','Information and communications technology','Write and maintain application code from specifications.','[\"programming\",\"debugging\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(5,'2519','Software and Applications Developers NEC','Information and communications technology','Software roles that do not fit a narrower developer title.','[\"programming\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(6,'2521','Database Designers and Administrators','Information and communications technology','Design and look after databases and stored data.','[\"sql\",\"database\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(7,'2522','Systems Administrators','Information and communications technology','Install and maintain computer systems and servers.','[\"systems\",\"networks\",\"linux\"]','[\"BSIT\",\"BSCS\",\"BSIS\",\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(8,'2523','Computer Network Professionals','Information and communications technology','Design and support computer networks.','[\"networks\",\"security\"]','[\"BSIT\",\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(9,'2529','Database and Network Professionals NEC','Information and communications technology','Combined database and network work outside narrower titles.','[\"database\",\"networks\"]','[\"BSIT\",\"BSCS\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(10,'3512','ICT User Support Technicians','Information and communications technology','Help people use computers, software, and accounts.','[\"support\",\"troubleshooting\"]','[\"BSIT\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(11,'3514','Web Technicians','Information and communications technology','Maintain websites and routine web updates.','[\"html\",\"web\"]','[\"BSIT\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(12,'1330','ICT Service Managers','Information and communications technology','Plan and supervise information and communications services.','[\"management\",\"programming\"]','[\"BSIT\",\"BSIS\",\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(13,'2411','Accountants','Business and administration','Prepare and examine financial records.','[\"accounting\",\"audit\"]','[\"BSA\",\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(14,'2412','Financial and Investment Advisers','Business and administration','Advise on budgets, savings, and investments.','[\"finance\",\"investment\"]','[\"BSA\",\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(15,'2421','Management and Organization Analysts','Business and administration','Review how a team or office is organized and suggest changes.','[\"analysis\",\"management\"]','[\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(16,'2431','Advertising and Marketing Professionals','Business and administration','Plan how products and services are presented to audiences.','[\"marketing\",\"communication\"]','[\"BSBA\",\"ABCOMM\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(17,'1221','Sales and Marketing Managers','Business and administration','Lead sales and marketing work.','[\"sales\",\"marketing\",\"management\"]','[\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(18,'3313','Accounting Associate Professionals','Business and administration','Support bookkeeping and routine accounting tasks.','[\"bookkeeping\",\"accounting\"]','[\"BSA\",\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(19,'3322','Commercial Sales Representatives','Business and administration','Present products and services to business customers.','[\"sales\",\"communication\"]','[\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(20,'4311','Accounting and Bookkeeping Clerks','Business and administration','Record day-to-day financial transactions.','[\"bookkeeping\"]','[\"BSA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(21,'2310','University and Higher Education Teachers','Education','Teach courses in a college or university setting.','[\"teaching\",\"research\"]','[\"BSED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(22,'2320','Vocational Education Teachers','Education','Teach job-related subjects in a training setting.','[\"teaching\",\"training\"]','[\"BSED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(23,'2330','Secondary Education Teachers','Education','Teach subjects in a secondary school.','[\"teaching\",\"lesson planning\"]','[\"BSED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(24,'2341','Primary School Teachers','Education','Teach children in an elementary classroom.','[\"teaching\",\"child development\"]','[\"BEED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(25,'2351','Education Methods Specialists','Education','Help schools improve teaching methods and materials.','[\"curriculum\",\"teaching\"]','[\"BSED\",\"BEED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(26,'2359','Teaching Professionals NEC','Education','Teaching roles that do not fit a narrower school level.','[\"teaching\"]','[\"BSED\",\"BEED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(27,'2142','Civil Engineers','Engineering and technology','Plan roads, structures, and other civil works.','[\"civil design\",\"structures\"]','[\"BSCE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(28,'2144','Mechanical Engineers','Engineering and technology','Design and test mechanical equipment.','[\"mechanical design\",\"cad\"]','[\"BSME\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(29,'2149','Engineering Professionals NEC','Engineering and technology','Engineering work outside a narrower discipline.','[\"engineering\",\"problem solving\"]','[\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(30,'2151','Electrical Engineers','Engineering and technology','Design and maintain electrical systems.','[\"electrical\",\"circuits\"]','[\"BSEE\",\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(31,'2152','Electronics Engineers','Engineering and technology','Design electronic devices and embedded systems.','[\"electronics\",\"circuits\"]','[\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(32,'2153','Telecommunications Engineers','Engineering and technology','Plan and support telecommunications systems.','[\"networks\",\"telecommunications\"]','[\"BSCpE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(33,'3112','Civil Engineering Technicians','Engineering and technology','Support civil engineering drawings and site checks.','[\"drafting\",\"surveying\"]','[\"BSCE\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(34,'3115','Mechanical Engineering Technicians','Engineering and technology','Support mechanical testing and drawings.','[\"drafting\",\"mechanical design\"]','[\"BSME\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(35,'2211','Generalist Medical Practitioners','Health','Provide general medical care.','[\"clinical care\",\"diagnosis\"]','[\"BSMED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(36,'2212','Specialist Medical Practitioners','Health','Provide care in a medical specialty.','[\"clinical care\",\"specialty medicine\"]','[\"BSMED\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(37,'2221','Nursing Professionals','Health','Provide nursing care and health education.','[\"nursing\",\"patient care\"]','[\"BSN\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(38,'2261','Dentists','Health','Diagnose and treat oral health conditions.','[\"dentistry\",\"patient care\"]','[\"BSDENT\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(39,'2262','Pharmacists','Health','Prepare and advise on medicines.','[\"pharmacy\",\"medication\"]','[\"BSPHARM\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(40,'3211','Medical Imaging Technicians','Health','Operate imaging equipment used in diagnosis.','[\"imaging\",\"patient care\"]','[\"BSRT\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(41,'3256','Medical Assistants','Health','Support clinics with routine patient tasks.','[\"clinical support\",\"records\"]','[\"BSN\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(42,'5321','Health Care Assistants','Health','Help patients with daily care under supervision.','[\"patient care\",\"support\"]','[\"BSN\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(43,'2166','Graphic and Multimedia Designers','Other professional services','Create visual layouts and multimedia pieces.','[\"design\",\"multimedia\"]','[\"ABCOMM\",\"BSIS\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(44,'2642','Journalists','Other professional services','Research and present news and features.','[\"writing\",\"communication\"]','[\"ABCOMM\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(45,'2611','Lawyers','Other professional services','Advise on legal rights and represent clients.','[\"law\",\"research\"]','[\"LLB\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(46,'2631','Economists','Other professional services','Study how resources and markets are used.','[\"economics\",\"analysis\"]','[\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(47,'2634','Psychologists','Other professional services','Study behavior for education, workplace, or research settings. This category is not a clinical assessment.','[\"assessment\",\"communication\"]','[\"BSPSYCH\"]','2026-10-06 06:53:26','2026-10-06 06:53:26'),
(48,'3341','Office Supervisors','Other professional services','Coordinate clerical work in an office.','[\"supervision\",\"records\"]','[\"BSBA\"]','2026-10-06 06:53:26','2026-10-06 06:53:26');
/*!40000 ALTER TABLE `psoc_occupations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire_answers`
--

DROP TABLE IF EXISTS `questionnaire_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `questionnaire_answers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `questionnaire_response_id` bigint(20) unsigned NOT NULL,
  `questionnaire_item_id` bigint(20) unsigned NOT NULL,
  `value` tinyint(3) unsigned NOT NULL,
  `protected_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `questionnaire_answers_response_item_unique` (`questionnaire_response_id`,`questionnaire_item_id`),
  KEY `questionnaire_answers_questionnaire_item_id_foreign` (`questionnaire_item_id`),
  CONSTRAINT `questionnaire_answers_questionnaire_item_id_foreign` FOREIGN KEY (`questionnaire_item_id`) REFERENCES `questionnaire_items` (`id`),
  CONSTRAINT `questionnaire_answers_questionnaire_response_id_foreign` FOREIGN KEY (`questionnaire_response_id`) REFERENCES `questionnaire_responses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire_answers`
--

LOCK TABLES `questionnaire_answers` WRITE;
/*!40000 ALTER TABLE `questionnaire_answers` DISABLE KEYS */;
INSERT INTO `questionnaire_answers` VALUES
(1,1,1,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(2,1,2,3,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(3,1,3,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(4,1,4,5,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(5,1,5,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(6,1,6,5,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(7,1,7,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(8,1,8,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(9,1,9,1,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(10,1,10,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(11,1,11,5,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(12,1,12,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(13,1,13,5,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(14,1,14,1,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(15,1,15,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(16,1,16,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(17,1,17,3,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(18,1,18,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(19,1,19,4,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(20,1,20,2,NULL,'2026-10-06 13:40:09','2026-10-06 13:40:09'),
(21,2,1,1,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(22,2,2,3,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(23,2,3,2,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(24,2,4,4,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(25,2,5,4,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(26,2,6,5,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(27,2,7,3,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(28,2,8,2,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(29,2,9,1,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(30,2,10,3,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(31,2,11,4,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(32,2,12,2,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(33,2,13,1,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(34,2,14,3,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(35,2,15,4,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(36,2,16,2,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(37,2,17,1,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(38,2,18,5,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(39,2,19,4,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(40,2,20,3,NULL,'2026-10-06 20:43:20','2026-10-06 20:43:20'),
(41,3,1,1,NULL,'2026-10-09 03:46:37','2026-10-09 03:47:27'),
(42,3,2,2,NULL,'2026-10-09 03:46:37','2026-10-09 03:47:06'),
(43,3,3,4,NULL,'2026-10-09 03:46:37','2026-10-09 03:47:11'),
(44,3,4,4,NULL,'2026-10-09 03:46:37','2026-10-09 03:46:37'),
(45,3,21,4,NULL,'2026-10-09 03:46:37','2026-10-09 03:47:27'),
(46,3,5,1,NULL,'2026-10-09 03:46:54','2026-10-09 03:47:27'),
(47,3,6,4,NULL,'2026-10-09 03:46:54','2026-10-09 03:47:27'),
(48,3,7,2,NULL,'2026-10-09 03:46:54','2026-10-09 03:47:06'),
(49,3,8,4,NULL,'2026-10-09 03:47:00','2026-10-09 03:47:11'),
(50,3,12,4,NULL,'2026-10-09 03:47:00','2026-10-09 03:47:11'),
(51,3,9,1,NULL,'2026-10-09 03:47:06','2026-10-09 03:47:27'),
(52,3,10,4,NULL,'2026-10-09 03:47:06','2026-10-09 03:47:27'),
(53,3,11,2,NULL,'2026-10-09 03:47:06','2026-10-09 03:47:06'),
(54,3,13,1,NULL,'2026-10-09 03:47:11','2026-10-09 03:47:27'),
(55,3,14,4,NULL,'2026-10-09 03:47:11','2026-10-09 03:47:27'),
(56,3,16,4,NULL,'2026-10-09 03:47:11','2026-10-09 03:47:11'),
(57,3,15,2,NULL,'2026-10-09 03:47:22','2026-10-09 03:47:22'),
(58,3,19,2,NULL,'2026-10-09 03:47:22','2026-10-09 03:47:22'),
(59,3,17,1,NULL,'2026-10-09 03:47:27','2026-10-09 03:47:27'),
(60,3,18,4,NULL,'2026-10-09 03:47:27','2026-10-09 03:47:27'),
(61,3,20,4,NULL,'2026-10-09 03:47:27','2026-10-09 03:47:27'),
(62,4,1,2,NULL,'2026-10-09 05:13:32','2026-10-09 05:14:05'),
(63,4,2,4,NULL,'2026-10-09 05:13:32','2026-10-09 05:14:05'),
(64,4,3,2,NULL,'2026-10-09 05:13:32','2026-10-09 05:14:05'),
(65,4,4,5,NULL,'2026-10-09 05:13:32','2026-10-09 05:13:32'),
(66,4,21,4,NULL,'2026-10-09 05:13:32','2026-10-09 05:13:58'),
(67,4,5,2,NULL,'2026-10-09 05:13:39','2026-10-09 05:14:05'),
(68,4,6,4,NULL,'2026-10-09 05:13:39','2026-10-09 05:13:58'),
(69,4,7,4,NULL,'2026-10-09 05:13:39','2026-10-09 05:14:05'),
(70,4,8,2,NULL,'2026-10-09 05:13:39','2026-10-09 05:14:05'),
(71,4,9,2,NULL,'2026-10-09 05:13:48','2026-10-09 05:14:05'),
(72,4,10,4,NULL,'2026-10-09 05:13:48','2026-10-09 05:13:58'),
(73,4,11,4,NULL,'2026-10-09 05:13:48','2026-10-09 05:14:05'),
(74,4,12,2,NULL,'2026-10-09 05:13:48','2026-10-09 05:14:05'),
(75,4,13,2,NULL,'2026-10-09 05:13:58','2026-10-09 05:14:05'),
(76,4,14,4,NULL,'2026-10-09 05:13:58','2026-10-09 05:13:58'),
(77,4,15,4,NULL,'2026-10-09 05:13:58','2026-10-09 05:14:05'),
(78,4,16,2,NULL,'2026-10-09 05:13:58','2026-10-09 05:14:05'),
(79,4,17,2,NULL,'2026-10-09 05:14:05','2026-10-09 05:14:05'),
(80,4,18,4,NULL,'2026-10-09 05:14:05','2026-10-09 05:14:05'),
(81,4,19,4,NULL,'2026-10-09 05:14:05','2026-10-09 05:14:05'),
(82,4,20,2,NULL,'2026-10-09 05:14:05','2026-10-09 05:14:05'),
(83,5,4,1,NULL,'2026-10-11 23:50:50','2026-10-11 23:50:50'),
(84,7,4,2,NULL,'2026-10-20 14:59:32','2026-10-20 14:59:32'),
(85,8,22,4,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(86,8,23,5,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(87,8,24,3,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(88,8,25,5,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(89,8,26,4,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(90,8,27,5,NULL,'2026-10-22 03:18:08','2026-10-22 03:18:08'),
(91,8,28,0,'eyJpdiI6IjJpSlpxTHZBdEwxOEswS281bVR5eVE9PSIsInZhbHVlIjoiYmpKTW9kZlhrdC9jUkgwWXViNWVwZz09IiwibWFjIjoiMjA2ZTEzM2VmYWI0ZmMzY2UxMmY1N2IwYmE3ZDYzODc2Zjc0Njg3NDZjZmYxYWE0ODY1OWYyOTNiMDhiYzE4NyIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(92,8,29,0,'eyJpdiI6IkxmaWpKRDZhckJoTUdGWU1ML0dGaGc9PSIsInZhbHVlIjoiSjlhVTlJTWhTYlNldWpJdmMrdm9BUT09IiwibWFjIjoiYzBiMTY5ZTA0MjllNTM5NTRhZjE0MWMyMzZjNzY4N2ZhNDIyZjI2ODU2MjNiY2U5NzlkMDJhNDFkZTgzMjA3MyIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(93,8,30,0,'eyJpdiI6ImVQL2UwZUZOMW12eSs4bjUzK2poRmc9PSIsInZhbHVlIjoiM1pabHhpMHFBU1lYampmMTZITnhuQT09IiwibWFjIjoiMDA2YTkyNWI4ZTYxM2ZkZTAxODZhMjFkM2M0Zjc0Nzk2YjZjZGM5NDUzNGJlMjA2NmVmNGQ4MWUzYWE2MzNjNSIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(94,8,31,0,'eyJpdiI6ImREaFRQbW5nZUlteWprb2hGTW1xWGc9PSIsInZhbHVlIjoicmV3amwyQ0hka2Yxd0hxWk9OVmltZz09IiwibWFjIjoiMjhiOTJkZTBiY2M1NDYxOTZmYWZjMzMyMTUyMjk4YmUxYjk3YTBiYzZkNDJjNGQ5ZjU3M2RmN2Q1ZmU3M2UxOSIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(95,8,32,0,'eyJpdiI6IkN1WTIwVmJGK0JOUnVkT2E0UHROL2c9PSIsInZhbHVlIjoiaHlWZmZCaitaUjREVEhnR3V0WUFpdz09IiwibWFjIjoiNGQ1MDQ5MmFiZDI3MWVjZTQ3YjBhOTIxMDU0Y2NmNWY0Mzg3ZWZlMDU5YjA3YzQzYjM0YzA0NzQ2ZmNiZTk5NyIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(96,8,33,0,'eyJpdiI6IkZQaThveGJQQ2x5cDdpSGRrMWZXRVE9PSIsInZhbHVlIjoiMm0vbk9zSE45QWxiYXFJY2luRzZXdz09IiwibWFjIjoiMThiNWI2NmU1ODFkYzgwNzcwZmY5MjQwY2IyOTlmMDAwMjI4YTNmM2JlN2EyNjIyYTdlMzcyNGIwNmQ5ZjQwNSIsInRhZyI6IiJ9','2026-10-22 03:18:56','2026-10-22 03:18:56'),
(97,8,34,5,NULL,'2026-10-22 03:19:34','2026-10-22 03:19:34'),
(98,8,35,2,NULL,'2026-10-22 03:19:34','2026-10-22 03:19:34'),
(99,8,36,4,NULL,'2026-10-22 03:19:34','2026-10-22 03:19:34'),
(100,8,37,5,NULL,'2026-10-22 03:19:34','2026-10-22 03:19:34'),
(101,8,38,4,NULL,'2026-10-22 03:19:34','2026-10-22 03:19:34'),
(102,8,39,5,NULL,'2026-10-22 03:19:45','2026-10-22 03:19:45'),
(103,8,40,2,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(104,8,41,5,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(105,8,42,3,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(106,8,43,4,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(107,8,44,5,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(108,8,45,5,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(109,8,46,1,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(110,8,47,4,NULL,'2026-10-22 03:20:38','2026-10-22 03:20:38'),
(111,8,48,3,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(112,8,49,3,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(113,8,50,4,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(114,8,51,5,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(115,8,52,5,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(116,8,53,5,NULL,'2026-10-22 03:49:25','2026-10-22 03:49:25'),
(117,8,54,5,NULL,'2026-10-22 03:49:44','2026-10-22 03:49:44'),
(118,8,55,4,NULL,'2026-10-22 03:49:44','2026-10-22 03:49:44'),
(119,8,56,4,NULL,'2026-10-22 03:49:44','2026-10-22 03:49:44'),
(120,8,57,5,NULL,'2026-10-22 03:49:44','2026-10-22 03:49:44');
/*!40000 ALTER TABLE `questionnaire_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire_items`
--

DROP TABLE IF EXISTS `questionnaire_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `questionnaire_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `section` varchar(40) NOT NULL DEFAULT 'academic_behavior',
  `definition_version` varchar(40) NOT NULL DEFAULT 'draft-v1',
  `construct` varchar(40) NOT NULL,
  `text` text NOT NULL,
  `reverse_scored` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_draft` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `questionnaire_items_construct_sort_order_index` (`construct`,`sort_order`),
  KEY `questionnaire_items_version_section_active` (`definition_version`,`section`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire_items`
--

LOCK TABLES `questionnaire_items` WRITE;
/*!40000 ALTER TABLE `questionnaire_items` DISABLE KEYS */;
INSERT INTO `questionnaire_items` VALUES
(1,'academic_behavior','draft-v1','study_habits','I review my notes after class.',0,1,1,1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(2,'academic_behavior','draft-v1','study_habits','I wait until the night before an exam to study.',1,1,1,2,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(3,'academic_behavior','draft-v1','study_habits','I set aside a regular place to study.',0,1,1,3,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(4,'academic_behavior','draft-v1','study_habits','I often study without a plan.',1,1,1,4,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(5,'academic_behavior','draft-v1','time_management','I start assignments soon after they are given.',0,1,1,1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(6,'academic_behavior','draft-v1','time_management','I often run out of time for coursework.',1,1,1,2,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(7,'academic_behavior','draft-v1','time_management','I keep a schedule for school tasks.',0,1,1,3,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(8,'academic_behavior','draft-v1','time_management','I underestimate how long schoolwork will take.',1,1,1,4,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(9,'academic_behavior','draft-v1','motivation','I am interested in learning the material in my program.',0,1,1,1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(10,'academic_behavior','draft-v1','motivation','I see little point in attending class.',1,1,1,2,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(11,'academic_behavior','draft-v1','motivation','I want to finish my degree.',0,1,1,3,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(12,'academic_behavior','draft-v1','motivation','I feel unmotivated to work on my courses.',1,1,1,4,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(13,'academic_behavior','draft-v1','procrastination','I delay starting important schoolwork.',0,1,1,1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(14,'academic_behavior','draft-v1','procrastination','I start schoolwork as soon as I can.',1,1,1,2,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(15,'academic_behavior','draft-v1','procrastination','I put off tasks even when I know they matter.',0,1,1,3,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(16,'academic_behavior','draft-v1','procrastination','I finish coursework ahead of the deadline.',1,1,1,4,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(17,'academic_behavior','draft-v1','engagement','I participate in class activities.',0,1,1,1,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(18,'academic_behavior','draft-v1','engagement','I rarely talk with classmates about coursework.',1,1,1,2,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(19,'academic_behavior','draft-v1','engagement','I keep up with course announcements.',0,1,1,3,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(20,'academic_behavior','draft-v1','engagement','I feel disconnected from my classes.',1,1,1,4,'2026-10-06 06:53:26','2026-10-06 06:53:26'),
(21,'academic_behavior','draft-v1','study_habits','Statement',0,1,1,1,'2026-10-06 20:59:17','2026-10-06 21:00:00'),
(22,'academic','ucc-panel-approved-v1','academic_self_perception','I am satisfied with my current academic performance.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(23,'academic','ucc-panel-approved-v1','academic_self_perception','I can understand the lessons and topics discussed in my classes.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(24,'academic','ucc-panel-approved-v1','academic_self_perception','I can manage the academic workload required by my degree program.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(25,'academic','ucc-panel-approved-v1','academic_self_perception','I can learn difficult topics when I put in enough effort.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(26,'academic','ucc-panel-approved-v1','academic_self_perception','I am confident that I can pass my enrolled subjects.',0,1,0,5,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(27,'academic','ucc-panel-approved-v1','academic_self_perception','I am confident that I can complete my degree program.',0,1,0,6,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(28,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','My available budget is sufficient to cover my school-related expenses.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(29,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','I can afford the transportation expenses needed to attend classes.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(30,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','I have reliable access to a computer or device for my academic tasks.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(31,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','I have reliable access to the internet for my academic requirements.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(32,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','My financial situation allows me to focus on my studies.',0,1,0,5,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(33,'socioeconomic','ucc-panel-approved-v1','socioeconomic_context','I have sufficient financial support to continue my education.',0,1,0,6,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(34,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I attend my scheduled classes regularly.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(35,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I set aside regular time to study or review my lessons outside class.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(36,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I actively participate in class activities and discussions when given the opportunity.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(37,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I make use of the learning materials and resources provided by my instructors when studying.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(38,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I complete my academic requirements within the given deadlines.',0,1,0,5,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(39,'behavioral','ucc-panel-approved-v1','behavioral_engagement','I continue working toward my academic goals even when I experience difficulties in my studies.',0,1,0,6,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(40,'competence','ucc-panel-approved-v1','competence','I can communicate my ideas clearly to other people.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(41,'competence','ucc-panel-approved-v1','competence','I can work effectively with other people in a team.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(42,'competence','ucc-panel-approved-v1','competence','I can identify problems and develop appropriate solutions.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(43,'competence','ucc-panel-approved-v1','competence','I can adapt to new tools, technologies, and changing situations.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(44,'competence','ucc-panel-approved-v1','competence','I can use digital tools and technology effectively for academic or practical tasks.',0,1,0,5,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(45,'competence','ucc-panel-approved-v1','competence','I can apply what I learned in school to practical tasks or real-world situations.',0,1,0,6,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(46,'competence','ucc-panel-approved-v1','competence','I can organize my work and responsibilities to complete assigned tasks.',0,1,0,7,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(47,'competence','ucc-panel-approved-v1','competence','I can learn new skills when a task or situation requires them.',0,1,0,8,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(48,'psychological_capital','ucc-panel-approved-v1','psychological_capital','I am confident that I can successfully handle difficult tasks related to my studies or future work.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(49,'psychological_capital','ucc-panel-approved-v1','psychological_capital','When I encounter a problem, I can think of different ways to overcome it.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(50,'psychological_capital','ucc-panel-approved-v1','psychological_capital','I continue working toward my goals even after experiencing setbacks.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(51,'psychological_capital','ucc-panel-approved-v1','psychological_capital','I generally expect that my efforts toward my studies and career will lead to positive results.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(52,'psychological_capital','ucc-panel-approved-v1','psychological_capital','I can recover and continue after academic or personal difficulties affect my progress.',0,1,0,5,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(53,'psychological_capital','ucc-panel-approved-v1','psychological_capital','I believe I can improve my abilities through effort, learning, and experience.',0,1,0,6,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(54,'self_perceived_employability','ucc-panel-approved-v1','self_perceived_employability','I feel prepared to apply for a job related to my degree program.',0,1,0,1,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(55,'self_perceived_employability','ucc-panel-approved-v1','self_perceived_employability','I believe I can demonstrate useful skills to a potential employer.',0,1,0,2,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(56,'self_perceived_employability','ucc-panel-approved-v1','self_perceived_employability','I can explain how my knowledge and experiences are relevant to a future job.',0,1,0,3,'2026-10-22 02:53:36','2026-10-22 02:53:36'),
(57,'self_perceived_employability','ucc-panel-approved-v1','self_perceived_employability','I am confident that I can continue developing the skills needed for my chosen career.',0,1,0,4,'2026-10-22 02:53:36','2026-10-22 02:53:36');
/*!40000 ALTER TABLE `questionnaire_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionnaire_responses`
--

DROP TABLE IF EXISTS `questionnaire_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `questionnaire_responses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `definition_version` varchar(40) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `construct_scores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`construct_scores`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `questionnaire_responses_student_id_submitted_at_index` (`student_id`,`submitted_at`),
  KEY `questionnaire_responses_student_version` (`student_id`,`definition_version`),
  CONSTRAINT `questionnaire_responses_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionnaire_responses`
--

LOCK TABLES `questionnaire_responses` WRITE;
/*!40000 ALTER TABLE `questionnaire_responses` DISABLE KEYS */;
INSERT INTO `questionnaire_responses` VALUES
(1,1,'draft-v1','2026-10-06 13:40:09','{\"study_habits\":37.5,\"time_management\":31.25,\"motivation\":50,\"procrastination\":87.5,\"engagement\":68.75}','2026-10-06 13:40:09','2026-10-06 13:40:09'),
(2,1,'draft-v1','2026-10-06 20:43:20','{\"study_habits\":25,\"time_management\":50,\"motivation\":50,\"procrastination\":50,\"engagement\":31.25}','2026-10-06 15:04:37','2026-10-06 20:43:20'),
(3,1,'draft-v1','2026-10-09 03:47:27','{\"study_habits\":50,\"time_management\":18.75,\"motivation\":18.75,\"procrastination\":18.75,\"engagement\":18.75}','2026-10-09 03:46:11','2026-10-09 03:47:27'),
(4,2,'draft-v1','2026-10-09 05:14:05','{\"study_habits\":30,\"time_management\":50,\"motivation\":50,\"procrastination\":50,\"engagement\":50}','2026-10-09 05:13:32','2026-10-09 05:14:05'),
(5,3,'draft-v1',NULL,NULL,'2026-10-11 23:49:50','2026-10-11 23:49:50'),
(6,2,'draft-v1',NULL,NULL,'2026-10-19 15:57:40','2026-10-19 15:57:40'),
(7,1,'draft-v1',NULL,NULL,'2026-10-20 14:53:23','2026-10-20 14:53:23'),
(8,62,'ucc-panel-approved-v1','2026-10-22 03:49:44','{\"academic_self_perception\":{\"section\":\"academic\",\"code\":\"A\",\"label\":\"Academic factors\",\"mean\":4.333,\"sum\":26,\"items\":6,\"level\":\"Very High\",\"readiness_percent\":83.33,\"context_flag\":false,\"role\":\"context\"},\"socioeconomic_context\":{\"section\":\"socioeconomic\",\"code\":\"S\",\"label\":\"Socioeconomic factors\",\"mean\":4.667,\"sum\":28,\"items\":6,\"level\":\"Very High\",\"readiness_percent\":91.68,\"context_flag\":false,\"role\":\"context\"},\"behavioral_engagement\":{\"section\":\"behavioral\",\"code\":\"B\",\"label\":\"Behavioral factors\",\"mean\":4.167,\"sum\":25,\"items\":6,\"level\":\"High\",\"readiness_percent\":79.18,\"context_flag\":false,\"role\":\"context\"},\"competence\":{\"section\":\"competence\",\"code\":\"C\",\"label\":\"Competence\",\"mean\":3.625,\"sum\":29,\"items\":8,\"level\":\"High\",\"readiness_percent\":65.63,\"context_flag\":false,\"role\":\"not_connected\"},\"psychological_capital\":{\"section\":\"psychological_capital\",\"code\":\"P\",\"label\":\"Psychological capital\",\"mean\":4.167,\"sum\":25,\"items\":6,\"level\":\"High\",\"readiness_percent\":79.18,\"context_flag\":false,\"role\":\"not_connected\"},\"self_perceived_employability\":{\"section\":\"self_perceived_employability\",\"code\":\"E\",\"label\":\"Self-perceived employability\",\"mean\":4.5,\"sum\":18,\"items\":4,\"level\":\"Very High\",\"readiness_percent\":87.5,\"context_flag\":false,\"role\":\"descriptive\"}}','2026-10-22 03:15:52','2026-10-22 03:49:44');
/*!40000 ALTER TABLE `questionnaire_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommended_actions`
--

DROP TABLE IF EXISTS `recommended_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommended_actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prediction_id` bigint(20) unsigned NOT NULL,
  `intervention_id` bigint(20) unsigned NOT NULL,
  `phrased_text` text NOT NULL,
  `phrasing_source` varchar(16) NOT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewer_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recommended_actions_prediction_id_intervention_id_unique` (`prediction_id`,`intervention_id`),
  KEY `recommended_actions_intervention_id_foreign` (`intervention_id`),
  KEY `recommended_actions_reviewed_by_foreign` (`reviewed_by`),
  KEY `recommended_actions_reviewed_at_index` (`reviewed_at`),
  CONSTRAINT `recommended_actions_intervention_id_foreign` FOREIGN KEY (`intervention_id`) REFERENCES `interventions` (`id`),
  CONSTRAINT `recommended_actions_prediction_id_foreign` FOREIGN KEY (`prediction_id`) REFERENCES `predictions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommended_actions_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommended_actions`
--

LOCK TABLES `recommended_actions` WRITE;
/*!40000 ALTER TABLE `recommended_actions` DISABLE KEYS */;
INSERT INTO `recommended_actions` VALUES
(1,1,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(2,1,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(3,5,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(4,5,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(5,5,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(6,5,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(7,6,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,6,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(9,10,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(10,10,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,10,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(12,10,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(13,11,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(14,11,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(15,15,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,15,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(17,15,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(18,15,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(19,16,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(20,16,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(21,20,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(22,20,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(23,20,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(24,20,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(25,21,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(26,21,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(27,25,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(28,25,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(29,25,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(30,25,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(31,26,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(32,26,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(33,30,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(34,30,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(35,30,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(36,30,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(37,31,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(38,31,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(39,35,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(40,35,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(41,35,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(42,35,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(43,36,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(44,36,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(45,40,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(46,40,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(47,40,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(48,40,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(49,41,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(50,41,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(51,45,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(52,45,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(53,45,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(54,45,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(55,46,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(56,46,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(57,50,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(58,50,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(59,50,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(60,50,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(61,51,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(62,51,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(63,55,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(64,55,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(65,55,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(66,55,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(67,56,11,'An adviser can talk with the student about whether the program still fits. This follows the qualitative program-shift indicator. It is not a trained model and it has no percentage.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(68,56,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(69,60,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(70,60,10,'The assigned adviser can schedule a check-in to talk through how the term is going. No automated action follows from it.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(71,60,12,'The adviser can agree on a short period of attendance follow-up with the student. It is a support check, not a disciplinary record.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(72,60,18,'The student can be invited back into a class routine, a peer group, or an adviser conversation. The invitation is supportive.','rule_based',NULL,NULL,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(73,61,7,'Short coaching on planning study time can be offered. It is a support option, not a judgment of the student.','rule_based',NULL,NULL,NULL,'2026-10-06 13:46:27','2026-10-06 13:46:27'),
(74,61,1,'A faculty adviser can refer the student to scheduled subject tutoring. This is an option to discuss, not a decision about academic standing.','rule_based',NULL,NULL,NULL,'2026-10-06 13:46:27','2026-10-06 13:46:27'),
(75,61,5,'A faculty adviser can offer a referral to the guidance office for a supportive conversation. This is not a clinical or diagnostic assessment.','rule_based',NULL,NULL,NULL,'2026-10-06 13:46:27','2026-10-06 13:46:27'),
(76,61,3,'The student can be pointed to the campus financial-aid office to ask about aid options. Staff do not see household income in this suggestion.','rule_based',NULL,NULL,NULL,'2026-10-06 13:46:27','2026-10-06 13:46:27'),
(77,61,4,'An adviser can help the student look at scholarship options the campus already offers. This is a referral, not an award.','rule_based',NULL,NULL,NULL,'2026-10-06 13:46:27','2026-10-06 13:46:27'),
(78,62,1,'You may suggest scheduled subject tutoring to support their learning in specific classes. This conversation is a supportive option to explore together, rather than a formal academic decision.','ai',NULL,NULL,NULL,'2026-10-08 19:28:57','2026-10-08 19:28:57'),
(79,62,6,'You can invite the student to attend a study-skills workshop focused on building effective learning habits. Please consider whether this invitation aligns well with their current needs.','ai',NULL,NULL,NULL,'2026-10-08 19:28:57','2026-10-08 19:28:57'),
(80,62,10,'Scheduling a check-in offers a chance to discuss how the term is progressing in a supportive space. This conversation does not trigger any automated administrative actions.','ai',NULL,NULL,NULL,'2026-10-08 19:28:57','2026-10-08 19:28:57'),
(81,62,18,'You might encourage reconnecting with a class routine, peer group, or a supportive conversation. This invitation is meant to foster connection without pressure.','ai',NULL,NULL,NULL,'2026-10-08 19:28:57','2026-10-08 19:28:57'),
(82,62,5,'You can offer a referral to the guidance office for a supportive conversation. This referral connects them to resources and is not a clinical or diagnostic assessment.','ai',NULL,NULL,NULL,'2026-10-08 19:28:57','2026-10-08 19:28:57'),
(83,63,6,'Invite the student to a study‑skills workshop, with the adviser deciding if it fits.','ai',NULL,NULL,NULL,'2026-10-09 05:15:26','2026-10-09 05:15:26'),
(84,63,4,'Provide the student with advising on existing campus scholarship options as a referral, not an award.','ai',NULL,NULL,NULL,'2026-10-09 05:15:26','2026-10-09 05:15:26'),
(85,63,5,'Refer the student to the guidance office for a supportive conversation, without clinical assessment.','ai',NULL,NULL,NULL,'2026-10-09 05:15:26','2026-10-09 05:15:26'),
(86,63,7,'Offer brief time‑management coaching to help the student plan study time as a supportive option.','ai',NULL,NULL,NULL,'2026-10-09 05:15:26','2026-10-09 05:15:26'),
(87,63,10,'Schedule a check‑in with the assigned adviser to discuss the term’s progress, without automated follow‑up.','ai',NULL,NULL,NULL,'2026-10-09 05:15:26','2026-10-09 05:15:26');
/*!40000 ALTER TABLE `recommended_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('snBNpeIhHKsMmK8ozwqXrpGbld72x5MhgE1pRxG6',69,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoic1JLNDQ4NDU0MnFpYXg0dVhqb1N4dHN2UXZtVkR2Qk5udGkzT3luMCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM3OiJodHRwOi8vbG9jYWxob3N0OjgwMDAvc3R1ZGVudC9oaXN0b3J5IjtzOjU6InJvdXRlIjtzOjE1OiJzdHVkZW50Lmhpc3RvcnkiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo2OTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2NDoiMTg4MWExOGIyNGI1ODcxMTFlM2JjOWY1MGQ1NzZkMGNiN2U1OGEzODNhOWFlZmE2MjMzYWIzOTBjN2YxYzk3ZiI7fQ==',1792612719);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skills_experiences`
--

DROP TABLE IF EXISTS `skills_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `skills_experiences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `technical_skills` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`technical_skills`)),
  `certifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`certifications`)),
  `internships` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`internships`)),
  `projects` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`projects`)),
  `work_experience` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`work_experience`)),
  `is_draft` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `skills_experiences_student_id_unique` (`student_id`),
  CONSTRAINT `skills_experiences_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills_experiences`
--

LOCK TABLES `skills_experiences` WRITE;
/*!40000 ALTER TABLE `skills_experiences` DISABLE KEYS */;
INSERT INTO `skills_experiences` VALUES
(1,2,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(2,3,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(3,4,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(4,5,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(5,6,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(6,7,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(7,8,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,9,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(9,10,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(10,11,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,12,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(12,13,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(13,14,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(14,15,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(15,16,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,17,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(17,18,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(18,19,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(19,20,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(20,21,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(21,22,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(22,23,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(23,24,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(24,25,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(25,26,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(26,27,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(27,28,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(28,29,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(29,30,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(30,31,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(31,32,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(32,33,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(33,34,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(34,35,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(35,36,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(36,37,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(37,38,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(38,39,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(39,40,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(40,41,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(41,42,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(42,43,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(43,44,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(44,45,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(45,46,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(46,47,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(47,48,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(48,49,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(49,50,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(50,51,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(51,52,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(52,53,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(53,54,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(54,55,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(55,56,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(56,57,'[\"PHP\",\"SQL\",\"HTML\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(57,58,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(58,59,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(59,60,'[\"communication\",\"research\"]','[]','[{\"title\":\"OJT\",\"hours\":200}]','[]','[]',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(60,61,'[\"communication\",\"research\"]','[]','[]','[]','[]',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(61,1,'[]','[]','[{\"organization\":\"OJT\",\"role\":\"\"}]','[]','[]',0,'2026-10-06 13:45:06','2026-10-06 13:45:06'),
(62,62,NULL,NULL,NULL,NULL,NULL,0,'2026-10-22 03:53:42','2026-10-22 03:53:42');
/*!40000 ALTER TABLE `skills_experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socioeconomic_profiles`
--

DROP TABLE IF EXISTS `socioeconomic_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `socioeconomic_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `household_income_bracket` text DEFAULT NULL,
  `household_size` text DEFAULT NULL,
  `scholarship_status` text DEFAULT NULL,
  `employment_status` text DEFAULT NULL,
  `living_arrangement` text DEFAULT NULL,
  `has_internet` text DEFAULT NULL,
  `has_device` text DEFAULT NULL,
  `has_study_space` text DEFAULT NULL,
  `is_draft` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `socioeconomic_profiles_student_id_unique` (`student_id`),
  CONSTRAINT `socioeconomic_profiles_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socioeconomic_profiles`
--

LOCK TABLES `socioeconomic_profiles` WRITE;
/*!40000 ALTER TABLE `socioeconomic_profiles` DISABLE KEYS */;
INSERT INTO `socioeconomic_profiles` VALUES
(1,2,'eyJpdiI6IkhVMjF0WnFSYWhJMzlDRytWem5JaVE9PSIsInZhbHVlIjoiNytIZ1ZRcDFwaHdTbnZxVnliMEczdz09IiwibWFjIjoiMWFmZmYxNDAyM2NlMGVkODBkZDkwNjM4OWFhYWJmMmFkM2U3OTRlNzdhZjcxYjZmNTA0YjdiNTJlYjhjZDZiOCIsInRhZyI6IiJ9','eyJpdiI6ImxJRFNNK2NPNHkrdzVUSDBsaXE2UXc9PSIsInZhbHVlIjoiWXRTclZ1Q3VZTkRxVGZKRU1rcEEzdz09IiwibWFjIjoiNmEzNWVlNzUyODgyODRiMWEwYjEwNTYwMTkwZTcxMWMzMjE2YzEzNTc5NDNjODdjYzQ1MTM3NGRkY2ZjOWIwYiIsInRhZyI6IiJ9','eyJpdiI6Im5wTmdyRkI1UmxzK3lpVVdya0k1eGc9PSIsInZhbHVlIjoiaGJ0eDVWV1htTTdjMXk2UUhNWjJiQT09IiwibWFjIjoiNzEzZTU3Mzc2YzYwYjI5NDYzMDU1ZjEwY2RiOGUzMDYyNWNkMDEwYTAzNTdjNjdhYTFiYWVmNmI5MjQ4ZmNhNiIsInRhZyI6IiJ9','eyJpdiI6IjY3Rk9GU2pRbWVyZVlSL1FJcmFCUlE9PSIsInZhbHVlIjoidTl6SXJsQWpDV0g5bVAwbHI1OWo1QT09IiwibWFjIjoiOGQ5MWFhNGViYTQ4ZDdiNjI4NGIyNWFjNDU2ODgzNzliZWFlNWQwYzk5MTY4YTg4MDVmYzgwMzlkZmQyZmExZSIsInRhZyI6IiJ9','eyJpdiI6IlliRkJCd2ozWk1nVWZUeU1qUHgvTWc9PSIsInZhbHVlIjoiaEN3Qy9VaTN6S3djZFlrcmRJS2hxdz09IiwibWFjIjoiNjYyZmRmMDM5MzVhOTk2OTU0MDY5YjRhMTBlMWJkYjBjMmQ2OTQ5NWMyMWNjZWIzNDBkMDMxZDcyMzVlMjU2YyIsInRhZyI6IiJ9','eyJpdiI6ImdlQko4RXZSVWVZcmJMSUcxYWRmeVE9PSIsInZhbHVlIjoiYWIzcVRwbXo1RFVnOCs2K0IybDQrUT09IiwibWFjIjoiMDg5Zjc5ZDJmOTI5YTNjNzlmYjViYmJlMWRiNjA2ZTM4ZDFjN2MwNzU1NDA5MmZmNzY2Zjc1OWIwODY3NWE0OSIsInRhZyI6IiJ9','eyJpdiI6IlNOOEI2S3dGTnEvb1Y4cHFTaUxyK1E9PSIsInZhbHVlIjoibk5YMkpBKzVxOVIycnVVU1RycE1LZz09IiwibWFjIjoiZDY3ZDQ5MDMxNTk2ODgxYzFmZWI1OWRiMjNhZDAyNjIyYjk0OTEyYWNlMGE0ZWFhYTA2NzUwZTVkOWZjMGY5ZCIsInRhZyI6IiJ9','eyJpdiI6IjgrMVpzWUFFdjBVTlJQblhaeWR0TGc9PSIsInZhbHVlIjoiVWhzMU1UajQyMDd5KzFsVjZ2eVcxQT09IiwibWFjIjoiNzY1MmY3NGI0ZTQxOWRmYTMwMTUwZGU3Y2UyNDQ2ZjBkM2Q0N2JlNmMzZDBlMmFiNmMyYTgwMjlmOTc1NzRkYyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(2,3,'eyJpdiI6InRVRXVxVi9MOUIzbEhneGdTeXRqS2c9PSIsInZhbHVlIjoiQzFoRG9OTi9UaXVYOTI4Tk1GOUYwUT09IiwibWFjIjoiZTNhZTU2Y2E5NzQwZTQ0YzljMTlhYjk3ZDZiOTQyYzkwYTFlZGRkOWJlMmVjZjFiZTIyM2IwYjc1N2FkNGJmYyIsInRhZyI6IiJ9','eyJpdiI6IjBtZFdxb0NkNzRrejgzR2RObTZrU1E9PSIsInZhbHVlIjoiTGZpQUphMGV4K2lsSG9YOEZtT3Y5QT09IiwibWFjIjoiNmY0YzUwZjdmZDcwOTYwOGNiYzYzNTVmZTY5YzExMDFjZDlkNTc5NThjNDExMmFmM2Q1ZWYzMjYxZWNlMmM3ZSIsInRhZyI6IiJ9','eyJpdiI6IkZKZW9GQk85UjVPYy9CaGlYVlNUd3c9PSIsInZhbHVlIjoiTVBTejF0aUlUWk9uVTc0dWptMG5lZz09IiwibWFjIjoiOTAwZTJjYzJlNTkxMDg3MDI3OTNmZmI4NjM3M2UzZDRlMjliMjM1MWQzMjBlMjMxMmQ5YzY3MmNiZTFlMjU0NCIsInRhZyI6IiJ9','eyJpdiI6Ing5ZHh6aGpOOFFPQU9QVFNGU2xVSmc9PSIsInZhbHVlIjoiZmlPRlEySkJCVXNVVUpEa1ZpeW9iUT09IiwibWFjIjoiZTQzZTUwNjY5ZDAzODBhNzYzNTk3M2ExNTY5NzEzZWRmYjMzOTNmZGFkODU1NGRhNWZhMTZiNWNjOWEwZTZhMSIsInRhZyI6IiJ9','eyJpdiI6IjBKbThrQTdWY1ZoaWJWejJWOWY5dEE9PSIsInZhbHVlIjoidGQyY3dmVktiQmh3Mm5Ocy9vWEJsZz09IiwibWFjIjoiOTZhMTllNzgwZWEyYzc1NDAxOTY0OTM1ZWYwYWRkZTQ2NWRiMzE3YmY2NWYxNDI3NjZkMjQ2ZmQzYWJhZmJjOCIsInRhZyI6IiJ9','eyJpdiI6InFFcWVKcStvNGVXUnZQV3dCdzE0YXc9PSIsInZhbHVlIjoiOE9YWFRaMWtxTGVSUTRhZ2RpTkpiQT09IiwibWFjIjoiOGVjYzQyMmFhYjU3ZmI5YTczNTg4YTg4OTU2OGFlZThkNjY5MTYxODkwZjM3NDY1Njc2YTBhMmQ1OTRkNzU2ZiIsInRhZyI6IiJ9','eyJpdiI6InVoNXpQWDVhb2dsbTZHMnJlTHUzREE9PSIsInZhbHVlIjoiUGZEcFFvaEJCZFRKTk9QUTJ5cGpmUT09IiwibWFjIjoiYTEyOWYzMGQzYzRkMzY2MzVkZDg0MmY2MTlhYzMxYWRhM2I1ZDEyNmFhZTA1N2MxMmMxNWE0YTg5ZWNmNGIzYiIsInRhZyI6IiJ9','eyJpdiI6IlNIVmROcUk0K1lsUzJtZzgrQlRrT1E9PSIsInZhbHVlIjoiY1dlNldzVW9PVGRScTJ4R2VPOGZyQT09IiwibWFjIjoiM2ZkMTNmNGRlZTE4MmFhNzYxNWU1MTRmNmQwYTJhM2Y4ZmY1ZmRlZmJjNzZjNjFjMmFjYmI3YzA0ZmEyOTdlMyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(3,4,'eyJpdiI6IjUzTWtxNGtYQnZCRGN2VlhQVmFSRGc9PSIsInZhbHVlIjoiNUhUNVB0S25JczNFOHV3OXpkL1IvUT09IiwibWFjIjoiY2JhOTk5NmNjNDU4NjBjNTA5YzcxMmZmYjVlMDdjNGE5N2Y1ZGJkNDhkMWY3OTJmMjg3MDA1YmM5NWYyZWIzNyIsInRhZyI6IiJ9','eyJpdiI6IjI5aVRYRy9neWVqc2hpY1RmV2VhUGc9PSIsInZhbHVlIjoidlN0NXJvNElJRmxYeVZDSE1rcUQ3dz09IiwibWFjIjoiMDZhOWRiYjVhMDhlM2IxZGYxNWJmNDE1OWYyYTljM2UzY2YyY2VhMWM4MTQ0Yjc1MTFhOGMwNjMyMzIxMTE5NCIsInRhZyI6IiJ9','eyJpdiI6IlpBNTlaV3F3VVRlWFVCNWYrZ2MyaHc9PSIsInZhbHVlIjoiOSt6SmJUNTg3THhWZDV6UGZoVUVIQT09IiwibWFjIjoiNmY2NzdkMDQxNzQ1ODZlMWY3YzgwYjhiN2IyMTMyNjViNTgxZWMyYWVjYzIyZTAxNTZlNDA0MDQyMTc0NWQ0OCIsInRhZyI6IiJ9','eyJpdiI6Ino2aUpKZ09ScGNZV2NBQmpSYkN2eGc9PSIsInZhbHVlIjoiakN3YUhFbURNaU8wUkNBcEhpZEpVdz09IiwibWFjIjoiZWZiMjc5ODA3Mjg1NDZmM2NhNzZhMjA5ODQ3NzY1NzQwZWYyMjM4ZTgyNDU4NWY1ZWM3NjU5YzA5MTRlNzU1ZSIsInRhZyI6IiJ9','eyJpdiI6ImdOM0hZSnZ3TEUyVDFUNGNrWmN4R0E9PSIsInZhbHVlIjoiU3BQSUt6U2RxL1VTRkI5V0VWc3pJUT09IiwibWFjIjoiZThiMGE3ODgwZGE2NmE5MGVhMDA0YWRmMTExMjM0Y2U1ZDgxNjYyYzM5MzFiOGE2ZWIxNTA2MmU3NmY3Y2E2NyIsInRhZyI6IiJ9','eyJpdiI6IlNFVEZPaCtCMkFFcXNOYjNnNjJOcVE9PSIsInZhbHVlIjoiRWFkRE9tLzVnbmdoVnNSdG9kbFdJUT09IiwibWFjIjoiY2Y3NzJmZjRkZjAzNzZhYjZkNjZkODVjMTM3YmJmNTQ3ZGNiYzQ1MGJhY2NkMGVlODJiZDMyOWY3NzMzOGQzNCIsInRhZyI6IiJ9','eyJpdiI6InM5UGs0VzZXc2dtSzhRNUV6MWNmblE9PSIsInZhbHVlIjoiMGp1UEhlTWNTcWFoODhEdmhiR2xlUT09IiwibWFjIjoiNGY4N2JhZmJlZTZkZTAzZmQyZmM4NzYwNmJkYzE1Nzg4MGFmYzFiOGU2N2JlNWFiYzkwMzJmMWUzOTIxMGM2MiIsInRhZyI6IiJ9','eyJpdiI6Im5aZjVjTmM1QVI3SmhHdWJjdzNtT0E9PSIsInZhbHVlIjoiRkVGVVp4V014bGxkejJuMWdXMlhkQT09IiwibWFjIjoiYWFhMWFhMjY3Y2E3NGYzMTdjNTJhYjIyOWZkMGM4YTUwYWNmODA1YjRmYTg2YjNmODUyNTQ1NzQ1MzYyZDllOCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(4,5,'eyJpdiI6IlhZS1lvaEpvV25BVVF2K3lTNUJ6WXc9PSIsInZhbHVlIjoiQkJHb2xLdDZmeHVMNW1rRmdzUDUzUT09IiwibWFjIjoiNmM5OGY0OGY5ZDhiN2FiYWYxZjRlMmNkZTdjMzY0ZWQ5Nzc1ZmQ3ZDg3MDFkOTNlN2I0ZjU1ZTE0MzAzMTZiMiIsInRhZyI6IiJ9','eyJpdiI6IlFsQXVNVEloY2hsT1BabFMyMDJReUE9PSIsInZhbHVlIjoiOWJXcDgrL3FOQThQb3FKV21Jc3dpUT09IiwibWFjIjoiYzM5YzY1N2ZiNmRmYWQ2NWU2NzY4NmExZDhiZjVhYTZhNjJmNTdjNjFlM2RkZWIyMzlhMmY5NzdiMjM1MzM0NCIsInRhZyI6IiJ9','eyJpdiI6InNlR0VFa1M2TUdTZkh3b2FKb3ByUVE9PSIsInZhbHVlIjoiaVN2YkU2R3dkQnNTV1orOGE3TXVOZz09IiwibWFjIjoiMjAwM2E4MzU5YjRhODMxNjYzNzQyYjcxOGY0MDJiOGFkMDE3MWMxNGY0MzYxMTA4YWMxZjViMTg5YzY2Y2IwNiIsInRhZyI6IiJ9','eyJpdiI6ImYwc1NiNk9sczg1NWZVcnRMQ0JkblE9PSIsInZhbHVlIjoia3FnM002eUYzVXAvOWdNbFZDSnpqQT09IiwibWFjIjoiNTBhMzhmYjliMGE5MDNkNGRmODAzOTg1ZTE2NzZhNWM4YzI4YjZkZGNkNjA2MWVjYTgxNGI4ZTMxNTM4YmI1NiIsInRhZyI6IiJ9','eyJpdiI6IlR5UkJZL1ZhU1RBRG5TOFZFb1RWS3c9PSIsInZhbHVlIjoiVGM2emUwRVNoMjBtM3Z0Skw1cW9GUT09IiwibWFjIjoiM2EzNGZlYjNiNGVkMGUxZTQ1NGQyNWEyY2MxZGMxZGQ3MTZjZDY2M2Q1ZmZlNDAzYTY4OTk4YzczZTcwNzc1YyIsInRhZyI6IiJ9','eyJpdiI6IkphMStXOE1KUUxFOEl6eWtweHgzanc9PSIsInZhbHVlIjoiS0l0TlBrVW5qVlEwbDltb0xVaTNQZz09IiwibWFjIjoiMThlOWQ3MjVhMTlmYjRiYzVkYjk5YTE3YzQ3YzUyZGQ1MmVhODc3YWQ5MzljYTJmOWI5M2NiOTc5ZDg4ZGE1YyIsInRhZyI6IiJ9','eyJpdiI6Iml6Ym95RnBqVzIxekJNQzdpQjFVWGc9PSIsInZhbHVlIjoiOHpsZDhrd3F6aEFXcG54Z2pIMEtaUT09IiwibWFjIjoiYTQxNDM0M2ZjZGY4NjMxNWZiYzVjMjVkODQ2NWVmYWNhZDA5MDA4NWM0ZGM0NDQ2NTk1ZDI5YmJkNzg5ZDZmZiIsInRhZyI6IiJ9','eyJpdiI6IkZFS2RkQlFSWWZralErZm8zZzFXSEE9PSIsInZhbHVlIjoibXdUeTRlWERLVy9aQjlibkxIYU5VZz09IiwibWFjIjoiZjllNjZkMTY5YTkzYmU5ODliYTdiZDFiNTY3NTk4N2Q3Njc5MDQzOTZlMTliODBhYzRiMmNjNWJjY2MwNGNkYyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(5,6,'eyJpdiI6Ildvby9sc2NJVGtpQmFDaDlkMzNKNFE9PSIsInZhbHVlIjoiVWQydFdGRkR0NDhWYTVBeHkvenlpZz09IiwibWFjIjoiZmNhZDU1ZDNiYzk4MTZlMTdiMzNhNTA1ZmQ3YWFiN2I5NjUzNjM3ODg1NDRmMmY5MDRhOTIzMDljMzg0YjJiOCIsInRhZyI6IiJ9','eyJpdiI6IjBKbHEya0NjM0hRMUNJdzZlUnliVXc9PSIsInZhbHVlIjoiazlRaS82RldmQW01akY5V1l1UWxWZz09IiwibWFjIjoiMDk2ZTQyZDFlMzc0NGFkY2M3YmM3MDI4MjEwMTViZTQ0ODY0NjkzNGVlMjRmZjMyODVhZDg0YTRhOTBjNzJjYyIsInRhZyI6IiJ9','eyJpdiI6IjNvWXJNUngycEpRU3dkUlV3K3B3eGc9PSIsInZhbHVlIjoiQnRjTS93VU5BT204R1d3ZzZ6Q0F2dz09IiwibWFjIjoiMThkZWVlZjdmYzBhMzE1YmM1YzJmNmMyMzE3ZmZiNWFjNjdhZWJiM2NkNzliYjFkOTg2MjYxZDcwMmVjODRlNSIsInRhZyI6IiJ9','eyJpdiI6IitpUWpaZDFXSjJ4VC8weXNQZ0ZEVlE9PSIsInZhbHVlIjoicEc3LzIySTNONUxCZ2tCSFd0OWlZdz09IiwibWFjIjoiMGMwNDg2ZTM2NzM5OGI2MjliNzQ1MmFiZGM0NmViZjVhMDNhMmQ0YjBkMmI5ZjlhZmYwMzA0OTQ3YmNlM2JhNyIsInRhZyI6IiJ9','eyJpdiI6Ijg3MlhqNnR4bTRGRzV3cXN0T1JYWGc9PSIsInZhbHVlIjoiZzVOd3JQbEhiYmZPdTF0UlhhaGdHUT09IiwibWFjIjoiOTNhYTk3OTcxMmMxODU2ZmI3MjNhMTIyMjdkOTA2NGQzN2ZiNDBmMzdhMzE5MWUzNmUxN2UzMDZiMGRkMGNkOCIsInRhZyI6IiJ9','eyJpdiI6IlN6dEJkQ0RrYTAwaEZKRDVCZmlDZHc9PSIsInZhbHVlIjoiWTFncHpRMGdnMDRsYUNhZVF0bk5ldz09IiwibWFjIjoiN2Y2ZmNiMjg1ZWE3MDQyYTQzOGQwODcyZWFkMWE0ZThiMjY2MzgwMDIyYWM2ZGRkZGUwZDkwYzZjNTEwOWRlMyIsInRhZyI6IiJ9','eyJpdiI6InhQcDk4eTVpcWNRcTk0d2x3VVFIaUE9PSIsInZhbHVlIjoiWXFyTHVNVCtjRjd4b2UzZFNHVWZjZz09IiwibWFjIjoiODU5MWFiYzE3NDhkODA5Y2U5ODUyNzg0YjU0ODdjNzk3MjA3YTI4OGM0YTAyOTgyNzllNmZjYzQzZDllMTI4NiIsInRhZyI6IiJ9','eyJpdiI6IngxT3FqakxsNWFvSnVRUHB5QTlOaHc9PSIsInZhbHVlIjoiOWgrZUxDREI3eHEyZzdFMXd2NjkxQT09IiwibWFjIjoiNDcwNDc1NGY2NjY1OTdhZTA1OThkYWJkNGQxMjllNjJkMTUyNTRjM2NmZjliM2MyZDVkYzhlOTE4NDE3NjYwYyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(6,7,'eyJpdiI6IktyVzJFQzNsRlVoMXRmUUY0VlFqL0E9PSIsInZhbHVlIjoiKzQ0WGNMaEZrYlMvQ2UyQU1MS1h2dz09IiwibWFjIjoiNzNhZjU4M2E4OWRlZjk0ZWNkMWVkMTQwMDE1ZjA3MDcxMzQzNTYzMTRiNzgwOGY2MzdhNWE5ZTkwNjhmZDk4MiIsInRhZyI6IiJ9','eyJpdiI6InVONXNVaG04VXAwcDlSNGJzaCtCRHc9PSIsInZhbHVlIjoiVFVDdVlmM0FHODhDNTJubXgxa0EvZz09IiwibWFjIjoiZTY3ZTIwNjU5MTNhYzE4NzE2YTI0ZTU5NDAxYzdjYzExYWU2MzYxMDliMmFjYmFhZDI2OWQzN2UxYmY3MjBiMCIsInRhZyI6IiJ9','eyJpdiI6Ik1jRHZDOE5waUZxMkN6VWowWHptSmc9PSIsInZhbHVlIjoidldHT1kzTjNZM0Y1K1pNdVExZjh2QT09IiwibWFjIjoiZDM2MTZhMjI4NzNkNGM3ZWE5Y2UxMmNlNjAyZWUyYzBiODkwMTYyOWJkZjQ4MDc2YWI0MzA1MTNkNzFmOGFhNiIsInRhZyI6IiJ9','eyJpdiI6IkxVUURIVksxalVaSmVBZ1B2dHI4T0E9PSIsInZhbHVlIjoiWjM2eUJ5dmFvTmh1UXpvTkd4SGpCUT09IiwibWFjIjoiNTc3MTBlOGM4MTQwMTIzOGQ3ZDI3ZTA4NjhjODRhMWFhMjI3NjUyZDY0NThiNTJkNGJkZmY0MmJjMTEwZWIwZiIsInRhZyI6IiJ9','eyJpdiI6IkN2dGRsdlhabitsUTNPV2JOYUZ1TFE9PSIsInZhbHVlIjoiaGV2Y3h0UTJCVlFiYmU3VWlMTHFDQT09IiwibWFjIjoiZjQxMjUyZWE1OTNkZmNiMDE5MDE4YzQ1MTYzYzAzZmUwOGJjZjllYzZiYjA4ZTE4MDVmNjA2ZmVmNTlhZjkxMiIsInRhZyI6IiJ9','eyJpdiI6IktYNkJvdXdGY1FVNW9ZcVMvUFBYT2c9PSIsInZhbHVlIjoicnNpRmRsK0FsYjQwNzFVcGVOVXZNZz09IiwibWFjIjoiYTViZTlhYjBkYzIzM2ExYTgyZjIyYjY5YTZlY2I4Yjc5NzQ0NTk3NWNjZDkyMjY4MzQ0NzJiNDlhMjFjMTQ3YiIsInRhZyI6IiJ9','eyJpdiI6IjI0NDdIR2xTMGdQQS91UmpCVldYMGc9PSIsInZhbHVlIjoicGlIZDBEdDZRYWZZOXlIMHY1N0hpZz09IiwibWFjIjoiMTQ0OThlNGY0OTJlNDAxZmFmMTkyN2YwMGNjOTJjOTk1MzNiMjZlZDY3OGEzNWYyNDQ1ODhhNDQ1YTBhZjZjMSIsInRhZyI6IiJ9','eyJpdiI6Ik9GWGFKVXNVSjlFbFY5K2JQem1GS0E9PSIsInZhbHVlIjoiVThtblFaWFpFTHpibWQxUVBqYlEzUT09IiwibWFjIjoiNzVhYzlmNjZhYzIxZGQzMWYxNGFjYmFjYmUyZjRiZThiZTA4YjEzZTdjOTQyMTU1MTRmMTcxMGMwNmYzODRlMiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(7,8,'eyJpdiI6IjFnUmlOUkRvbUhsK0JLbWZHbHp0bXc9PSIsInZhbHVlIjoiUW5iOFZBWTNjNi8zQS9wWVlHWElQdz09IiwibWFjIjoiNTNjYjQzNTFiYjc4ZWJkMGVlNTgzZmUzM2I0MmZlYTEzZmE0MGY1MmU2NGM5NjAyN2IzM2MxYjE4M2VhYzAzOCIsInRhZyI6IiJ9','eyJpdiI6Im0vMk1CSkJ2b0dvYVI4cTQ4ZjhFMnc9PSIsInZhbHVlIjoiR1pVYytJNTB3NG80Q1NxVDdISFhOQT09IiwibWFjIjoiNjU1MzRkMDFhNjA4Y2MwMzViNzIwZDNjNGMyOTJhNTU4NzYxYTE0ODRkMTBhYWI1OTBhMDA4YTBjZTM2Y2FlMCIsInRhZyI6IiJ9','eyJpdiI6Ill5K25wMmxzNkJvZUNtdmp1YXNmckE9PSIsInZhbHVlIjoiMEtlTjlsMFlPUzhMc3ZzVkxiY0oyQT09IiwibWFjIjoiYTY1Mjk4ODM3M2VhOWQ0YjFlMDMyZDdjYzQ4NzZlNTlhNGI4NjQ0Mjk3MmYwZjE5YzhjMGMyMjhlMDJhMzBkYiIsInRhZyI6IiJ9','eyJpdiI6InNZNW15SmlYa3dzTGlMNFRkbFBoN1E9PSIsInZhbHVlIjoiZytrMG5PYTNGZHlFckRsbFd6QVBNUT09IiwibWFjIjoiYTk5MDAwMTA1MTk5YjVlOGNmNTQwMjIxN2VjMmI3M2Q1YjU0ODVjODRlY2U3ODg2M2U2ZDY2NmRkZDA0OWY4OSIsInRhZyI6IiJ9','eyJpdiI6InJ0aS9hZEROZjQ0TmNqbVVWOHYxL3c9PSIsInZhbHVlIjoiVGlUN1FrRk9iSElWa2pEV2VMQjlidz09IiwibWFjIjoiNDk3ZjQyZDAxMjI5MWYwNTNiNWNmNDJjOTc2NmRhMzA5NzI5ZDllOWEzMDM4ZDQxNTAzZTA2NjM4YzBhNDAwZiIsInRhZyI6IiJ9','eyJpdiI6IkZtcXBjZFFOcms3N25WMVIySGZZYUE9PSIsInZhbHVlIjoiZjdPOFl6NUFReVNKSm1IeDdKdkhhQT09IiwibWFjIjoiOWU0ODM2OTgwNGFkNjE2ZjE5Y2ZlOGE3OTAyZTMzY2Y2MzZjNDUyODQ1NjA0MTU3ODUyZjU5NTI5NzE0MjhkNyIsInRhZyI6IiJ9','eyJpdiI6InErcWk1S1ZIZit1THhkNGRsVVAvT1E9PSIsInZhbHVlIjoiS2U5eGI5dzByQUxCNFNVSnhhZ0tOdz09IiwibWFjIjoiOWNlNDZmZTkwOGU3ZTQ3YzY0YmMzOGRjMWUzY2I1NWYzZDJhNjRiNzgzMmJmYTQ2OTZlYjUwNjZlMmQ2ZGVlMSIsInRhZyI6IiJ9','eyJpdiI6InNjVkpqM3hkYlNtRDZWM1pPalowSHc9PSIsInZhbHVlIjoiL0FXTUx5NXBqSDBqMElySDFCOEZZdz09IiwibWFjIjoiOTBmOTQwZDVhMGI3YjhkMWMwMjYyNmE2NjgxZTU2ZTA2OTI4OTIwNjg3MGQ3YjQwNGE1ZDRjYzYxMzQwZWQyZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,9,'eyJpdiI6IjZKbWtUcGdCai9TYzczQXlzNS9Ga0E9PSIsInZhbHVlIjoiRzdiUXE5OXlEYXEvcUVLQTAwN3ozZz09IiwibWFjIjoiODI3ZjM1MjlhYTI5MWEyNmY2MzYwYmJiNjFmMjU5ZGY5YTM3NDgwOWE2MDA3MGMzOGM4ODNhNmZmODVjY2YxZiIsInRhZyI6IiJ9','eyJpdiI6IkQwV2ROTFhxNWR6NUxwR1dLMlFiTGc9PSIsInZhbHVlIjoieDMrQkppdGNzVFNQZExkd2tpTXR2UT09IiwibWFjIjoiMmM2OTVmMDNlZWMxZWNmNGMwYmE0ZWVmM2U2MDQ5N2NkNjY5NzZiOTNmYzMxMWNlNDI0MzY1NmI0NTA0ODJmNSIsInRhZyI6IiJ9','eyJpdiI6IlNmeGZuUGNINTduNEVzKy9aNmdPVVE9PSIsInZhbHVlIjoiaUZaRDkzdXhteUNGUmVDYzNVanI4QT09IiwibWFjIjoiZTU4ZWQxM2M5MGM1OWNhZjA1OWQ1ODQ4NjdiYzMzY2E3OTllOTM2N2FjNGRkYjEzMmU5Mzc4ZDNlNDJjNWNjNiIsInRhZyI6IiJ9','eyJpdiI6InBvNVI0TXVJNnIxbE41ak9RZURuWmc9PSIsInZhbHVlIjoiR0pyNlRnV0owVmFUZWVOaDhXVnBOQT09IiwibWFjIjoiMzNlNDc1M2NhNzlhMGNlMDBjZjE5NGEyODI4ZGIyNTQ1OTVjNTNlMGU2YTU5MWZlNGE3OTk0N2YzOTNkYjJmMCIsInRhZyI6IiJ9','eyJpdiI6ImMyOXVFZTJNT1IrRElNb0J1bk5FT2c9PSIsInZhbHVlIjoiaDlaRW5QWXNLZVF5b08wbWwrZmpqZz09IiwibWFjIjoiNjdmZTljMWM0MjA1ODcxZjNjMzgzYzdkNTMyMTJkMjFmYzVlZWEzNzE0N2VlMDk0ZGZkNTMwMTc0ZGViOGY2MiIsInRhZyI6IiJ9','eyJpdiI6IkVUTTFYNVB2bTlwaUZoQWNEZHdLVlE9PSIsInZhbHVlIjoiNVh5L0lxZGNyZ21BUzFsL2V0UFBNUT09IiwibWFjIjoiNWE4MjhjYmI4YTEzOWMwYTUyNDRmMTBlYmI2MTY4NTc0YjAxOTI5MDhlZjRhNGI3ZmEzZjJhYmNmZDI3YTQ3MiIsInRhZyI6IiJ9','eyJpdiI6IkJsbzNCTHlvQlVwRFVRQ2hFOFhTQWc9PSIsInZhbHVlIjoiVjFJR3lKRmNrbUlUaDBtTC92Z013dz09IiwibWFjIjoiYjViYjNkOGUzNGJlODkzNzlmNWIzNzllZGRkZjhkODExYjU0MzNmMzQwMjZiYTc5ZjU4ZTQ0MmVkM2I1ZjQ3MiIsInRhZyI6IiJ9','eyJpdiI6InBDOS82K08wbHJRRDVFQzlqRjlNOXc9PSIsInZhbHVlIjoiRDluU1FkajZkb1FFbU5DbjFYU2pVQT09IiwibWFjIjoiMDM4MWIxYmY3MDBlMjE3YTVmZDkwOTk4OGRiYzUwZGZkMDMzMjAzZWYxMmQ4NmI3Y2YxNDlmNDVkMTc1NDFiMyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(9,10,'eyJpdiI6ImJKang3ak1DYWR1L2ppUnJEcU40SGc9PSIsInZhbHVlIjoidVBJY3VJVVpCRFJTSDh4ZTJZSUhIdz09IiwibWFjIjoiM2IwZmNkNGJkODFjYjExNmRkZTBkYjFiZjMyNzc1ZDhlYzhiYTQ2ZDBkMTM5OTRjNWZjOGJiMWM4MDA5NzQ0ZSIsInRhZyI6IiJ9','eyJpdiI6IktNRE5qZUVoNkZpMnU2UURFUVB6S2c9PSIsInZhbHVlIjoia1JmcUd6Rk5LTzVkTjQ3RlNYdWNXdz09IiwibWFjIjoiMWQ5ZTZhMmE3ZDljNTZmZTk3ZDc2MmMyZWQwNDIwMmNlMmNkNGVmNzBkYTJjNDU0NDM4MGY2YzYzNzMxZTQ1YSIsInRhZyI6IiJ9','eyJpdiI6IllqRDhrK0FPdTlXbmJvb0k4Mi9nYnc9PSIsInZhbHVlIjoiVFNyalFkdndTS2hVUjRCVzZua01RUT09IiwibWFjIjoiYzZkYmZjODZlMWE2ZWIyYWY1OTljZDM5NGE5Njk1NmJmMmY5NjYwMjE5MzBmNTBkYmQ3MjNiODZkZWFmYTcxMiIsInRhZyI6IiJ9','eyJpdiI6IjRhQ3owTWxaUUhPeTFxU21aYlMwWVE9PSIsInZhbHVlIjoiL3RZT0JBa3pMVkxWUyt2RjUrb1FQdz09IiwibWFjIjoiOTVhNzA0Y2IwNmYwNjE4N2M5YzE2NjVlZDAwMDgzYWEzNjI5NjAyMTRjMzEzY2VjNDQ0ODc3MWU4MjMwNWJkNCIsInRhZyI6IiJ9','eyJpdiI6IjBRRGhwbWVWV3NBbnFjd1FSbHRXd2c9PSIsInZhbHVlIjoiYk5ZYXJuRUhEc29TRDdjdXA1dVprQT09IiwibWFjIjoiOGJjOWQxOWZmMmYzM2M0ZTg0ZTQ3NTM2NTc5M2QwNDNhN2E2NWQ0OThkNDdjNWExMWI1ZGE5NzI3ZDUwZWQxMyIsInRhZyI6IiJ9','eyJpdiI6IlF3QkUvUVA3alVkZXZpQlpsOUNqd0E9PSIsInZhbHVlIjoiRkI5Y0V5VjN5T2w2dmpoSVVaczZaQT09IiwibWFjIjoiODVkOTYzOTEyNWI2MzZkMDJiN2YyZGEzOTk1N2Y2ZDlmMTcwOTcxMmY3NGRlYTAwNmRmM2UwZDFkNjA1ZTU4OSIsInRhZyI6IiJ9','eyJpdiI6InVxTW1ZbGR6V21XU1RBNHB4aVczY1E9PSIsInZhbHVlIjoiK1NVaG5QeW00VCs4WjRUL1ZwY2JhZz09IiwibWFjIjoiNzU5YTIyOWYwMWMyZTVlMmY4NTRjZTkzMWY1YzAwYjlkYmM4YjRjYmE1YmZkMDk4ZGY0ZWZkYTcyODlhY2MxMCIsInRhZyI6IiJ9','eyJpdiI6IklhT1ZBYWx3OUVOcnByS216UFBnV2c9PSIsInZhbHVlIjoiK0tWWEZneUIvb3dnZ3dlbDY1UXV5dz09IiwibWFjIjoiNzkzZDk4Y2EyOTNiNzVmNmY0NDgyN2E4NTZjOTg3NmM2NzA2YjkwY2Y5NTcxNzk5YTNiZmJlODA3NDk4NmNlZCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(10,11,'eyJpdiI6Inl0MW4yenNjT1JLT0FQeE8wdG5DY3c9PSIsInZhbHVlIjoiVWRiQ25EWUN1VDBrMnBLdU5IV3Erdz09IiwibWFjIjoiNjZkOTkzODFiNGMyZTBlZjU2OWQwYWNkMWViN2RmZDJmNGVhMTU5OGJkYWIzYjU5ZTEwMjk1N2MzYTEwZmU2OCIsInRhZyI6IiJ9','eyJpdiI6ImxlYUJjcEkzZ1duY2w4NWlVSjEvRmc9PSIsInZhbHVlIjoib1pEV0FrbXc4WW83R1BSbWZpeEZwQT09IiwibWFjIjoiOTM2YWI0Mjc1YzBmNTllZjI3MWNmYmMwNWZjMmZjZjM4MjI4ZmNmNzc3MDFjNDU2ZmVjYzJjYzI0ZDZkMzRkOCIsInRhZyI6IiJ9','eyJpdiI6IldKeEpsOERYL0dONlFXeld6dCtFMXc9PSIsInZhbHVlIjoiSm1ST04vMUVqUkNJUFIwUCtaL244QT09IiwibWFjIjoiOTI5MTVlYWRhNWM3NGEwNzhhN2E0N2Q2NmZjM2MzY2E1ZTE1MmU0Y2Q1ZDY1NmZkOTMzMGQ3MWU4ODAzMzQyNiIsInRhZyI6IiJ9','eyJpdiI6IlRIdENDNEhZQXA0ZCtSZ3JnN3lpclE9PSIsInZhbHVlIjoiSE14RVlnd0t2akwwcXkycWc4NkhQdz09IiwibWFjIjoiZDRiNDJjMDJjOWYwMzQwZjUyODQwMGY3YTViMTNhMzU5M2EzYTAyNjc5NWVmN2JmNjkxMDdhNzZlMmQ1Y2IxOCIsInRhZyI6IiJ9','eyJpdiI6IkV4RGFWb1hlMzAxQlByQ3BnVXdseWc9PSIsInZhbHVlIjoiZzlrT0ZlbTF2ekxtZTFMYlRHU1R0UT09IiwibWFjIjoiMTA4OGFiMGJjNmEwYTY4YmI4NDg4NzEwOWM1ZWEwMjVlYWE4Y2M0NmRiZmRhNzM3MDJjYmExNGU1ZmQ1OWJkZCIsInRhZyI6IiJ9','eyJpdiI6IjB3bFpnYTF6ZnRTb0JkMjM3d3FISFE9PSIsInZhbHVlIjoiSUd1MUpOQ0hYVlEyb2Z6R0tnSFBUUT09IiwibWFjIjoiNzRlMTk2ZDZiNDJjMDc2YjBhYmZmZDk0ZDhkNGY5NWFhZjM4ODFhMTEzYTIwMGM2YmNhNDVlY2U1MDdmMDA1MiIsInRhZyI6IiJ9','eyJpdiI6IjVXS1VheVBRSzgzU0xBK2IvRzNqTnc9PSIsInZhbHVlIjoiM2xFNkRQVzk4VEV4cWdvVndaaWkxQT09IiwibWFjIjoiZTM2MjYzMGU5NzNhYjM1OTdlNmU2NTc4OWE3Zjg3OTVlNGU0NjA1MzY4OGQzZDdjOGIwMDY0ZTU3NzYwMGNhZSIsInRhZyI6IiJ9','eyJpdiI6ImhmczFBWjB5cmhINDJBNklvcGs5aXc9PSIsInZhbHVlIjoiT3V5OTU3bGdKWEFGL1ZVWlRITE16dz09IiwibWFjIjoiMjNmYmZiNGFmNTEwOWEyNzM1MWJiMjMyMTdkNjcxYTU0NTg5MGViYTZmYWQ2ZjIwODQzYzk2ZGVmZjQ4NWIzOCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,12,'eyJpdiI6IlhVRnExQ3IzVDQ4U3V3aExGM3pBa1E9PSIsInZhbHVlIjoiVGpVaDVLVkM0aGZFUXl3a1l6Zis1dz09IiwibWFjIjoiZTNmZTQ1OWY4YjUwMjljZmNjMDY0NzBiNzE1NDBhOTlhYmM3NGIxZjg4OTk5YTBlNDFmMTM5ODU5NzU5YjgxMSIsInRhZyI6IiJ9','eyJpdiI6IjJzaURlVjZYb0V2R1BUajRUL1kyY3c9PSIsInZhbHVlIjoiMFJsc0RYbEprVGVpRjZZd1BPR3JIUT09IiwibWFjIjoiNGU4NTkxZWRhYjQyYTZjN2Q5ZmRiMjU0ZDQxMTVhZWE0YTE2NTI1ZTBkYjJmZDYzNjE3MDlmY2E5Nzk0NmY0YyIsInRhZyI6IiJ9','eyJpdiI6IjZGbkRQZ1ZzNWZ4YWZmU2hrYmJpV1E9PSIsInZhbHVlIjoiVEV3cGRGRzR6NGFZd0FTWHhxUklMUT09IiwibWFjIjoiNjZiYzQwMTcyZTNjMDY3MjRiMWMyMGQ2MDIzZDc3Nzk4Zjg0NTNlOWRkMDNkMjg2N2Q4Yzg3OGMxNmMwOGQ1NCIsInRhZyI6IiJ9','eyJpdiI6InhJRWFCSWlFQjR4THdvQ24wVDB3dEE9PSIsInZhbHVlIjoiSjQ5cUptZVFuY2FRZzlDK1BMcWFiQT09IiwibWFjIjoiYzhjNTVmMTk1ZTU5Zjk0YmRmNzdkYzA3NjI5YjAxNjAwZjI3NjAxNTExMmQ1MmI5MjY1MjZkZTMwZjVkYmNlMSIsInRhZyI6IiJ9','eyJpdiI6Ilh6cXNQdEVnbDFDRWJTakVsWnllVUE9PSIsInZhbHVlIjoiQ09BTTVmNzhEVnVsQ0p6MUpKV2pOQT09IiwibWFjIjoiZGFmMTY5YzQ2NmMwN2YyYWQ1ZGM1YWQ1Mzk4MjY1NTAzNDNkMGMyNTEzZThmODhmZDU0MzFhN2YyZGU2ZWUzNSIsInRhZyI6IiJ9','eyJpdiI6IkxtZXNtdHpxMngyWUZ4endqZTBvM1E9PSIsInZhbHVlIjoiSGtDbSszYUdIUTFsZ0o1Z1ZwUU5Sdz09IiwibWFjIjoiYWFiMTgwZTBhOWQ3YzQzYWViMDY4MjEwYmRkY2ZkZWVlNzJjNjQ2YWJmNTgwMTQ4ZDQ3MTg5MjViYTQxOTAxYSIsInRhZyI6IiJ9','eyJpdiI6IjBQTElWWHlSQTMrcDhueTkzUXFFVXc9PSIsInZhbHVlIjoiKzdwYmhiZmw1OEZoMUtXMnBiWU5jUT09IiwibWFjIjoiNWMxZjFjMDc2YTczM2QxODJlMjZlNzU2NWVmYzg4NTcxODkyMzdhZWY4YTcwNjIyZmE1Y2QwOGVkZDY0OWY3YiIsInRhZyI6IiJ9','eyJpdiI6InFiaE83ODZNMDJVTWdvbWpEZW0xVkE9PSIsInZhbHVlIjoieHpzT1hZTUU2cWZJdUE2K1kzU0syQT09IiwibWFjIjoiYmFlNjMyYzM5OTc0ZWE5YWU5OWI3MzA1YWY1ZDRhZmE0MTNiZWJiMDM4ZDNkNTVhZGQzMjcxZDMwMWY0N2IwMSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(12,13,'eyJpdiI6IkR0RUc5NmRUUGQ2bVA2SkRucExHWHc9PSIsInZhbHVlIjoieEgrNjU3OFVuOWJ1L0VyckVJbEw3UT09IiwibWFjIjoiNTg4MDBhYjVjY2NlZmUzYjFiYmRmOWVkMmE5YjY4M2ZkNGQ1ZjA2YWQxYWMwMDMzNzUyMmQ3OGJiZGQ1Y2RjMyIsInRhZyI6IiJ9','eyJpdiI6Ikg2TmRqdHhiRTdIZ3N2K1lsUHlIb3c9PSIsInZhbHVlIjoiY3Vid0owK0djZnBGdktLeGQrRG9odz09IiwibWFjIjoiOTZlNDQzMTg1OTMxOTkzZWZlOWYxZDY3MzRhNzY2ZGMxYTk0MjRmNGY5Y2ZlZjExY2NmYjU5ZjI4M2E4ODQ2MSIsInRhZyI6IiJ9','eyJpdiI6IlBYcmFkK20zaVAxWHlqNWU2MXM0cWc9PSIsInZhbHVlIjoiNEtCSnVUcjRsNFBUNlFKZzdCWkNxUT09IiwibWFjIjoiMTZmNDZkYmZiNjFlMGQ1ODdmYWIxNDhkNmUwYzAzZjE4NmQzNjdjMjVmNGIyMzgwYTY2MzFiMWI1ODhlOWQyNiIsInRhZyI6IiJ9','eyJpdiI6IjVMSzdyaGNEWGRLY09sTnpRT1RCQ1E9PSIsInZhbHVlIjoiNTF0eThMZUtqNXViWlJLcnJ2TWdXUT09IiwibWFjIjoiNzRiOGQ2M2ZiZWNkMDJlYTgyYzhjZTZlNDA4YzUxZDM3MTk3OWMwM2RiMTkyOTNkYWVjNzYxNzlkZDA5MDA0ZCIsInRhZyI6IiJ9','eyJpdiI6IncrQzFoL1hCL3l4NEhaNTJsbm9Td0E9PSIsInZhbHVlIjoicmhObGNya2NuNDYxNm1CMWFhQ05HQT09IiwibWFjIjoiNjZkYTAyMzQwNDUyZjQ4MzY1MzM5OGE2NDE0OTA1ZmY1MmRmOTI2OThlNThmMDNkZWJlY2RjZWQ1ZjZmOGY5YSIsInRhZyI6IiJ9','eyJpdiI6IjFUc3dhQjYxMlFrM1NFd1JaZ1lQOVE9PSIsInZhbHVlIjoiai9kV0EzYm1TU1dtWkNpaHRicHhNdz09IiwibWFjIjoiNDU5MWQzNjYwZjQ3ZTAwZjk5MjNjOTkwODVmMWQ3YTJjZGMzZGUzMmZmMjM2MjRlMGM2MzEyMDU0MTg2Mjg2YSIsInRhZyI6IiJ9','eyJpdiI6InJPT2gvMll3YVg2YVBFRjRxUmFjSXc9PSIsInZhbHVlIjoia3BRK1JMbUNXSFNocE5Dek4xSTZwQT09IiwibWFjIjoiZjAwY2MzZWFhYjQyNWUxNzc1YmM3ODNlMDhlOTIwOGRmMGEwZDZmODBhNTA1OGFmNTk4NzNjOTIxNmJiNDcwNSIsInRhZyI6IiJ9','eyJpdiI6InRaZUc3eVAyNERhVnFlNG1qYyt1enc9PSIsInZhbHVlIjoid2NnUzZlUUd1bk1CeDNnZmp0Q1NLZz09IiwibWFjIjoiZWY1NjZkMTg3ZGMzMjM2YzQyMTFhOWU1ZWRhZTkyY2NkOWU2NWVmZTI5N2M3MWM4OGQyMGQ3OWNiNjlkMWEzZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(13,14,'eyJpdiI6Ilc4R0NKalBtYXRvUmFDZmY5UHM4ZFE9PSIsInZhbHVlIjoiYndPMTlXMXphUWQycTNhcmU2blUrdz09IiwibWFjIjoiOTRhMTFhMDQyY2JjMmQ5NDJmN2M3ODg0NmEyZTIyZDQ4YjdiMWM2NDM4NTQ1YTk1M2VjZGUzZjMzMjkxY2IwMSIsInRhZyI6IiJ9','eyJpdiI6Ino4UGJiZEJEcEdZN1lHcHRhVWpoTXc9PSIsInZhbHVlIjoiVjdMbm92amFySEd5Wks3bTZjUWFwQT09IiwibWFjIjoiYjA5ZWFlZDYwODNmYzQ0OTAxYjVlZjMyM2VlOTAyNGU3ZDI0ZjNhYjNlODg0NTZmMzI1YmViN2MxYzNhZmQ5NyIsInRhZyI6IiJ9','eyJpdiI6Ik9yaEhpRFgrY3NLVHZUYXE0QW8rUnc9PSIsInZhbHVlIjoianlXa3BuaFZEUmY2NlQyS2htVUZSQT09IiwibWFjIjoiNDQ5MjY4MDRmN2ExM2Q2ZGI3ZDIyYTBhYmZhOTgzYzM4M2Q0MmQxMGRhNzM2NTQzZmE4MmRmNTc3ZDJhMGVmNSIsInRhZyI6IiJ9','eyJpdiI6ImVZOWZnOHlLVU05QVBodzU1V3JjSUE9PSIsInZhbHVlIjoiem9qbzRPQVJZOU1VMkdSV2hPWG9aZz09IiwibWFjIjoiMjhmYzkyYzEyMDkxZGFkZTFjMDA0NGJmNWM1MzQ3MGQzMGUyMTJjNzcxODJhYWYwMzIxZTdmN2NhODQ1NThlOSIsInRhZyI6IiJ9','eyJpdiI6IitRQXJaa00xU3RvaDFEN2FNakJOOFE9PSIsInZhbHVlIjoiSTg5MklFRFRaL25UZnJ1QytLd09NQT09IiwibWFjIjoiODlkOWJjZTVhNTRiNWIwMjFlOWE0MjMzMWI2OTliYzU3ZDJiYmE5ZGIxODUwNjQ5NzI4NTUwMDUwM2JjZjU3NCIsInRhZyI6IiJ9','eyJpdiI6IkxSUFZBRzljK1VVZG1wT2cwd09GVFE9PSIsInZhbHVlIjoiUWlWbEo1VlZ2RVBJWFZCL0xZUjUvdz09IiwibWFjIjoiNTkxMGU0MzlmMWZkZThmNzhhNmVhNTQ3Y2M2MGFjNDNkZTUwNzJmZTcyYzJhODZhZGIwMDE3YmE2OGM1OWJhZSIsInRhZyI6IiJ9','eyJpdiI6ImVFNjZObTk1cXJ5a1Bvd2JneGFMTlE9PSIsInZhbHVlIjoid3hyaDJmSUpWdUQ5ODk5eTdXUUthUT09IiwibWFjIjoiYTcwY2I5YzRhNDAzYjEyOTQxZDc0Yjk5M2Y5ODc5ODU4ZTMzYWRiMWVjMGQ2ZDUyZTdkZjAyNzBlYzdhMGE2YSIsInRhZyI6IiJ9','eyJpdiI6Im5JU0lHdTNXalB1Vy9NRmNQV3pnd3c9PSIsInZhbHVlIjoiY0N0bnlQVFNEWEd3Z2tkYWxDWXVPQT09IiwibWFjIjoiYWI3NDM1MmZkY2RkZWI2YjhlMDQ0YTgxMDMyOThiMzc5MjQyYjNlYzA5MjQ1ZjBiM2JlOGZhZDM5OWM4YTI2MyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(14,15,'eyJpdiI6IitEQ0JHQklUU2dGNlNrZnFLK0hZUlE9PSIsInZhbHVlIjoiVmhLZ1FWQlpMVGg4Rk1oMDRUM1lVZz09IiwibWFjIjoiOGVhYzM4ZGQ5NzU0ZmJjN2U2NGJlZGE1ZjlmOTcyMDQ0YThhMDY0MDU2ZGE3M2VhYzk5MGJmOTAxOGM1MjBlNyIsInRhZyI6IiJ9','eyJpdiI6IlZxYjAyWXlqVEptQTI5anh6TGhlMmc9PSIsInZhbHVlIjoiWTN1anpZdkVMdUxkNnhNNG0zdStqZz09IiwibWFjIjoiZjY2NWVmYWE0MjM2MzAzOGYwNDYxYWY1OTE2ZWJiMjk5ZGJiODRiN2U5NDZlZjE5YWNkZDA3OGE0ZTUwNTRmNCIsInRhZyI6IiJ9','eyJpdiI6Ik9ESXhMcHZMd2tTcE13RHFDckFUQkE9PSIsInZhbHVlIjoiWFlYZDNJZzFJLzNWVVdvZysrSk1GZz09IiwibWFjIjoiOWY5NzNkMDVjM2Y2N2ZiNTQ5MTRmM2RiZWNhYTY2YjBhN2EyNTU2YzI3YTE3NzQzMTFiNTA2ZjUzMGFkYmZhMyIsInRhZyI6IiJ9','eyJpdiI6InBDMExaRzZVdWViU25mRGRHa1JwYkE9PSIsInZhbHVlIjoidUVRdXVxVU5uNlhJdmwrbFRPcnBFQT09IiwibWFjIjoiZDZlYTY5ZjNjMDRkNzU5ODJiMjAzYzU1YTM5MTdmMzAwODhjMGE0N2Q0ZDY3MDkwNTM1NDk5YzAxOWI5NzY2MCIsInRhZyI6IiJ9','eyJpdiI6InNKWUhaaTBsdGh1a0IyamxtcnQ4eUE9PSIsInZhbHVlIjoiWEpPVTBwcUVHRXZoMUVrT0o4TG9Wdz09IiwibWFjIjoiODg2ZjYyNTVlMjdiNzkyMmJiMjVmYzEyZWUxYTI2MWI1NmZjOGY5MTA2MzQ1MTc1YzIzNGE4MTg5OWVkZjIzZiIsInRhZyI6IiJ9','eyJpdiI6IldQQWFkVURheGMrTWlqMm9DUVRqVUE9PSIsInZhbHVlIjoiL3plaTN5VVNta21UakgzK0FPalNKZz09IiwibWFjIjoiNmQ4ZWNlODI4YjlmNmJjNzU0MGE3YjQzNmJjMTNhY2RiZjI4MTRkOWQ1ODE3Mzc5YTlhNjE0OGQ5MmZkYzlmNyIsInRhZyI6IiJ9','eyJpdiI6IlJmSlhtc0ZhaGorSVg2TTZMeFp5ZUE9PSIsInZhbHVlIjoicWQvODJkdUtzT2JYcWU4ZnQwaFQxdz09IiwibWFjIjoiNmZkNGM0Y2YzYzRhODQ0NjVmZGY5NGViZDBjZjgwNjgxNTVkMTUxYmVkMzI5MTMwNTI1NWM3YzU4NjcyNjM2MSIsInRhZyI6IiJ9','eyJpdiI6ImsrdmNXN0ljZDgzbWFzWlZtZWZwR2c9PSIsInZhbHVlIjoiZng4TnpNcHRrRkZRV0hvdEh4cUd4QT09IiwibWFjIjoiODAzOGViMWE1ZjVhMTExMTYwOGY4NWVmYzk2MDMwODI2MDMzMmJkZjBiOWYyNmEyZjdlMmU0MWJiM2JkZTNjOSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(15,16,'eyJpdiI6IlZiWTBzVWRON3V2Q2xPYVE2Qnh0Zmc9PSIsInZhbHVlIjoiZ0tPMkpPbTBUTmhXaldDYU9MVEhFQT09IiwibWFjIjoiZThiNGZhODE4ZWRhYmU3ZWE2NWYzZTRlMzljZGNiZGNlZmI4YTMxNTg4NGE3MzY2NGRlNmJjOTZiZTgwNzY2ZiIsInRhZyI6IiJ9','eyJpdiI6IjFTNGl1Q0c3aDlUbktTUkFiY3RqR1E9PSIsInZhbHVlIjoiOFFQTnJDVmJxU0lldkZKRUZxbU9KQT09IiwibWFjIjoiYzNiY2E1ZWM3MWM4ZjViZjAyZDQ1NmI3OTYyYWUyMmVjNWMzNjJlODYxYzYyODllNmUyMGYxYjg0NDRkOGFlZiIsInRhZyI6IiJ9','eyJpdiI6ImhCZlVRMWhrTTByZW85a241cy9aeHc9PSIsInZhbHVlIjoiQXpZclMwMkJrSlk5Q3N5UlkzemRpZz09IiwibWFjIjoiN2Y5ZGM1NzJlZmY2OGZmZDFjNjFhYTUxYjcyYmY0ZjJlMjAyYjBmYmJiOGZjMGNiNmE0MjMwOTlhZDU2YWMzOCIsInRhZyI6IiJ9','eyJpdiI6IjRBbzlQcS9iajd2L0JZWHU5Ym1HSmc9PSIsInZhbHVlIjoiM2NIQTZKY2ZFaG5IQlc3blFtcThaUT09IiwibWFjIjoiZDRlYzJkNzc5N2ZkNjlhOTYxZjAwYmJiNmExMThkYTEwOGMzNDMyMDYwNTg1MDM3YjJkOTg1MTczMGYzMDhjOCIsInRhZyI6IiJ9','eyJpdiI6IjVLVEFGTUJmQ2k5Z0Y5QXF3MVJXTHc9PSIsInZhbHVlIjoic0ZRQkRTOEhIcThNWlA0Y05UOEd5QT09IiwibWFjIjoiMzcwZmYyZjFmMmFhOTA4MmEzNjA0NjNlN2Y1ZjU1ZGEyYzgzMjVhNGE0MjY0OWQ3M2Y4MTVlMmVmNjk1ODY4YyIsInRhZyI6IiJ9','eyJpdiI6IjBHUkc2Ylg3QlZzWUhiaVRZUXMvbFE9PSIsInZhbHVlIjoiWDlGQWxNMTNKUHQzZnYrdHVkQnFiUT09IiwibWFjIjoiNzBjNjI2OTBjNjYyODNmNzg3OTQzMTI5ODFkZmYxZGMyODk2N2ZjMjM1OGU0NGVkYzhhMDNlYWI2M2JkOTI3NyIsInRhZyI6IiJ9','eyJpdiI6IjdWbkFFbWtLb1ROb2NxZ0lzeEdkVkE9PSIsInZhbHVlIjoiQWZ1QWVBUW5ENXVITVdFUkZRNWZhdz09IiwibWFjIjoiOTY2OTYyOTNlMTZjMzBmMmExODRmNTUxMjY5M2JjNDBjZGMzZGI1YTE3ZjI5M2JhNjQwZDJmNTVlZmU2OWE2MCIsInRhZyI6IiJ9','eyJpdiI6InJnUSt4SUU0RGJDaWJIVFdXT29ybUE9PSIsInZhbHVlIjoiUWovOHhQY2hrTnl2WkhHUUJUZmJaUT09IiwibWFjIjoiODNlYzdiYTFlMzUxOGE1MzZlZDFmYTk1MDM3MDY0NzZhN2UwMDE5MDM5ZWYwYzcxNTRhNzU0NWZmM2U1YzQzZCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,17,'eyJpdiI6IklXNlV4Z2s0VXpMODZMQkZGSWM2eUE9PSIsInZhbHVlIjoiSnM3bnpleFlmYkh1ZGZ2UytUZjJRZz09IiwibWFjIjoiNTE1OGI0NDdlZTM3MjU4MGQyZTI3ZWY2YzAwMjBlNjllMDIzMTk2NWYzZTQxNjFiYjEzYjYxNzgzODU5YzYzZCIsInRhZyI6IiJ9','eyJpdiI6InFtcXVJVXlmdjQ4ZDhhdTF1LzhpSmc9PSIsInZhbHVlIjoidFVFanJjNkdwb05jckxDQno2SVJxUT09IiwibWFjIjoiMDI4ZjdmNzJhMWY4M2QzYmFjYTFlY2ExMjBhNjU3ZDk1ZGJkN2U4M2ExNjNlOWQzNWExNjI3MWMwMGQxMTVlNCIsInRhZyI6IiJ9','eyJpdiI6InBaS0tCVUhjd3NmdXlVV1FTTTU5YlE9PSIsInZhbHVlIjoiN3pzMVBsb1VBNXdKd3VRalRwZWc1Zz09IiwibWFjIjoiNDQwMDg5NjEwYmU2NzgzYjI3MjIwZTBmZTE5OGFmM2Q2NTdiYTAyMGJkOGRjYjIxYzNmZTAyNGFkY2FiMzM1NSIsInRhZyI6IiJ9','eyJpdiI6IjcwMXRGb21vZHJUKytlYWZOaVRPUmc9PSIsInZhbHVlIjoibHUyWWFFdXR3T2VWRVN2clBaMnpOdz09IiwibWFjIjoiYzIyM2RlNTJlMzA1ZTA1ZDZkZDAwYmZiOGExMWU4Mjg4ODBkMDAxNzExN2U1NmQ5ZWQ3YzU5ZTE3M2VjN2U1NCIsInRhZyI6IiJ9','eyJpdiI6IkxnREpBcENjMWhKUUZMZDVGRXBWU2c9PSIsInZhbHVlIjoidi9haHZmM3RySDE2WWUyZEp2SENMUT09IiwibWFjIjoiOWIxMGQ1YmQ1ODU1NTAwMWI0OTM5MDIwNjc0YjFhMzgxOGY5ZGUzZmMxZmI5Y2VmMzhlNjg4YjQ4ZmI5NmU2ZiIsInRhZyI6IiJ9','eyJpdiI6IitaRm9KNDlEOTdSSFFNcUtqU2FyWUE9PSIsInZhbHVlIjoidU5aUWpMcVMybEVqNHg5YVFSbEI2QT09IiwibWFjIjoiOWNkODQyOWUwMjk4NTUwMjg4NWRmNWJmNWFmNGY4M2MyZGJhNTBlYmEzZTM1ZTM4ZjkzN2JjODJjZTZhZWZjNSIsInRhZyI6IiJ9','eyJpdiI6ImhSM29PQ0hJaGlVS2JmY3E5UHRRb3c9PSIsInZhbHVlIjoiL1FnNzUxdTRoMVJhWDJSTWJjU28rUT09IiwibWFjIjoiYjc2NjhhMDI5ZDNlZDcxZjE5ZWNkMzNlN2M5YzM0NTUwMTM4YjllOWMxNTQxNWY3OTNiZTFiYmQ1MWE0NTZiOSIsInRhZyI6IiJ9','eyJpdiI6Imh2bTN5T0lEM0NkdldtRkZQMkhyRkE9PSIsInZhbHVlIjoiVjhXK1pNNFNaRk13MTF0ZjdnWm1UZz09IiwibWFjIjoiMjhlZmQzYTg0NmI4MTgwNTFhMGNlY2IxZTY1NDUzYzE5ZjFhZWExZWU4YmVjMzdiOTY1MjdjOTk3MWRkMTQ2YiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(17,18,'eyJpdiI6InJQQ3kzOE42K1V4NzFRQld5VjFtRVE9PSIsInZhbHVlIjoiN3UzTFpHNktBTmw3UDlPVVFDMGhYUT09IiwibWFjIjoiNzM0Yjc3YWI2MzM1Y2FhYzI2Y2JkN2Q3Nzk5MDNjZGFiNmYxMGIzYjY3YjRlMjhjM2U5YzliMGQ3ZWVmNWJjZiIsInRhZyI6IiJ9','eyJpdiI6IlRwejFTR3pGSmorTU9sajZWcXU5aFE9PSIsInZhbHVlIjoiSW5XRHI2elpxWWNOck5FZHR6ZWsydz09IiwibWFjIjoiYTEyNGI3M2RhNGQ4MzI1NjBlODFhMDE5NzBjOGQ4MmI5NzU5YzYxZjcxMDZmMjY2NzMyOTc3N2IwZjg5NThkOSIsInRhZyI6IiJ9','eyJpdiI6ImY5eUZjMFVsTmxiK0lYOEtIWjYzeXc9PSIsInZhbHVlIjoiTDJWUG1XQ0ZKano0TEpsZTJackhKdz09IiwibWFjIjoiZWJhZmU0NzM5NWRlNmZhNjliZWRlYjNmYWJmMGFkNWU4MTI4YjI1N2FhY2NlNDc1ZDA1YzM1Zjg1MzNhY2I1NyIsInRhZyI6IiJ9','eyJpdiI6IkVzTjZ3ejRVL2ovcE55MUhUQ1Y2VFE9PSIsInZhbHVlIjoiN0x0aWxoS2tuWGZVTE5reFpWM2hldz09IiwibWFjIjoiMDQzYjUzZjI3MWUyMTJjNWMyMTIxMzQwNGQyZjA3MjA3NjljZTM5ZDI2NGQ0YWM2YmQ3YWZiZGFhMzJiYjg0NiIsInRhZyI6IiJ9','eyJpdiI6IklxQm0zeE1iMnB0T1dkTW56S0VjRlE9PSIsInZhbHVlIjoibmhVMHdhOXlVYTdLeUJTai9ldEhTdz09IiwibWFjIjoiNWFmZGFiOTQ5YTNjOWNmMjY1ZGIwZmRlYTA0NDM2NTk4Mjg2MDc5ZjQ3MGI3OGViNTAzMTlhMjE5OGFjMjE0ZCIsInRhZyI6IiJ9','eyJpdiI6IlZIcklxZmJMSzRaSkhNejBCaUVKbUE9PSIsInZhbHVlIjoiRnRyRUg0Zi9HYkhuOXFUN3Z2NEtxUT09IiwibWFjIjoiNWM1MGQwNzczNGNjNmE1OTg2NmIwOTAxM2Q0MjkzNDgzZjVjMjgwMjAzMDAzNzAwNmMzNGE2OWMzNWM4NjZkNyIsInRhZyI6IiJ9','eyJpdiI6InllT2hvS3FZb1NPbVIyOS92UTNXdnc9PSIsInZhbHVlIjoic1I1STZxdWZJQUpJdUk2NDZ1UVNRZz09IiwibWFjIjoiOGIxOGFhNTAwN2VhOWQ1ZTI4YWZlZjI3OTgzMTJkN2EzZTYxZTQ1YWFjZTI5YzMyNjAzOGYwZjQwMTBjMjg1MyIsInRhZyI6IiJ9','eyJpdiI6Inowd2xrQStZdUIvU29MVzlNNFZpVVE9PSIsInZhbHVlIjoiUloyQ1MrK1lENTJnSlZsSmVhbDNpdz09IiwibWFjIjoiOTAwNmQxZmMyNTZkNzNjMDk2Yjc2ZGI0ZmEzMzNhMGFlZDE3N2NlODk4YzIzM2JmOTA1MzMyMmQ5MjQzYTY1ZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(18,19,'eyJpdiI6InJkSXI3bHI2WlZ6c0t5RzF3elBLenc9PSIsInZhbHVlIjoialJCQzFNL3JhVDU5YjdReGdXM3FTZz09IiwibWFjIjoiMTdhNjg3YzY2NmMxNzI1NzU0MGViYWZjYzU0OGVjNzMyNDA0MDIyNWVmOTczMDA5MTAyZGVhYTYwMDAyMjJhMCIsInRhZyI6IiJ9','eyJpdiI6Imtvam9PK1lTczlrMDBCbVFhZ0syc2c9PSIsInZhbHVlIjoiQkhKdGthVSs2eXRCSXNPQ1FFLzlDQT09IiwibWFjIjoiM2UxZmQ2MTUwZjA2ZjgzM2MyZjJlOTk4NDVmM2I4YmM2ZTNmZjg5ODk3MzY3ZDkzZTNhMTE2MDk0MDNmMjg4ZCIsInRhZyI6IiJ9','eyJpdiI6Ik9JSXBtajgrQ1gwOGNqczQ0MG9KZUE9PSIsInZhbHVlIjoiVm96eEVRY0NKdHhhcVBLZmZVYnhDUT09IiwibWFjIjoiYWVhM2VhZjc5NjAxZjY0Y2MzNDgzOTljYzU4MDc5MzM3NmExOTliNTEzMjAyMjdlYmM5NTM5YzJlYWU5NTlhYSIsInRhZyI6IiJ9','eyJpdiI6InloaXBBQ0RURjNWQndzUXdLNjdIU3c9PSIsInZhbHVlIjoiL2tFMjV3cklLUGxzaUMvc0V6SlVTZz09IiwibWFjIjoiYzJhOGRmNjY1MjNmY2JjNWNmZjlmZDBkMzk1YzEyMWU0ZjVlN2IwMjAzOGIzZDRhYjkyOGM0ODI0NTViYWU2MSIsInRhZyI6IiJ9','eyJpdiI6ImxHZWQ1WEVxVkowSlZGK0JqZ1prckE9PSIsInZhbHVlIjoiRjd1Uk1sU1hJSkdtQ3RUZXR6QVlEUT09IiwibWFjIjoiOTc3OTE5YWQyOTY1ZDg0NGNhOTgzY2JhOWUzMzk4ODY4YTdlMjgyMWNiMjU4ZTE1MTY5MGI4Y2Y3ZmUyN2NiMiIsInRhZyI6IiJ9','eyJpdiI6ImZQU1RFY3QwN0tCTEFWQ1B6QmNZWmc9PSIsInZhbHVlIjoiUW9OSHZSRXUvZHFuNUY4WFAzSWs5QT09IiwibWFjIjoiZGE4MWI1MDQ0ZTZhZmJmMGY3YzM5MzdkMDljOGY5NThkNDk1ZDRlYTI1Y2FlYWJiYmY5NDFhY2RlYjdiOWZhZSIsInRhZyI6IiJ9','eyJpdiI6Im9YYVFmSU5FeG5KZ0Q0SWJvN3c2U0E9PSIsInZhbHVlIjoiekxDbmt6dUtBR3RMNW5NUnlnS0N1QT09IiwibWFjIjoiZmQ4NGJiZTE5YjQxNWFlMzY2YzQ4NzY4ZTE4YzI3ZTYyNDJiNjQwMjA1NmIzZTVlZjdlYTZkZmMzYjY1OTFlMiIsInRhZyI6IiJ9','eyJpdiI6IlpqOTVmcU1IVHRnU1lnVTg5ZUJ2aXc9PSIsInZhbHVlIjoiL1U1N2JXQjNsODFScG5VSzNqSjBLdz09IiwibWFjIjoiMjY3MTZkNmE0MTBjNDczYjVkMDg1MjAxNGY3YTAxODU3ZDZlZTM1N2I0NTFkMTI2YjVhMjMxZmRkZDNjNWYxNSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(19,20,'eyJpdiI6Imk5bmNVTnc3NkEvSjk0MUIzeGRHS2c9PSIsInZhbHVlIjoiejlxUkx4eU8vQ3RsYXNKZW1iSWhXQT09IiwibWFjIjoiMzIwZjllOWFlZWQ1NWYwMDhlODA1MjIyM2ViOGM0NmI4ODVlZDBkMjQxMmU2ZDkwOTc0ODAyY2RhZTIxODRhNyIsInRhZyI6IiJ9','eyJpdiI6IlVJa3Q3STJlZnlwOTkzLzlXLzZibkE9PSIsInZhbHVlIjoidDQ4Sk91dzh4RTNkUjJUbHMreUZiUT09IiwibWFjIjoiYjg0ZWYwODczMjQ4ZmY0N2Q4ZTJlNDkyYjI5MGRkMGQwOGJkZTg3YWMxNmJhNjVhZWZlZjI4MDIyY2U2NDVjZiIsInRhZyI6IiJ9','eyJpdiI6IkQ2UDVOYmlYOEVQYnZJcHRzN2VsUWc9PSIsInZhbHVlIjoiU2F4UnZtR0xGN1hrZEROMU5LMFlPQT09IiwibWFjIjoiZjE0NmU5MzMxOWFhOThhY2UwYTg3ODQ4YjIyZGQwMjY0ODI3OTRhYmU3ZmUwNzY4OWEwMTg2NmUwNjMwOWI5MSIsInRhZyI6IiJ9','eyJpdiI6ImUwRE1uMkRnbFdrdHlqb2hKUWMzWlE9PSIsInZhbHVlIjoiNnlqYTMwbmVGR0N2WTA1NmcrNUlnZz09IiwibWFjIjoiZjZiODc5ZmRlOWQ4NmJkNTQ0ZGVlOTUyMGQyNDUzMWUzZmY2MDA5OGIzZjQxZTczOWE2ZTE4NjY1NTAwYjkyZCIsInRhZyI6IiJ9','eyJpdiI6IlBmN2IzMjVNN1pDaSsvd21FTzBUY1E9PSIsInZhbHVlIjoiYnVHZFkxZlYyWTJiaWg3dll3eExGdz09IiwibWFjIjoiMDI3Yzc1Mjg3ZWYxOGRlZTVjNGYwNTEwNzE2ZDEzY2Y2M2Y3NzcyODViMWM0ZWM2ZTA4ODM0MDQ0Yjc2MGE5YiIsInRhZyI6IiJ9','eyJpdiI6IjhDMzlxaWxUSGV1aXdJeHBBV3NzV2c9PSIsInZhbHVlIjoiM1RxUDZuaWFkZWFIdzErY3dXK2UrUT09IiwibWFjIjoiYWIxMjFlNjdjYTIzOTk2ODRkZDczZDY1NWJkZmIxOTdmMDA1YjFkNTZlY2ZhY2ViZGMxOTljMDY5NzUzZTFjMSIsInRhZyI6IiJ9','eyJpdiI6IkVmKzNOUUYzTDFyRmpqUGRuaU4vU3c9PSIsInZhbHVlIjoiWUxDQ2ZPd2tPVTFXZVhjY0pvaGVzZz09IiwibWFjIjoiZWNiMDEzYmRmODM5ZjQ1ODg5NDNiNTAwYTZhMDBjMGNmMTY2MTAwZThiNTkyYmU2NGE1YWU4ZTNiNTdjY2ViYSIsInRhZyI6IiJ9','eyJpdiI6InYrRHQxc3doRnpDM2ZTOWh2TXZrTXc9PSIsInZhbHVlIjoib0lSK3lqUDA5b2taandGY3RVRDA2dz09IiwibWFjIjoiMWYyNTQ5MGFmZWVlNGVlNGM4NDBiOTcyMmQ2OGIzMGMzYzJhNjgwZDM4MGU1Y2Y3OWZlMWViM2YxM2QyN2Q1YiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(20,21,'eyJpdiI6Im9KUjhEckhOeWlpWTZSK3c4ZjVOSUE9PSIsInZhbHVlIjoiTTJCTjEwRGJPK1JSYVJNait2MHNvdz09IiwibWFjIjoiNmRiOGQzZjAxOGM0ZTQyNDdiYTJlYTJkNmZkZWY1ODg5MmZlOWU3MjM4NzdhYTA4YjYzZmE3ZDNiZjhiNTk2NiIsInRhZyI6IiJ9','eyJpdiI6Ik5ITmxiK0NzLzczaE0xMXVoeVBLeVE9PSIsInZhbHVlIjoiWjVnanpFRk8vOFYyUU9RVm9LbWVZZz09IiwibWFjIjoiOWI2YjhkZjZlYWJjOTY4YTgyNjRhZGJhMTM2MTA0MDNkNzc3MzY0MTNkMjZmNjIzOTc1ZDAxMThhNjk3ZDY3YyIsInRhZyI6IiJ9','eyJpdiI6IlNPZC9HUC9qNmRmUkZRVGpCL1NlOWc9PSIsInZhbHVlIjoid3FUUU5Gb2V2V215QmlPSGZJMWVZZz09IiwibWFjIjoiZWNmZDU3ZmQ0MGMyNjJjMTA1ZDZiZjUyYzQxNGExODA3YjU4YzU3NjAwMWZlYjYwZWRkOWQwYTM3OTM5NDM0ZSIsInRhZyI6IiJ9','eyJpdiI6Inc4UEJVZ0hKU1JER09pT1l1ZWlzQ0E9PSIsInZhbHVlIjoibkZzN3lTVHRxVWlwV0hxalkwQmpoUT09IiwibWFjIjoiZjBhZDMxZDk0ZTg3OTAxNzY4MTc0YTU5MTQxNzhlYzVjZGMwMGFiYjBkZmY2OTI4ZmZmMjBiN2I0ODdhYzI3ZCIsInRhZyI6IiJ9','eyJpdiI6Ik9NdXRjcjlxV08wYnZNUmlGejExVnc9PSIsInZhbHVlIjoiWkduVlFCbnNjU1FhT051NVFoelR3UT09IiwibWFjIjoiMzhiNDJiMDcxNGJkOGVhN2FiYWEyZDFiODdjZDE0YWQ4YjcwODUxNDk0MGRlMjUxNGZmNTMyMmEzMjk3YzY3NSIsInRhZyI6IiJ9','eyJpdiI6IlN4M0dPZTVwNXU1V1E5cVdIRERJNVE9PSIsInZhbHVlIjoiQU9NcEx4RGQ2NWVweGp2bUVLMldBQT09IiwibWFjIjoiMDI5ZGUwNWQ4N2FhM2Y4ZGY4Yjc2OTk0NDk1MDc4NmRiZDllOWI5ZDkwMTFmMDAyMjE5OTgxZTNhMzllOGZhNiIsInRhZyI6IiJ9','eyJpdiI6IkpoV3BoNGdDNkR1azQvRGNCODJaMlE9PSIsInZhbHVlIjoiYnp5eVlJcldMSTZOWW5LQklXaWdNdz09IiwibWFjIjoiZTMzMzFmNGY5ZTdiZWI1Nzk1ODUzYWY5NTMyN2JkNDNkMDA1YzBhZmU4ODAwYzlmOTM4NjVlMzA0Y2UzZDVlOCIsInRhZyI6IiJ9','eyJpdiI6InNGeHRiTkJ3K3pUYlloa3JqMTdCenc9PSIsInZhbHVlIjoiN1lmbkFPZThHdnc3R3dRRzY2UVk2QT09IiwibWFjIjoiYTUzYzc2NDQ1ZGUzYTM4NDExZmY4Mzg3Y2NiZTkzM2Q1ZmFjZjIzNDM2MDI1NjAzNzQ2MzZjZDM5YmM0NmRhMyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(21,22,'eyJpdiI6ImFkSEpJRmoxNzFCKzNoRm5OZjBQbkE9PSIsInZhbHVlIjoidGZPdFJ3TjhwUzk3SG1KVGtGbE1zUT09IiwibWFjIjoiZjg3MTkyNTc3NWUwNjk3ZWIwMzQ0ODBlNTJlMDhmZjQwMTQxOWZhMGMxZWRkYWE4ZmE2YTY2ODdiNmVjNjEzZiIsInRhZyI6IiJ9','eyJpdiI6InppZVZmQ3Z5UVFXMWhDMXZ1V3VwaVE9PSIsInZhbHVlIjoiazJvejNXMElFaFVQZVpIeUtDV0RVQT09IiwibWFjIjoiOWJiNTY3YzA5MGU5ZGUwZjMwM2QwYjE1MTNmMzM5MjFkMTQzMTg4NDdjNThhN2NiY2NjYzM3OGVlNDk4ZTMxOCIsInRhZyI6IiJ9','eyJpdiI6InJDWFBHeko0Y09oN2t6OU10aG10aEE9PSIsInZhbHVlIjoiTHBMVjd5U1hOYnBjbGVaeXY5WWo2dz09IiwibWFjIjoiNDFhYmI5ZTJjMjEyNWQ3NDFhOWFmNjgwOTE2M2ZkZGU0ZjVkZjJkM2RkZTcwNGE0NTIzMmQ0NzI5MzkzMTcxNCIsInRhZyI6IiJ9','eyJpdiI6ImJ1cktaM0xMVUxYMDhDYXZtM0ZYdEE9PSIsInZhbHVlIjoiQi9QajBod0xDYWpQQjNqMTByKzVLdz09IiwibWFjIjoiNDI3YTQ3OWUzMTg3YTVlOTU1OWFkZTJlNDM1ZDgwMjY0ZDY4YzdkZTM0MWYxNjBkNjY4NmJjMmY5ZjNiNmJjNSIsInRhZyI6IiJ9','eyJpdiI6ImNUeWhoOTZqNHFPVDBkZGdvNk5Ia2c9PSIsInZhbHVlIjoiMWFqNkFVTFppQkE3UW5hQVBjSVVhUT09IiwibWFjIjoiYTk0MDUyMmMwNzg1ZmMxNjMyMzEwOTYyMjc3ZWFhZDNiYjkzYzk1Zjg3NTM4ZDIxMDI1ZDNmYWM5ZGM0MDc4OSIsInRhZyI6IiJ9','eyJpdiI6ImMyQlo0VUg4VVRQTGF5YVVudmg5dkE9PSIsInZhbHVlIjoiZjlBWW5nTWRqZDdJWXBHVFZEQUxydz09IiwibWFjIjoiYjYzZDBkMjA1OTZkZjI3MmYxMTQyZjIxYTk3YjhhNjYwZDgwYzVlNGZkM2ZkMGRlZjhlMjUzMTE0Y2E2Zjg3MyIsInRhZyI6IiJ9','eyJpdiI6IlUyYnJXalZBS0VHUWxuRVJ0b3psUHc9PSIsInZhbHVlIjoiZUl3OC93KzFvbENnVXZua3Y4bGpVQT09IiwibWFjIjoiN2Q4ODcyMTNlMWNkMDgyYjZhZmEwYzlmZjliYzM1YzEwNGU4NjNmOGM1NDU0MTkzMmMwOTU5ZmQ1MDU3MTc2NCIsInRhZyI6IiJ9','eyJpdiI6Ik81bERDOGNCUmJ0bjhxN05tdnZpQUE9PSIsInZhbHVlIjoiQ245WTJrVW1CeUgvTy85OERNMTl0QT09IiwibWFjIjoiZDA3YjY3NjRhYWYwOTAzNWQ4MTcyMTgxZWQ0ZDE4YTdmMTU1ZWJhNTJkNGYwMDNhZjcwMWZiODRkYzA4MDhlZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(22,23,'eyJpdiI6Ing5bkZpSHVua1c0cU9hUEMwMzhBOGc9PSIsInZhbHVlIjoicnVwNFF4enlUS0hYNjZNWlkyUktXdz09IiwibWFjIjoiM2MwMjIzYWVhZWIxMzM1MjE5YjZmOGFmYTdkZmQ2MjkwY2U3MTFlZmEwZjA5MTE2NTlmYTRkZWZkZmJmZTJhNCIsInRhZyI6IiJ9','eyJpdiI6IklLSjRDTlJ6RUcwSWhPVWV4Vy8yakE9PSIsInZhbHVlIjoiZHlGOXhjemZGTWdzc0pNaVVkQXVCUT09IiwibWFjIjoiZjMzODI1MDIyNTZiM2I0ODMwZjMwODFiMjAxMTJhMjk0YTE2ZGY4MDMyYzhkNDA1MzIwNTczZjk5MzhkM2IwYiIsInRhZyI6IiJ9','eyJpdiI6Im8xdEJoalkrcVBURVRhVU5DQ3lPMEE9PSIsInZhbHVlIjoiNnIxcUl6VDJtWkplamxRL05NbzhaUT09IiwibWFjIjoiZTkwNWEzMDkxYzQ4ZmI2MjRhMTViOTE5YjU0NDY2MzM1M2VhNGYxNmYyNDJhZTZjYjM4MTg2ODI1MDc2NDQxYiIsInRhZyI6IiJ9','eyJpdiI6ImVmRHdEazA3NWk5aWtIampBTVJlakE9PSIsInZhbHVlIjoia3F5MUhLUnpkTE9SelloVUpXRTNSZz09IiwibWFjIjoiMzM3MTc3YjlhOGRhYTNjZGM4Y2ZjNjFhMzcxODc4NjdkMWY5NTg2NGFhYTY3NmMwN2VmOTg3ZjUxZjUxNGY0OCIsInRhZyI6IiJ9','eyJpdiI6Ik5vRWZvb2VBVnVIVnhnNUVFQU1OMlE9PSIsInZhbHVlIjoiblRaaDJIMko3MUhXTWpOdVI1SS80QT09IiwibWFjIjoiMTMxMmJmNTlhM2VlZDdhZmI0ZDFjMjBjYTg0ZGU0NTVhOTcwYTk3OWU1OTIyNTkxMDQ0YzNkNGZiMTEwYzNlYiIsInRhZyI6IiJ9','eyJpdiI6ImFPSzJod1V6V2psQW80R1llNUtia1E9PSIsInZhbHVlIjoiT1hEa0RVRk52bDZNa2NhL2VjTXFYQT09IiwibWFjIjoiZWVhNTY2NzM3NGRiMTZjMTFhYzA0ZDViOGMzMDViZDYyZDA5ZDlkODkxZGZhNzhmODNlNDIxNGM3NjY0NzA4NyIsInRhZyI6IiJ9','eyJpdiI6ImlOOHVOTlRCZ2ZHbnFYM3FBQVVRVmc9PSIsInZhbHVlIjoiaVc0RWRxVlhwU1F6b0lsSUpqSXZiZz09IiwibWFjIjoiZGEwMjM3ZjljN2I4MDRmMTYyY2YyYjRhNDA4NDFkODk3ZjQ0YzlkYTEwOTNlMDdjMjY5ZTNmNDc3NDU5YjI5OCIsInRhZyI6IiJ9','eyJpdiI6Ilg3TFpJLzJKeXpOYUNBM0ZDYXRSc3c9PSIsInZhbHVlIjoiTHovNUVlVWgvU0FLemZlemxxQzJ3UT09IiwibWFjIjoiN2Q2YTkyNDY0NWU4OTNjZjUxMzFlNzViYjU1YzI5YTExZjdmNTNiMzU5YTI0NTZkYmRjMDM0YTMwZDExZGU1YiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(23,24,'eyJpdiI6InVMdnhlMDZiRmNJU1dMNXREN29wMWc9PSIsInZhbHVlIjoiZkQ5bDBvaEZjWUtvYUFONXVIcXhGUT09IiwibWFjIjoiZTE5NjNlM2VlNTZmNDI2NDBkNzJlMmQ4MzEzZWU2OWQwYWUxNWJhMDc1NzRhMjE0ZTcwNjFiZjY4ZjdhMGY0OCIsInRhZyI6IiJ9','eyJpdiI6IkFOcjVCZ1drWkpiM213dG1jR1JscXc9PSIsInZhbHVlIjoiUEY0MU5lNlZIZ04rK29qYWFOdEFwQT09IiwibWFjIjoiYTE1YjE2NTg2NzUzN2VkNGViN2YyNTkyZTNlZDE4OWRkYWZkMTFlYzExODA3NjVhYmE4Nzg3NDhlNzU3MDk4NCIsInRhZyI6IiJ9','eyJpdiI6ImpWK3R3VE9mU1F4TGcwcFFRWThxWWc9PSIsInZhbHVlIjoiTWYveE9Tdm85empLT2hPaURLUER5UT09IiwibWFjIjoiOTAyYTE4YzkyNjZhODNkMzIyNDkwMjVmZGM2NzllZmI5ZDdkZGYxMTQzN2E1MjJhY2ZmMDJiYTA0OGViY2VhMyIsInRhZyI6IiJ9','eyJpdiI6ImVhQ3ZQVXl5cUd2b1RPMkE4MGhoS3c9PSIsInZhbHVlIjoiQ2JTK0taaFBKc2ZpUVpjMEhDamFLUT09IiwibWFjIjoiNmE1ZTVjZjUwM2EyZDA2YjllMTA2MGFmNjcwZjA2OGIzZGNiNjlhOTlkOWRlNGJiMmY1NDY3ODA2YzYyMzcyMCIsInRhZyI6IiJ9','eyJpdiI6IlEydTV2RldITkNGMmV1VmdQNnJqR2c9PSIsInZhbHVlIjoiemdOT0w2ZDNZdWQ1Yng3LzdCUHB3dz09IiwibWFjIjoiOGQ0Y2RjZDRjZWY2N2IzMzFhNmJjODlhYTEwYjdkZDEyZjc1YTVmZTU1MTY4N2UwMTkwNTNiZWRjMzMwNjkwZCIsInRhZyI6IiJ9','eyJpdiI6IkV1TkdqNDlPRnpIOEN2NWEvZGJRM2c9PSIsInZhbHVlIjoiaG8zeHJ6K0lscG5jQU9pa0lBNDdCQT09IiwibWFjIjoiMjZjZWEzNGE0Y2QzMzYxZjA4MzI1Yjg1M2Y4YzUxOTc0OTIyYzY2NTBlZTliZWYzYjU1M2VkN2U5N2QyMGFlNSIsInRhZyI6IiJ9','eyJpdiI6IjNKcUExNmNSY1QzRnpWZkd6SDB6T2c9PSIsInZhbHVlIjoiUnp2NXNsdFNBT1Q4WDNCU3I3cXMxQT09IiwibWFjIjoiZTUxMDJlYTViMDhhNjA3NWY2YTM1MGE5NTM1N2Y0MjhmYzUyZDc2NmI4NmQxMGRjZDdkNWJhOGU2YTliOThhZiIsInRhZyI6IiJ9','eyJpdiI6IktWejFBVDExcUZZSldzbjhZZi9vOEE9PSIsInZhbHVlIjoiY3FOOC9nQzlBbDFoZFBUdFkrM1Urdz09IiwibWFjIjoiYzM3YjY4MTEyMjAyZTIxMjkxNGQ3Nzg2MmJmM2ZjMDBkZTRjM2FiYTYyMTRkNWIyYjg2NDVjMmRmYzQxMDQ1OCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(24,25,'eyJpdiI6ImhDSFp0Y3VmSnZ3aTZQazlSY2s1MEE9PSIsInZhbHVlIjoiYjRVOVd1M1NQSWxZc0VDeFprZFJLUT09IiwibWFjIjoiMDM0NTlkNTc3NjRmNjVlNGI4YTRhYzYwMGUxZWE2YzQzY2I3MWRlNDQ0NDY0NmYxNTZmOGNlZDkxNGY5NjE0YyIsInRhZyI6IiJ9','eyJpdiI6ImNEZE5Nd1BoemNueVdhMGUzTHY3d2c9PSIsInZhbHVlIjoia2lrSlIyVWxGWGRtbEh0WG5TSmpDZz09IiwibWFjIjoiZjQxMGM3ODdlOGQ5ODBjOTdkYTY5NDg3MzEwOTBlMTk3MTE2ZDU1MzdiNTU4ODZkZDZhZjdkNmRjZjVlMDc2YyIsInRhZyI6IiJ9','eyJpdiI6IjhSWDFaL0ZJc0hSNXpKU2RDTkVwZ1E9PSIsInZhbHVlIjoiYWV5ZTM0QldadHYxWGQxQkJkVDloUT09IiwibWFjIjoiM2FkNjQ4ZWYxZTkxZTVjNGU1YzY4NTU0ODkwZGFiOTc2MGU5NjAxN2FhNTI0ZGE5NjViNjg2OWEzMjIwM2QzZiIsInRhZyI6IiJ9','eyJpdiI6InFYYVBYLyt5anBoNXR3MGdWR3ZpR1E9PSIsInZhbHVlIjoiOUNVVlZiOUtkZFRyay9jUk1CUWVUUT09IiwibWFjIjoiNTVlMWI5NzhkYTEzODMwOWJmMTcyZTJmMDM0NGFhMmE1MDZkN2JmNDJlMjM4ZWUyZDkyNDM2NGFkZGE0YmYxOSIsInRhZyI6IiJ9','eyJpdiI6IndXS2FXODdjd1ZEcXVxdkNDVE5DVmc9PSIsInZhbHVlIjoiYVoxckxzSVp2cjZYbXNtWTlsMFBqdz09IiwibWFjIjoiYTE1NmE4MmY0MzdjMzcxNmMyNTU0YmE1NjA5ZWYyYmUzMTE5NDY4YzRiZWI2YjEwMDBiMTcyYjlhNTE4Yzc3MyIsInRhZyI6IiJ9','eyJpdiI6Ing2MXppTTROaWJuYnZJK2RLUWQwUlE9PSIsInZhbHVlIjoiQUo2c3N3NXhVdGhsZnJNM1ZxVVpFQT09IiwibWFjIjoiODMxMzk2NjljNzFjNWY5ZTUwNTBjOTJiZTdiZGRlNzg5MGM2OTlkM2M3OWFmMGM2NTgyOGJmYzU4NWY2YWQ0NCIsInRhZyI6IiJ9','eyJpdiI6InA1cUlDbitOV0c1U2VPdDAvaFB0R1E9PSIsInZhbHVlIjoiYlV4TEg4SE9CUUIyMFFSU3JOZ1lvQT09IiwibWFjIjoiZjM4YjVjNzg2MDk0N2VlOGQwNzIzMDUzZTcyNTBjOTAxYTA0NWFkNGU5MDkyZmJiMTI2NzQ2NzYyMmZmMWRhOCIsInRhZyI6IiJ9','eyJpdiI6Ik1hY1E0MGM2VUxOUk1kTUlJSTZEY3c9PSIsInZhbHVlIjoidGptckFlTk1KL21qTkg0US91bExNQT09IiwibWFjIjoiNzAzZjZkMTc3MmUwZWY5MzIyMTgwODg2MzhlMGUyNmY0YTk3NzZjNzk0MTExNzI1NjM0N2ZjNWEzMDdkOGU0MCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(25,26,'eyJpdiI6IlEwdEV1UFQ5enlYZ3IrUUxINm5RekE9PSIsInZhbHVlIjoiNWh1dkpjTFFFMm5DdjdnM1YyTTVHQT09IiwibWFjIjoiZTAzYzRiMTYxMWVjNTUxMzA3YmI3ODMwMjNhYmNlNDBhNjA2MTZjNzZkOTVmMGU2NjY1ZTgxNWEyMzFiY2Q4NCIsInRhZyI6IiJ9','eyJpdiI6IlY0RTlVVGRxaVRzSmZJSDh2NUxIalE9PSIsInZhbHVlIjoiQ3VoMjlEUU4xUWs4MjliSTVwUWVDQT09IiwibWFjIjoiM2Q4MGY3Yjk1ZTFkYTRjNzc3YTIzNDQyNTFiNzE3MmRhOGU2YzJjNWRhMDVjYjQ1NmY4Njc2MTk3ZDBkODhmMCIsInRhZyI6IiJ9','eyJpdiI6Imxrd2ZhYWZIVmZidmd0cCtFK3I0TEE9PSIsInZhbHVlIjoiYWFXWHRjVGUzTU5RN3ZZN1p6aVdpdz09IiwibWFjIjoiMGU5ODY4YWE4OGYwMzIyYzdlYjYwNzkwYjk3M2E3ZTkwNjljOWQwNGM1NDhkODRhYzA3YzExZjI1N2ExNjcxNCIsInRhZyI6IiJ9','eyJpdiI6ImRhZm16ZERuZGkxbjFyY1g2Tm0wZEE9PSIsInZhbHVlIjoiWnZXU3dPZlJpTzV1Z1lFR3phOUVzQT09IiwibWFjIjoiYjg5NWQyMDcyYjE3NGZmNjdiYTA2MWNmMGUzMWMyNjU3OTgxMjQyMTA3Mjc5YzJmODc4ZGQ4ZmZjNTZkMTZmMyIsInRhZyI6IiJ9','eyJpdiI6Img2aEl0SmtHcVlQK2U3UytxTmRQUkE9PSIsInZhbHVlIjoiTWM4LzBreVhkaFVqWk16U2N1ZVZ5dz09IiwibWFjIjoiMzdjOGYxZWYzNzZhN2JmYjBiZTI0MDczZjMxODQ5MzY4OWJhM2FmNzBjNTczYTgzZDcwMzJmMDUzYzU2M2Y0ZiIsInRhZyI6IiJ9','eyJpdiI6IkFOVDdKcmdwK2JYaWFHRm5qTlVNWlE9PSIsInZhbHVlIjoiMW9qN2pKVXZSYTNHQk8vZzFNbHl2dz09IiwibWFjIjoiYjVlYjY1MThmYmYzMjA5NTY0MzBlNjk2MzVmOWNjOWRkNzhiMGFhNGU1NTVlYzVkZjQxZDlkNzBjNTgxZDJjYyIsInRhZyI6IiJ9','eyJpdiI6InpVS2tVNDE2MnYvT00xS05hU3NRdWc9PSIsInZhbHVlIjoialoxTHJ4Yk1raTJxelNZWWFIYXdkUT09IiwibWFjIjoiMjA1OTFiNmQ4MDQ5NzcwY2QwNzJhMGUxODQ3ZTNhYjg0MDk3ODUwYmJhMTg5MjEwYzk1NjE0NmI3NWZhMWEyZiIsInRhZyI6IiJ9','eyJpdiI6IlNhY0wyQTNxMXFXdkhJUkNnYWNJVXc9PSIsInZhbHVlIjoidWZTWHhBQlpnNXFlRlV5NGMwT0tGdz09IiwibWFjIjoiMDliZjBlNjQzNmE0ZWYxMzI1NTUzMzIxMGEzZjZjZTA2ODhmYWUxZmI4ZjkxYjZiOGY0MGU2ZjkzNDBiZWQwMSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(26,27,'eyJpdiI6IkhKblF2TVh0c1U3TGoyQWNlcjg2Nnc9PSIsInZhbHVlIjoiNjZKaDBwOGR6cm9PMnJYQUl0NWdtUT09IiwibWFjIjoiYzBkYjcwZjI4NTRjYWM3MDliODNlMTZkMDRkYjEzMmFmMDRjYTZhNzJjMWU4YjM2YjcyYzU2NGUyMjYxM2YxZSIsInRhZyI6IiJ9','eyJpdiI6ImtBWGNCa1B6MWMvZmlqOHY2bnQyTnc9PSIsInZhbHVlIjoiYnMyS2g1YVE1bDQrelp3aUw5VzYvdz09IiwibWFjIjoiNTFlYjM0ZDJiOTEyYTA2ZDRlOTA3MmE2MjM0ZTU0NDc1ZGZjYzEwMzhkM2NiNWU4ZDQzMzZlODZiZmNmYjkxYSIsInRhZyI6IiJ9','eyJpdiI6IlB6dXZURVNaQ3BQckRRRW9QMW9NQnc9PSIsInZhbHVlIjoiWm43VFI2b2ZSOElsNm8yOXBNVDNZdz09IiwibWFjIjoiOThkZjdiZjg4NzAxYTMzZjQzOTY1MDNiN2RlNzc1ZjdhMTIwNzcwMWJlMmE2ODM5YzgzNjAwY2JmNjYxZWQzNSIsInRhZyI6IiJ9','eyJpdiI6IkxXeU1kbXFRNy9TQ3FlSFRnU2htYUE9PSIsInZhbHVlIjoiVXdjS2lNOGE5YTNGQTkrUng4UE1qUT09IiwibWFjIjoiM2Q3ZDc2YTVlNzhhMzE1MWI1YTZlZDJkNWVjYWJiMzJhNDlmMTBjNTk1ZWEzZjRhNGVlYWY0ZThjYjJjNDA1ZiIsInRhZyI6IiJ9','eyJpdiI6ImVSdytiaktnU2JCZUNkOHllb1RSNkE9PSIsInZhbHVlIjoiU1A2SmlncHdTbng5WmZjZE41Mi9mUT09IiwibWFjIjoiYWNmMWM5MTNiZWEwNTgxYmMzMDM2ZjU2NjBiMzcwNWE0MmU2OTQxODA0ZWQ1OTNjZTg0YjNiNzJlZTk3MWI1YSIsInRhZyI6IiJ9','eyJpdiI6InN6K0xLdUNaVWp2bkhzdisvbDBaTkE9PSIsInZhbHVlIjoibTg3Nk1qS2JTekpsbEdRVnJBd0dCQT09IiwibWFjIjoiMmU2NzBlNjZmMGFmZjIyMWI0NjExN2JhNTlmMjg4YjI3NWQxOTFiMmYxMjcwY2QyZjc1NGY4ZGIyMDcyMDRjNCIsInRhZyI6IiJ9','eyJpdiI6IjNpZlorVm5CVUZacHVRdEVyUHF6N3c9PSIsInZhbHVlIjoiUGNCSTMvRFZBZ25zUVhidjNDaFhtUT09IiwibWFjIjoiZTliZGFiNmUyMWJjZDA4YTFkZmY3MDFkNzExYzIzYTRjNjY5NGI3NzMzMjEwYmYyNTZhNjAyOGRhY2QyNzgwOCIsInRhZyI6IiJ9','eyJpdiI6IkZqVXFvUGEzdE0wT2lKZzBsQ3owR0E9PSIsInZhbHVlIjoicHpVeWRJMVZ2UXBWbXVzL1ZiRWJIZz09IiwibWFjIjoiYmZlMDdmMzUxYzBiMDg3YjNlYTA5YTEzYjg2MjJhYmMwNGI3OTdlZDE5OTYzMGY5ZGU5OGZiMTc3NzdjMDM0YSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(27,28,'eyJpdiI6IlZycUZGSkhwWWFEOVZRcHdFVlEwRWc9PSIsInZhbHVlIjoiRVkyS2M4aUlKUlNwdkVCWkZKZlh6UT09IiwibWFjIjoiNDE4NzY0MGViZGFkMGM2NzE0MmVlNTY1NjJkYjcyMTM1YWM4MDE3ZDIxNWIzMWI3ZGUwYWM4NWI1ZmEwNjkyNyIsInRhZyI6IiJ9','eyJpdiI6ImtvaFhhTTRPNXZSWVFxNE9EV3FScFE9PSIsInZhbHVlIjoiSzdDcmdLVm0wMFkxSFpEaWRnS25Mdz09IiwibWFjIjoiZWQxY2Y3YTUyMDY1NzIzOTVmZTIyZjA0NzQyNTQ5ZTMwODQ0MTBlYTJiODM5ZTY4N2M1NzBiNThjMDUwZGE5ZiIsInRhZyI6IiJ9','eyJpdiI6InRMZFRPYkxlWWZEelhKS1lBeGFFeWc9PSIsInZhbHVlIjoiYjBDZjN3dGkzd2VNLzVLSUZoVFdtdz09IiwibWFjIjoiYmRlMDU5NWEzNzkzYWUyNDg4ZWM5Njg3ZGFhYzZmNjcwMzYxODE2NTYxMTM4MjNhZTcxY2IwMWZlMzM3Y2UwNSIsInRhZyI6IiJ9','eyJpdiI6Ikd1MU03QkQxN2dZQXJMZ09hTkZDbkE9PSIsInZhbHVlIjoiQ05rcG9Xc2dyOGtkZ1gzMmhHbTFHUT09IiwibWFjIjoiZGEzMzRhZWZiZjFiZDgxNTQ4N2MzMmZmZGU2MTI2YTZmNjc2MGQ2NmQ0MDhlNjFkZDQ5NGM0ZGRlYzY3ZDljZCIsInRhZyI6IiJ9','eyJpdiI6Ik9tQkdQalZWZEVGWVVaTHFYOTdxYkE9PSIsInZhbHVlIjoidFg0eVpwbENrakJKSWtwT1V6bnpZQT09IiwibWFjIjoiM2E3NmVkY2YxNDRmNzMxZGE4Yzc4NzViNjBlNDJjMzc4NzM5ZDU2Mzg1MzgwN2Q0YmEzNzY1YTExZDNiOTY0OSIsInRhZyI6IiJ9','eyJpdiI6IkJwZXNCbGJJUkJIZXNFZjdVVFVMK1E9PSIsInZhbHVlIjoiYUdFaWNFTzlYU3FuTEloaXN0ZmhhQT09IiwibWFjIjoiZjAzMDcwY2E1ZjY3MzU2YmI1NTc0ZmI2NGVmOGUxYjc3ZWM3NDIzZmI5ZTI5ZTM0YWFiYTEzNGQ5NGQ5NmQ4MiIsInRhZyI6IiJ9','eyJpdiI6Inc3YXRUOGl5RjhoOFNYUUVVN2t2Unc9PSIsInZhbHVlIjoia2lTTGJUKy9LVHd3ZGFTWVZjOXNRQT09IiwibWFjIjoiNTJlOWU5MzE2NzliYjc5N2RhZjQ3MTVlNTE5ZWEwYmQ4Mjk1M2RiOThiNzhiYzc4NjY5Mzg4MjhhZGNiZmZiMCIsInRhZyI6IiJ9','eyJpdiI6InovcW9QWEdLY1VoMENXMmFKK08wZEE9PSIsInZhbHVlIjoiY3FYMy9DbFVhS3I0K0xJcTBaNW5SZz09IiwibWFjIjoiZGU4OTFiZjJkZTRkODNmNDk1NjE3OTliM2VkNjdmMzg4NjEwZWY2YzQyMDcwZTVkYmRhNDQyZjAzZTM3MmMxNCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(28,29,'eyJpdiI6IkdSUjFCU29UV2VpK2N6T3dkN2JUaFE9PSIsInZhbHVlIjoiczJ3K3NYYVZaTGQrWnhabTlVdEJxdz09IiwibWFjIjoiNzE3ZDQ0OWI0OTM5YmEyOTNhZjhmZWFkM2I5NjM0MTMyNzFlNjE5YTI4MGFmNjc1MTY3MjRmZjRjZGJiYzM2ZSIsInRhZyI6IiJ9','eyJpdiI6Im5JVU13RzhjT0tRNk5hRGp2SEtJdEE9PSIsInZhbHVlIjoiWklWSkk4MTJReHRpWGhyMTdjM2ZDZz09IiwibWFjIjoiYzdlMzJjZWVkOGRhYjAwMTQ3NDViYWI2Y2ZmNGI0YjJmODgwMmM2Nzk0YjBmMDRkMzcxNzdiYzU1NzRjYTU1NCIsInRhZyI6IiJ9','eyJpdiI6IjMvT0pNQXdISE82Nnp3R2NPeWxHRkE9PSIsInZhbHVlIjoiVzJHTVdOYnBOTHVHa1RZMzduUFpQZz09IiwibWFjIjoiYjZlOGNhNWU2NjNhYzgzZjJiMzI2OWM5MmE5YWQzOGJlNmViODA5MTkzMTExMTc1ZGMzMjFlMGQ1MTJiYjVjNyIsInRhZyI6IiJ9','eyJpdiI6Ikc0czhqbVF2a1lvajczUExXWnUxR2c9PSIsInZhbHVlIjoiV1JkdXQ0bHdNRnJoU3BjSFdydXpldz09IiwibWFjIjoiNzE3MTZkMGIwYzU1MWEyNzViODE0ZTJkYjk1ODg2YmVmMWIwY2JkNDdhOTEzMDIwYWE4N2M3NmNlMzNhZmE5YiIsInRhZyI6IiJ9','eyJpdiI6InBEYkl0cGFNT1lhUnNjeDV2VWNMeUE9PSIsInZhbHVlIjoiZ3U3NHFrL1VoekU4QUNUKzgrYVdRdz09IiwibWFjIjoiM2Y3ZGUxZGM4NjJhZmQ4MzFmN2NhZTE0NzQzZjE5NmNlMmJhNTkyZGUzMjcwZDg2NmM3MmI3MTNiZWMxYTAwZiIsInRhZyI6IiJ9','eyJpdiI6IlBLT3prcjVlY2FTZzAzblRIbFZZYUE9PSIsInZhbHVlIjoiTzQ1clNZOSt0bVhRTGF4QkRURGJRdz09IiwibWFjIjoiYmQ1YTlmYjQ0MjQ4MzljMDQzYzk3MTZhYmUyNjNkNjNlMDUyOWU3YmMwZTI0ZWIwMjRmNjk5MGZhNzQ3NTM4ZSIsInRhZyI6IiJ9','eyJpdiI6IkcxTDc5L2p6dU43QWZmMnRRR2lEOFE9PSIsInZhbHVlIjoiaVc0OW1wUnNpeFVlT2s3V2MzR1RZZz09IiwibWFjIjoiYjRlMTI1Mzc0NzQyNTU4MDQzNTVhZTRhOGRkZmU1YWZjZGQ1M2MwOTJiNmRmNTUxMWEyOTg0ODM4NDM2NGQyOCIsInRhZyI6IiJ9','eyJpdiI6IkNNQ0ozK2FhaktXR0VQU1l4UllkUFE9PSIsInZhbHVlIjoiYUlXakVhV0YxYklJLy9YS2g3aDhIZz09IiwibWFjIjoiNDhiMDhhODNkZjQyNjEyOGRmNjZiZGYzYmYzMDViNWJjNDhjNjIxZjhmODdjOTVmZTczOTM3M2QxZTM0Y2VkMSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(29,30,'eyJpdiI6IlowODVXVUw4Mks2NmVNRWpDejhJL0E9PSIsInZhbHVlIjoiRmQ3aWRwLy9tTE1FQjhkcVBpaUlPdz09IiwibWFjIjoiNzJkYzVkYmY1ZWY2ODcyNzU2YTc2NGJhYjY3YzMxZTRkMzMyYTY5Mzc0YjEyNGY2NDgxYmM3M2I3ZDQ3YTdiMiIsInRhZyI6IiJ9','eyJpdiI6ImVSZ3h5Y0x2eDFrYUdvUisya2tuQ0E9PSIsInZhbHVlIjoicG1IbUNIWGhYQllEUzlmbUNvMTlBQT09IiwibWFjIjoiNjNjYWQ4ZDY1OGRiOWY0ZmRhMGQ4ZDZhOWI4NmUzNjNmNzE2ZDgwNDMwYTI3NzY0NTFiYzA3ZGM5M2FhNzZmZSIsInRhZyI6IiJ9','eyJpdiI6ImVCczU2VkRQTkxndGZscWM0ek1tRmc9PSIsInZhbHVlIjoiQ3E2N25kWlZTVG1HcnN4R0xrWS9uZz09IiwibWFjIjoiNTExZjMxZDBmN2UyOWFmNWYxYjI1OWY1NDU2YzEzNTRhNDE4ZGUzNDUxMjQzNTNlOWRkNDZhYTczMjgxNWE0YyIsInRhZyI6IiJ9','eyJpdiI6IldiTHJXajhiZXVzU1ZtazR0ekVRMEE9PSIsInZhbHVlIjoiQlJKbUg4em1PODNRNG5tTmdKbzlGQT09IiwibWFjIjoiNDIwZGVjZDc4NDc2YmQ3NjhkNWIyMzA2NGMyMjgxNDk4ZGQ1ODE4ZjRmZjkwNDIyODgyYzhkNDNjZmY3NTA2MSIsInRhZyI6IiJ9','eyJpdiI6IkZ1dWgrUFR0WmdPZ3pXRC9Ib3Q5OGc9PSIsInZhbHVlIjoiaDNNVTJqdmFiS3RQMTJzWEx3UkVhQT09IiwibWFjIjoiYzNjY2E5ZDA1N2FlYTg4OTk1NzhiZWRiNmE5NjM1NTUwMWVlODIxOTUzYzU1NzQzNzUxMGZjZmE1ZTQ2MTNkMSIsInRhZyI6IiJ9','eyJpdiI6IkFlMzB5NjF6L2xrYUJYTnhZYitIL0E9PSIsInZhbHVlIjoibnRYME5tdzI2QmdNQzN5V3RuT1NmQT09IiwibWFjIjoiNzU3ZmJjNjYzZTVlMzlhMTY5MjY2ZTQ2YTIyYzczOWVhZDJmNTczZTAxNTU3ZDE5MjJkOTc3YjkwOGNmMzBiYiIsInRhZyI6IiJ9','eyJpdiI6ImNEN280OTVRQTVOdktzRGNxS3c5VUE9PSIsInZhbHVlIjoiWElJRXNPc0phelF3S1I2RzdQNWthUT09IiwibWFjIjoiMTI2Nzk4YWFhZTI0MGZmNjM0ZjY4M2YyNjM2YzNlOTc3ODhhMTI1ZmIxNmEwZGY5N2Y0N2Q5N2YyYzgwOWVjNiIsInRhZyI6IiJ9','eyJpdiI6IkZHSER0RzR3a1R0bUR6aFU0ZGNiQ1E9PSIsInZhbHVlIjoiY253ekRtbEYzUFNrdlRtSDdtTkMzZz09IiwibWFjIjoiNDZiZDk2NmEzNGIyOWI3ZTI2MzY4YzZjNzQ3Njk0NzczMWU4NWZjM2MxZjlmMmIxMGZiNTc0YjY2MzU4MDlkNyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(30,31,'eyJpdiI6IlNLV2xHbjF5M09ublBEbitLdWxKZ1E9PSIsInZhbHVlIjoicEdwUnl3czljNXVQUFl1YXdKUVBPUT09IiwibWFjIjoiZmMzMWI2OGQ3Y2NmMTMxYWJjMjlhZmFkN2U2ZWIyYjk0MTg5NzYwNTNkNjE1MDFlYWZkZTdlMzI2YzA0ODczNCIsInRhZyI6IiJ9','eyJpdiI6InFhd29mRHFrQi9INUprWVNkcDFYYlE9PSIsInZhbHVlIjoiWUJUSkNiSENtN1I5cVJvSDlLeVZnZz09IiwibWFjIjoiMWUwZDFhYzkxZmZhNDI2YzkxNzZhMjYzYTk4Nzk0ZTk0OTMwNmI1YjM5ZDFmZjExNmE3ZGM4NGNkMDM3MDZlNyIsInRhZyI6IiJ9','eyJpdiI6InBCcys3U1lTWUpPWnpwZXVhcWd4VWc9PSIsInZhbHVlIjoia3hzWkJ5QTBWSWt5WXdjU2tSTUZPUT09IiwibWFjIjoiMGU5NzMyZWRlYTgzYWY1YWM5NjcxMjlhZDA5ZWZiM2E5MjM1N2ZkM2IwYmJhODUxZjhhZDFlM2RiMjQ4NzU1NiIsInRhZyI6IiJ9','eyJpdiI6InNOVlBjN2VZK2xzeUU0aXpTZ1k4bGc9PSIsInZhbHVlIjoiS1dTTHI3MHl1NG9QRTFpVGpSbjRoZz09IiwibWFjIjoiNzQ5NDc3YzcwNzU2YmVjNmRmODZiMDE0ZjE1NWM3Mzg3NGIxYmIxYjViZDg5ZDA0MTBjODJmYjhlMzg0NTU0MiIsInRhZyI6IiJ9','eyJpdiI6InkvZ0tvakJ0bVBxNENCTEE3b2hFVFE9PSIsInZhbHVlIjoieDYza3UrSEFQS0pqTE5kUTRLRGRGdz09IiwibWFjIjoiYmFhNmI2NmE0YzYxMmYzZTFlMTI4YTc0NTFiYThmYjhiMjJhYzRmYmY2OWQxYjAzYWY2NjZmOTFlODE3YmI3OCIsInRhZyI6IiJ9','eyJpdiI6InpLQWZMZEluMGUrYm1idE5zRjFUZ1E9PSIsInZhbHVlIjoienZVbkkyV0ZIeGRuVEJ0K25MdXB0UT09IiwibWFjIjoiOGYwMzUzOWIyODBiYzRiYmMzZGU3Y2MxY2Y2ZGE4ZjcwZWU2MzM5NWJlODc2ODE3YjA3NjQ0NWUwMjU3OWMwZSIsInRhZyI6IiJ9','eyJpdiI6IkpHdFVwV0ZWc1ZVQWY1YzhCa24yZHc9PSIsInZhbHVlIjoiM2YxQWlqYkthdS93Rld1dTV3elUwUT09IiwibWFjIjoiM2Q1YWIyMzlkNTNiZDAzNjE0MjgxYjk3ZTFlNWVlZjQ5Zjc0NGQwYTAwZGE0YTlhZjYxMWUyMjc1ZWJiMDk1MCIsInRhZyI6IiJ9','eyJpdiI6IkNqTnZkblhDdWhHbFh0WU1ENnZ2cXc9PSIsInZhbHVlIjoiajJGSnRBSkFtMjVkVGRYTGZycVJqZz09IiwibWFjIjoiNTM2ZmZmNmQ2ZDgxOGQ4YjBhYTU1NmRiODA4MTAzMDY0YmZiZDFhY2ZlMzZlYTQ0ODcwMzNjNmM0MjA3M2EzYyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(31,32,'eyJpdiI6InU4WE5NNlRDVHUwZCtobmduOUwwbkE9PSIsInZhbHVlIjoibTNhYXNDVUlBMU1Zb1IvbDg4VjFWUT09IiwibWFjIjoiOTgyMDVmNzBjNjMxMWJjY2MwZjhhODQ2ZjUwM2FlMjBiMDJiZjY4MmMzNTIyZmY3ZGJlMDU4MWRkZDNhNWEwNiIsInRhZyI6IiJ9','eyJpdiI6Indvd2Jua3dneVNMaEVaOFk0QVY3MXc9PSIsInZhbHVlIjoiQms5NysyR0hBT0ovKzRJY1dqdlJBQT09IiwibWFjIjoiNDdiYmZkODhiMzIxYWZiYWQ2NjU4OTdhNGRmNjZiM2QwNTkwYzhlYzNjMmUwOWIwZTQ0OTRiYzEzMjA4ZjMyZSIsInRhZyI6IiJ9','eyJpdiI6ImZrN3dCSk5KbldpTUxrUmVPbHZhdnc9PSIsInZhbHVlIjoiaTJCOVVIT2lEMldHc0NmdncyZy8yZz09IiwibWFjIjoiOWM4YWZkZWRiNDViOGUyOGQ3OTE4M2UyNTkzNGEzNDA3MGM5MTNiNGQwM2QxYzFmMWYxMjFlYjAxMGYwYjQ5OCIsInRhZyI6IiJ9','eyJpdiI6Ik5NZlNxeWsrRUdHV0Z3d2x2ZmE1eFE9PSIsInZhbHVlIjoiNFc3cDA2N0IrMkFDdVNTM2FPVG1Gdz09IiwibWFjIjoiODhkNjA4ZDZkYzY2YWE1NWViMTIwZWJlZWIwOWRlYWE5MjcwMTE3YzY3MzZkYzMzN2U0ZTgwZjkzMGYyMGQ5YyIsInRhZyI6IiJ9','eyJpdiI6IllvVzh5T001dncwUFh6aG1QZldyRWc9PSIsInZhbHVlIjoiVzBQMHJycm11bExWa1hYaUdsQldHZz09IiwibWFjIjoiYWJlMjRiYzQyZGM2Y2RhNjZhOWEzYzFkNzE2ZjY0ZTgyMDhlNDc1ZjRjYjYzYTk3YmExZjc4Zjc5NDk1ZDQ0YyIsInRhZyI6IiJ9','eyJpdiI6Ikp2bERUL1F1N2kzOWhrdUhXNDk0ckE9PSIsInZhbHVlIjoiVGp0MkswK3NQczdGT25Fb0tWZDJDUT09IiwibWFjIjoiNzhmNmFiMWY4YmM0OGU4MTNjMTNlZDZkYWExZTE0MzdjZjkxNDM4YmMyNjA0N2YxNDA0NmUzYWFjOGY5NTk1ZiIsInRhZyI6IiJ9','eyJpdiI6ImkvRlQwWkgybHlqL3JxdUIrNEVVQ2c9PSIsInZhbHVlIjoickJVaGhlcXgwMzZ6L0h3eHdQb21QZz09IiwibWFjIjoiZjcyYjFlYmYwMTBjNWE1NmM3MGViMDQ1Y2MzZjI5MTZkOGM4NjYzN2M4ZjcyNzJjZmFmZTUyYTk5Y2U0NTNhNSIsInRhZyI6IiJ9','eyJpdiI6IjFaY3lIQ01DZ0ttcXJDQnVrbURCakE9PSIsInZhbHVlIjoiNVV1Mkk5Zkh6TFNWNTVEaEwwQ2pqUT09IiwibWFjIjoiNzM2MWU5YjliZWJkNWZiZWM5MzA4ZDFhNDFmMGRiNWYxM2Y5ZDQ5YWFmODYzNjUzNmJmNWE4ZGRhMzM3ZWMyYSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(32,33,'eyJpdiI6IkEzOWNRRFNOTWt3T281ckpIVXF1MHc9PSIsInZhbHVlIjoiT0MrNlUzYk5xR2xQSUtSSlBvQ25XZz09IiwibWFjIjoiYjYxYWJhYjE2YmNhM2U2NTA2ODY4YzAxMjU5MWViMGU0ZWVjY2QzYWY1MzJjNzQ5MDJmNWNlNjIyZWZhYTBjYiIsInRhZyI6IiJ9','eyJpdiI6IkJHb0h2UjE1cW4yRXpwODVRL2IySmc9PSIsInZhbHVlIjoiTktSVlhQNk52MVFrVTBSeDFPeTVBUT09IiwibWFjIjoiYWUxMzI4OWM5ZGViYzRiMDNkNTgyODU5Yjg0NzZiOGI5YTkyODcyYmUyMDdmYTk4ZDVkMzcxMjJlMzBmNzQ4ZSIsInRhZyI6IiJ9','eyJpdiI6IkpBZlo2N3R5TFF2MzZaQWM3UW8vWVE9PSIsInZhbHVlIjoiaEY4UXk3REdoZ24yRVRRVFBjMlNoUT09IiwibWFjIjoiYmM0ZTI2MjkyNDJkNjhmMzMzNDFkYTc0ZmQ3OTEyMDQzOTdkZWVhNzQwZTYxYmYxMjVlODgzYjYyMGYyODc2NSIsInRhZyI6IiJ9','eyJpdiI6ImxEb0toNEJsUWsxYm9oR2dBTGVCNXc9PSIsInZhbHVlIjoiSURJUnBsZ3UzekpXOFI3V3RLQ0tUQT09IiwibWFjIjoiNjk3NzAxYzg3YmI1MzgwYzc1NGZhMDIwZTRjYzM0ZTcxNjI0NzhjMDU0YTI2ZjEyODc1YWZiY2JhNDVjYzIyZCIsInRhZyI6IiJ9','eyJpdiI6IkVURE9CWC9aZ0I3V2I1cFgvcHJEaUE9PSIsInZhbHVlIjoiREZhMDZLSjA5UnFUakQwM2FKN3Jrdz09IiwibWFjIjoiMTgwMzYxYjViYzlmZGIzZGEwOTNjZDJhYjA1MjdkZDMwZDE0YzgyN2UwZTI1MmYxMmE5OWI3MjRmZDVjZWE2NSIsInRhZyI6IiJ9','eyJpdiI6ImdhTmRVMUVXSmQvemFlY1h3R0F2NlE9PSIsInZhbHVlIjoibWxrRzNSUTIwOGMvcDkxY0l1U1JPQT09IiwibWFjIjoiNGY4NDQ3NzEyZjZjZDJlNDk3NWU1Mjg0NTE5OTdmM2Q5NjVmODExMzZmNGRjZjljNzRhYmZhZjcwMDZiMjUxZCIsInRhZyI6IiJ9','eyJpdiI6IklVbU5xOEZoZDVIVUpmSE15VkZhNkE9PSIsInZhbHVlIjoiZm16cmNqY3JoL2J6aXpRaWRLbkJyUT09IiwibWFjIjoiMTYyMzA1ZTM1MzQxMTU2YTQ0NzRmYTg3MGE5ZWUwYjJjYWQwY2ZmOWZkZTJjOGUzNjEwMTRmYjUzNTZmZDFhYyIsInRhZyI6IiJ9','eyJpdiI6IklUTDh0cXlYWXdTZHVRbm9rTVA5T0E9PSIsInZhbHVlIjoib2sxWHRJbFc4UmQ0MXQxZ2lUZ3JGdz09IiwibWFjIjoiNmIzMWFjMDIyNmE0ZTJkZTNmOTg0Y2I0MDcxZGFmYmQ4NWNhYjA1MGZiOTNmYjUxMjA0NWRhZTA1NzU3YTU1ZCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(33,34,'eyJpdiI6IlBmWndDNHBaTlBxeWZETXhwaERHWWc9PSIsInZhbHVlIjoibTBJZ3JEV3g0WGhGUkJuUUplam5tQT09IiwibWFjIjoiYjFiNmVhMzc0MjNkNGRiNTBkMDIxZDdlODRkOWE5ZDJhNzI2OGI3OWE2OWQzN2Q4M2E4ZDM3MGM1MzQ1OWE1OSIsInRhZyI6IiJ9','eyJpdiI6IkMwTmZoWHdyNEFqN0tyZ0lnaDFabUE9PSIsInZhbHVlIjoiT25XUDd2VGFmR1hPTW56UEpBWDAzdz09IiwibWFjIjoiODM4N2NmMzgzZWU5ZDZiMDIwZDE4NjBiNDg3NTRlYWU1YzlmMTQ1MjkyYmVmZDY5ZjFmMmE5MDc4NjExMjc5NyIsInRhZyI6IiJ9','eyJpdiI6IitwU1FGT3hNM2FNOHlqUitrVTZQZ2c9PSIsInZhbHVlIjoiUnNmbDNkRzdnTnJJa3UvVzNTSWxEQT09IiwibWFjIjoiYjA0NmIzM2UzODlkMWJhM2RlZjZmNjExMjcwNDU3ZDJjNWM2YjI2NjFiMGNkZDJlZmZhYjIwNTAwNmMxYWQ2ZCIsInRhZyI6IiJ9','eyJpdiI6IkVvS2JCRFM5dWJGQ01tNFFHaVhWaFE9PSIsInZhbHVlIjoiOThCYk5ZVHBjWXg5aGpvVzgwNkVEQT09IiwibWFjIjoiNDg4ZDA4MmFhY2JiNTBkOWEzYTMzZGQ5MjUwYzRlZWZkZWZmYjc1ZDE2MzY1YzM1MTUyYThlZmExZjQ0YTRlNiIsInRhZyI6IiJ9','eyJpdiI6Iks5T1Y5QWVxSG9rQzFRQ0VFWDlGblE9PSIsInZhbHVlIjoiZnM5ajUyTTEyRndxdm9xR1JVYVJwQT09IiwibWFjIjoiY2RjMWVkNTgwZjYxZDMyYjlkZWUxOTBmNjBhNjc4OGZhZmUxOTc3ZGMzNTY1NmM1MDVmOWFlZDhlYzEzMTlkYSIsInRhZyI6IiJ9','eyJpdiI6Im9Xa3dTUXZuTkhBMTJlbStRbjkraFE9PSIsInZhbHVlIjoicGFOeCtvVklxUitJaGxQa0pMZGVsdz09IiwibWFjIjoiOTQwOWY3MTRkOTIxYjQ3ZGNmMzExYjhkNjc1MjlhODc0ZWRlNTc2YmNlNGIyYmViZWE0YTQ4YTE1NzZiZGUwZSIsInRhZyI6IiJ9','eyJpdiI6IjQ3azhYWFhtV1YrQkM0WDdQTk15Unc9PSIsInZhbHVlIjoib2JqWVFnMit5ZWtER04venBQQzdRUT09IiwibWFjIjoiZDdhNzlmODk5ZDBkMmQ0MDViNmEzN2I0ZjE5ZDhhYWVkNDFhNmY4Mjg1Y2RkZDFiYWY1YWI4ZDgwNWNmMjI5NiIsInRhZyI6IiJ9','eyJpdiI6IjFUcE5HWmhhL3VZQjVKWGw0MmptU1E9PSIsInZhbHVlIjoiYlcvMTdKc2V2VGlQSmtzejVoc2l2Zz09IiwibWFjIjoiOWU0YzVkNWFjZTFjZTUzNWM5YjMxYzZkNDQxMDFhZDY2Njk2ZjhlY2EzZmE2NzExMzVhODIwMDhhYjQ0YTUwOSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(34,35,'eyJpdiI6InZkVHFOTDI3THUxdHhGSHh5RlJyZmc9PSIsInZhbHVlIjoiVHFhRjlKczNvODc5ZGpDOUJ2WHBSZz09IiwibWFjIjoiZTZlMTlkNjEzNGJhNzA2MzgwYjI0ODgwYTBjOGQxNDYwNTgyNjEwYThkY2ViM2Q1ZTkyYWIyOTliM2I0Nzc0OSIsInRhZyI6IiJ9','eyJpdiI6ImVxUjd3OUdYaFBJekVEYXZGL3E2RkE9PSIsInZhbHVlIjoibHdqSzgrUEp0UytKQTZYaDdwMDFqZz09IiwibWFjIjoiMjdlMDllMWEzYWQwZTg3MDM1NjFjMDBhNmVkMjdhOGExZDI0YzE0M2ZmODE5OGQ4ZmU5YjU0ZTcyYzY3Njg2ZCIsInRhZyI6IiJ9','eyJpdiI6IkQ4OG5qV1VOQkNhbFZPdEY3MWJmVVE9PSIsInZhbHVlIjoiRFZVdDFlRTRYc2ZiRHYwNWJ6WjRVdz09IiwibWFjIjoiNWZkZDU3MGEyNDljOGM0NTk4ODJkMGU4NzYxM2FiNGUzNWIxOGVjOTgxM2I1ODEwMWMzNzg1MGJmYjA2Mzg4YSIsInRhZyI6IiJ9','eyJpdiI6IkdramxBSlhYa3oyOGhCUWFzUllOdlE9PSIsInZhbHVlIjoiV0d0NVJCZEtJTHFnck9aeVJLaGRLZz09IiwibWFjIjoiMThkNmYwZjUxMTRmYmMxZTdkMjFjYjZjYzk3MGVkMjVhN2E3NTdiNGYyNDliNmI1OWY5ZjkwZGNhZmY0YjI2YiIsInRhZyI6IiJ9','eyJpdiI6ImwyT1JjQXVvN0phYW9PT2xxSlpyOEE9PSIsInZhbHVlIjoiZTRBY0J4cjJHTlJQTTJkdm4zbVF3dz09IiwibWFjIjoiYjU1ZmQ2YmM1NTgxYmIzNmNjYjEzODk2YTE1MTQyMjAzMzIxNjYyNTRiYWJhZmE3MzlkNDQ1NDcyNWY1MjMyNCIsInRhZyI6IiJ9','eyJpdiI6ImpmbmZJdERuYzZpWW9DK0d0SGsyN2c9PSIsInZhbHVlIjoib2QxaGxHUjBna1M2VTRIcDBzYm0zZz09IiwibWFjIjoiMGZjZjE4MDc1NTUyMTk2MWRhZDFmNGUzZGJhNGVkZjEyZTlmYTZkMDRmNzFkYzNjMWJjNzkwNWFiNjE2MDJmMiIsInRhZyI6IiJ9','eyJpdiI6IjFNMFFWV3p5Z3h5dzRvTDFCM1gxNVE9PSIsInZhbHVlIjoiQmc1MHdPUFFUM0ZBbjBSZjlkeFAxUT09IiwibWFjIjoiYjUxYjRlMDdmODU1MjBlNzYzNTQ2NDQyMzExZjg4NzlkNDFmZTE3ZGU1MGQzMmQxZDA4ODE5MTVlYTNiYzUxYSIsInRhZyI6IiJ9','eyJpdiI6ImwvOFFwOExqempyTDN4ekVHMFRaK1E9PSIsInZhbHVlIjoialVtT0ZuV2kvQllUWnV6SGtFVDFvZz09IiwibWFjIjoiYjZmYjY4NTMxMDNiNzNmYThlMzI0YWFkNGFhYWU3YmZkMDRjMDBiMWQyNDFhZmMzNjk5ZjE4NDQ2MmY3YmU2ZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(35,36,'eyJpdiI6Im5GRy84UFF2dDkxdDNXY0VLL3RxK3c9PSIsInZhbHVlIjoiSHZIVWl1WGlZNkRLVUZmRWE0YmN0dz09IiwibWFjIjoiNTIxYmI0NzhiYTZjMTdmNzM3NzY4OGQ1OTM3Mzc3NjEwMWI1OWE5MDMzYTNhNmZjZDY4MjVkMmEwZWE5YTE4ZCIsInRhZyI6IiJ9','eyJpdiI6IndwRDh0dmZtaW5PWWtRY0NEZ2J1YXc9PSIsInZhbHVlIjoiejhoRDBRc2xub2Uwb2orZzAzZ3JrZz09IiwibWFjIjoiOGUxMmFiNDVmNTE0YjY0OTg1MDZmYmNjNGExZTgxNTc5N2VmYTIyNThmN2Q0NjA4ZDFjZTg5ZDAwZDM3YjZlNSIsInRhZyI6IiJ9','eyJpdiI6IngxV2dGZWNSNEsrSWFpaXVUSjF4UEE9PSIsInZhbHVlIjoiQUJ4NFhWa0JDS3hyNDNFMG0xckM2dz09IiwibWFjIjoiZDllMWZjNjMxYzI1ZTE1YmJlNGEyYzFkNTFkZDZmYzk4MTIyZGQ1MTYxYTc5OGE1YzYxNmQ5NjAwNmY2ZmU5YiIsInRhZyI6IiJ9','eyJpdiI6IjZhREtBK3VUbzlWcFZzcUVGbVR3Tnc9PSIsInZhbHVlIjoiYWFlUk5GZGtGcjc1RThMcUthYU15QT09IiwibWFjIjoiZjkxNDQ3YzczMTczZTE5MzBmODA0YWIwMjE2ZDNmMmNjMWVkYjgyNGZmZjU2MGVhZmUxMTZmYTY1N2M0MmYzMyIsInRhZyI6IiJ9','eyJpdiI6InllM096bm9NVHNya1pqN2w2Q20rQlE9PSIsInZhbHVlIjoiZkpYZFZQWTFxcytWUjhoZzQ5cTFGQT09IiwibWFjIjoiNmJjYTk2ZTJhNzQxYzkzMjQ2Yjk5MTI4OGQxOWM0NDA3NTlmOWJiMTZmYjNhODdhYjY1MjE2ZWY1NzNjM2JmYSIsInRhZyI6IiJ9','eyJpdiI6IjZuZ0V4RUpSNWluOFZzZGdKeHJCbXc9PSIsInZhbHVlIjoiOEIyRlE1QVBSaGhIZWRyT3JRQ0N1QT09IiwibWFjIjoiODYyMWVlMmNiMmZiYTZiMmM4ZWRmOThiYWZjMzg2MDBkYjcxODk2NWQ3NWZmOGQ5NWU4ODM1NzRiOWE3YzEwMCIsInRhZyI6IiJ9','eyJpdiI6Ikh0N0J3NllIWE12Mk5hR01KaFREU0E9PSIsInZhbHVlIjoieTR3dDk1bHF5M1BoM0VIbUV0Nk5sQT09IiwibWFjIjoiMmM5MGFlMTJkOTFkYjRmNWM1NTlhYTQ2MjY3YWM2YjEwN2UyYWFhNDdhMjIzYTUzNDNkYjZhMTg2NzNmYjFhNyIsInRhZyI6IiJ9','eyJpdiI6ImcvbnRqQmdScEhyRm0wQjVMYTNXSEE9PSIsInZhbHVlIjoidkRhZmdrbGloYThwN1lYZGQveXF6UT09IiwibWFjIjoiNmU2Y2Y5MGE3OTgyYWZjYzY0MmVhMDQzZjkzY2QxNDE4MGNhYjc3NTI1YjU2ODkzMmEzZTA4ZGI4ODVmZmQyMSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(36,37,'eyJpdiI6InVDSG0xSWI5cDB3Z0M0UDZjNGNvMEE9PSIsInZhbHVlIjoicWM0SUlRbHR4T2I2YytxMktrbFNHdz09IiwibWFjIjoiNzJlOThlOGQ4MTRmYzZlNjU3MjI5ZGMyMTQ2MTIxYWI0Y2ZjYjc0ZmRkMGRjZDA4MTNlMjUwNGY4OGVlZDE4ZCIsInRhZyI6IiJ9','eyJpdiI6IkNORUJ2VGZJRy83TzQ4ZXEyQ3VoSXc9PSIsInZhbHVlIjoiMEhETGdRVVpYUmw2aFhqNG5ZZ1pkZz09IiwibWFjIjoiZmIwNWUzZTkyZDI0ZjEwYjNlODU2OTgzNWUzOTk2YTFkZGZkYzA4OTg0OTBiMWE3Y2EyN2U3ZGE2M2I2OWQwZCIsInRhZyI6IiJ9','eyJpdiI6Iko0S244aVVmQ2V6aWNiQ3R4TU5vZ1E9PSIsInZhbHVlIjoiazlHUHJsWUU4UmRBdk8wekZrc2ZoQT09IiwibWFjIjoiNTllYmI1ODUxNmJiZTI5YjE4YWQ4ZDY3MWI0OTA3ZWE4OGRmZjM0M2JlZDQ0NjYzN2Y2YmViNTc4MzMxYTU1YSIsInRhZyI6IiJ9','eyJpdiI6IitwNG9aWXh3Z1NqdlJycTVWZGNQblE9PSIsInZhbHVlIjoiRUlGOUk2Q2E2a3o1VzZ3Z3BZM2xYQT09IiwibWFjIjoiMTVmMmE1MjNhOTFjNTI3N2EyOGFiNDlmMTA4MjUxYWEwZjRmNGFiOTJkOTEzM2Q1ZTdkZGI1OWI4MmMxODM1NCIsInRhZyI6IiJ9','eyJpdiI6Iiswd2U3Sm5BVUQrQWhqVzFvUis2YXc9PSIsInZhbHVlIjoiYXRTQTQ0R1dTekhvdWRRa08rT3dWQT09IiwibWFjIjoiNTY2MTBiOGEzNGYzMDRhZTA5ODI2YTczN2YxMzFjYWMzMWU0NTlhOTA2NzFiNjhlYTUyZmVlMGU2MmQzNTM1YSIsInRhZyI6IiJ9','eyJpdiI6InVOVXlRa2RhVmJPTjZvTFNDbFVxd1E9PSIsInZhbHVlIjoiNkF5eTM4ZERHdHhOVE44OTdHbFZCdz09IiwibWFjIjoiZWQ0NmIwOGFmMjhjYWMxNmNmYTI4MTIwNGYyNWMxMzI4ZDY5YjNjMzlmMjg5YzIxYzU2ZTU5ZjRiYzU5ZjAzMiIsInRhZyI6IiJ9','eyJpdiI6ImExdmdsL05rdG1MZzFhNjBJM0tjUHc9PSIsInZhbHVlIjoiTzVHZUpTNVFtblFhME14WTVvZ3R2Zz09IiwibWFjIjoiZTQ3ZTBhY2EwZjNlOWY2MmFlMThiOGMyYzVkZTFkODBjN2MwNjAwNTU0MDRjYmYwODA1NjM0YWI0YTZhZWI5MiIsInRhZyI6IiJ9','eyJpdiI6IjROSnAzdzdWeGUyWndzWENldXl3T3c9PSIsInZhbHVlIjoiaWtDemRIVVdrWGNNRGpDWjRmWVFHQT09IiwibWFjIjoiN2UxYzI1NjliZjU4NGJkZTE5MTQ2MzFmYTk0ZTM2MjdlMzQyMWJlMTlkZDg2YmY1Y2Q3MWY2MzE5YTU2ZDBhNiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(37,38,'eyJpdiI6InVMUTBRM25pUGFCdnJzRzJWTUcwTkE9PSIsInZhbHVlIjoidzBSNHF4UC9FeU5DRFdCNHRzVTVBZz09IiwibWFjIjoiN2VlMWQ4ZGNiNGM1NDU0NjE5YmJlNjBjMDMxYzQ1ZjQwNDRjZWE2NWJmNTg0NWI0YTc0ZTFkZTE5NTcxYzI5MiIsInRhZyI6IiJ9','eyJpdiI6Inp3YlJZTXl1M0d0aWh2UG45RUlTS3c9PSIsInZhbHVlIjoiN3FieTd3dWFFTHhlRkwvUWRpNlFvUT09IiwibWFjIjoiYTRjNzljZDQ5NGU1MTYyNTE4MjBmYjc1MGUzYWUxMzRlZjljMDg3OGRkNjhmM2QzYTRiNDFlZjE3MWQ1MmY2NSIsInRhZyI6IiJ9','eyJpdiI6IlY3aWFFb1dJMEU1U2xKV1JURlk2QVE9PSIsInZhbHVlIjoiQk12aURUTHFxa2RtMFpMS3BHWmc4Zz09IiwibWFjIjoiZmMxNzY0ZTFjNjkzYTQ5MGZlMTk4NzgyZDNmN2YxYjZkZDEwNjU1NmFiY2I5NjllZmExNDc5ODM4YTU3ZTI4ZCIsInRhZyI6IiJ9','eyJpdiI6IjhIT2xLYzNmYVJUMDJ3eVFxTmRQb0E9PSIsInZhbHVlIjoiNWhKY1ovUk42d3NPMEVyY3Z3WGQrZz09IiwibWFjIjoiNzljMjhiYmNkOWE4NThjNGE0YzZiNGQ2MmYxMzcxZTgzZTVlODE1N2FkNzg2NzFjY2E0NDlkM2NhYzk3YTEzOSIsInRhZyI6IiJ9','eyJpdiI6InBNQ0hFa3BuSGRVMy96cnRxVnNzOGc9PSIsInZhbHVlIjoiWGlZblJKY041WGRZNTJpZWtvS1BmUT09IiwibWFjIjoiYjgwYjAxNDMzMDY0ZjA5ZWExNTM5ZjZmODhiNjhlYzgyNWQ2ODk4MjdiY2Q1YTBjYjM0YTZhYjIxNDkzNTM2NCIsInRhZyI6IiJ9','eyJpdiI6IlQwb3p1M0MrOWNlV3dlNk9IY1k4aUE9PSIsInZhbHVlIjoiemgxbVUyTWRNSDlDbm8rc3hrN3VVUT09IiwibWFjIjoiMzQ2MWM4MDIwNTI3NDFmZWI2NmFmNTlkM2Q0MzM2ZWYzYjE2Y2ZjZTM3ZjRjYTk5MGZjNzQwZTQ5NGQwODcxNyIsInRhZyI6IiJ9','eyJpdiI6Inl4Z1NDcWpLSlhoREhkNFBuLzFsMFE9PSIsInZhbHVlIjoiK2hyWVY5SkhtSlFsd0NESWQrVVRqQT09IiwibWFjIjoiNGUzMWRjMzQwNjJhNzBlNDVhNWNhYzA2MmRkMmVjNDlkNmI1OTViNTIyZDlkNjU0OGVjM2M5NDE2NjRmMDRlMiIsInRhZyI6IiJ9','eyJpdiI6IjNkNW82QWVhdDY4OXJUdVZHRmVPeVE9PSIsInZhbHVlIjoiY05qci9BL0FzTE4yUDNPYzNPYXVQdz09IiwibWFjIjoiMDc2ODlkMTc5MmVmNTIyMjE1MmQxODFjMTJmNTJlZDdlNzdjNzcwNDJjNDRjMjQ0ODFhZGE1YjljZTkzYzk3MCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(38,39,'eyJpdiI6Im50MmNsSXIrVEJaM1VBM09NSWgwWnc9PSIsInZhbHVlIjoiSTZ6OVBTSWdYOE5STm9sZEtRLytKUT09IiwibWFjIjoiYTJhNmE5NzY1YjE1OWVhODYyYzY0Mjg1NjRmMDBiNWE1ZTQzZmJlMjUzMzFkZjk0YzYxNmEzM2ZlMzQ3NmJiNyIsInRhZyI6IiJ9','eyJpdiI6Im56SmZkdUNGYUVhSUFUZTRvQkp2blE9PSIsInZhbHVlIjoiYkk3ZEdTNE51VUNQeFJkYmIzcE10UT09IiwibWFjIjoiNzBlZDQ3ZWJiNDk0ZDdmMjU2ZWI4NzcyZWFhOWRmOTJjMjFkNDlhMDJhNzAwM2RiMmMxNWQzYzFiMjNkMDIxNSIsInRhZyI6IiJ9','eyJpdiI6ImtQOWJ5dUcyUjNiOWFQa2ZTTldMV1E9PSIsInZhbHVlIjoiUXBpODNQTXpOK0N5YjQ4U2JQQzl5Zz09IiwibWFjIjoiM2M3YjJlNDkzNzdlMTMxZGE2Y2IxYmJmODg3M2EyMmFkYmIzN2Q3NzA4OTRlMmZlY2YxZDYyNjQyMzgxZDEyZiIsInRhZyI6IiJ9','eyJpdiI6InowZUNFRmdCcjkrVWZyM3VCRk11eUE9PSIsInZhbHVlIjoidDcyWWhQc0tSMVNSWXJ0R0ZzbGllUT09IiwibWFjIjoiMGZhZmMzYzcyODZkNTBhOWI0MDQzZWE3MjhhOWMzNzE0OGQ2ZjQ1OWE2ZTllZWE5ZTA0ODNlODcwYjJhYWQ5MCIsInRhZyI6IiJ9','eyJpdiI6IkRXdXU4Ui9sMzhtZWQvdEFWbFcwNlE9PSIsInZhbHVlIjoiY3ZWTGhNQTRlT2JTNGhDajdSRFhTZz09IiwibWFjIjoiOWU5NTg4ZTBlZWQ3Mjc0YzNkODVhZDM5NTc2MTBhMzU1M2Y0NWVhNDNlYWUyNmUwMTUwZjhjMmQ2NDRiZjhmZSIsInRhZyI6IiJ9','eyJpdiI6IlB0VTkrNURBWlBiMGNHUnJScWlNMFE9PSIsInZhbHVlIjoiSXNuNWd1c21LdjZtUnhMY01GOGozQT09IiwibWFjIjoiNjAyZjVhM2MxMDU4NDc2YmE1M2MxNTRlN2E2YTYwMjhlYjRmNDMxOWIzOGY5ZGQ3NDVmNGIxN2MyYmVlMTY2YiIsInRhZyI6IiJ9','eyJpdiI6ImRBZGZmQjB2S3huOTdEWDRQTWM2UGc9PSIsInZhbHVlIjoiNkVFa3g1T0lHNWJQTzQ2V2pSNmordz09IiwibWFjIjoiOWU0NjkzYjQ0NTVhMmQ3NTQzYTk4OTQ3NWQ0ZTM4OWMyMTE0MGUyNTBhMzA5ZWNlZDEwYWY2OWNjYmE0NjU4MiIsInRhZyI6IiJ9','eyJpdiI6InJhdUVvLzdhbG5ra2ViSzVVWXVxcWc9PSIsInZhbHVlIjoiMTJUWm8zWE92RVJyWWlYNjI2NURLQT09IiwibWFjIjoiNGUwMzgzNTRmOGZlZTNlZDA4ZGUxYzI5NGYyYWEzMWVhYmVjN2UwOTE3OWIyN2ZmYmE0MTg5YmYyYWZhNWM5NCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(39,40,'eyJpdiI6Imw4aFE3Y1dsSFhFOW5GUldGSVBCSkE9PSIsInZhbHVlIjoicjBWSkpRL3VDWUxMK3laTTAxRjc2dz09IiwibWFjIjoiODFlNDNmYTc0YmI0N2IxNDAxZWVhNTJmNWJmNjczNjU4YzM1YWQwZmQ0YTExNGY1NTZiYTkyMzVkYjc1NjMxMSIsInRhZyI6IiJ9','eyJpdiI6ImNwMFZOVXFSYlR2dXpSOFVWd1ZKVkE9PSIsInZhbHVlIjoiU1pXMzVzUnJWckljNHdZMWNFV2EyUT09IiwibWFjIjoiNDc1ODg1MWU1MTY0MzRkOTMzY2UyMDBkOWRjOTQ2MjlhZmEzOWMwY2ZiYTMxMDUzNDM2ZGM3YzJkMzk2MWM2NSIsInRhZyI6IiJ9','eyJpdiI6Ik9yM0FIZDdCem1mQ2VQRkYvUDhPWWc9PSIsInZhbHVlIjoiQXMzMUlRZUhVc1lab2tld2Q2K3pYQT09IiwibWFjIjoiMjg1YzA4MWZiZDFkYjkyM2E1YzQxZjQyMzkxOTg0NGExYTQxYjFmYzVlMjFjNWVlMGFhNTQxMmFkNDRiNmM1YyIsInRhZyI6IiJ9','eyJpdiI6InFpODdrWUV4cmFSeU1oLy93bVMveFE9PSIsInZhbHVlIjoiQnllTWZ3VkFoQVBmaTNzSFVxbWlVZz09IiwibWFjIjoiYTUxNzJiYWY3MjI3OTdlNTg0NjBlMWQ5YjNhOTk0YzVkNmE5NjEzYjhhMDUwMGZiOGRkZWNiM2RmNjZiNDZiMiIsInRhZyI6IiJ9','eyJpdiI6Ii80Qk13ZjkvZE9DakxjNFh0MEZvU2c9PSIsInZhbHVlIjoiMjNEbUg4eG1aTjVaNUQxNnFRTnJNZz09IiwibWFjIjoiOTk3MzhjNjY4ZDE2MTY1ZmYxMjNlM2QzYWY1OTYyZTg2ZmM3YjEyZjI1ZWE3ODczOGNmZjA5ZmFhZjlkZjUwZiIsInRhZyI6IiJ9','eyJpdiI6ImJkVjlHc3JSVmxiUncyVFZtZXpyT3c9PSIsInZhbHVlIjoiK3ZXTHhkc2JwYkI3VGx6U2hKTTNpQT09IiwibWFjIjoiYTI5Y2FkZGU4N2Q4ZWJkNjAwYjAyZGZiNmJmOGE3ZGJhMGIwZjZiY2ZjNjk4OTg3ODA3NjAxY2I2N2ZiMWQ1ZCIsInRhZyI6IiJ9','eyJpdiI6IlBzVmRxR3hjaCtZaXA1Z3ZNSjB3WGc9PSIsInZhbHVlIjoiZ3YvMXFPNDJ5TzlEaHo3M1RUNDJmUT09IiwibWFjIjoiZWE3MzcxM2RkMWE3YTYyOGQzMTdmZWU1MDgxZjg2ZDdlZWVjM2ZjYzg1YTVhYmFiNGFkNjRhNDNhYzQ1ZDdiMyIsInRhZyI6IiJ9','eyJpdiI6InRibHFlMWVLYXBUVVo5OU1OaUFMS0E9PSIsInZhbHVlIjoiRmN3UjJMQ2todlJmdVdmeXo3alBoQT09IiwibWFjIjoiNDlmZTdjYzgzN2RmYzcxZTE1YmI0Mzg4NDk4Yzc4NmYxZTJmNzhjMzYyN2JhODM4NWMyODc2ZTAzNDY1Mjk1MSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(40,41,'eyJpdiI6InBWL0p3cXZCMDBIZ3F5MzZUWC96YUE9PSIsInZhbHVlIjoiZHRyak1RL2RoOHRUSUxNMDI1czNoZz09IiwibWFjIjoiNjNlNzc5ZjNjYjI3Y2UwMGY2Zjg3MGFmNjA2ZDlmMWZjZjYwMzY3YmRiODQ4YzQ4ZTExMDVkNmFmOGY1YmU2YiIsInRhZyI6IiJ9','eyJpdiI6IldnRXEyZTlYb25kbnArZy80VVV3b3c9PSIsInZhbHVlIjoiRVoxeEd1Y0hETm5ETTJuRkpFU0RpZz09IiwibWFjIjoiNWIxZGQwMTEyMmU5MTlmNDM3NWE1OThhNDcyMGU3NjA3YjBkNzU3MDFlZDg0NjcxNGIzMTY5ODQwZDdmNzA5ZSIsInRhZyI6IiJ9','eyJpdiI6IkZtVWFIU3R1czdqb2N1ZDR3d29SOGc9PSIsInZhbHVlIjoiR1BOeTdBTHc3dDN0NHc4TTZ2ejhGQT09IiwibWFjIjoiZWQ4OWUzNjJlYzI1ODQyNTdmMzRiYWI4NWQ5MjRhMDUxN2Y2NDFiZTUxOWJlMGE3MjZkNzQ2NWRkODkyNmJhNyIsInRhZyI6IiJ9','eyJpdiI6Im5Vc2t6bTB1QWo3Z2p4RmJ4Q1dHNHc9PSIsInZhbHVlIjoiWjhhYUt2S2JPdmtqdnlsdGs2dmZVQT09IiwibWFjIjoiYjgwZTU0Y2E1MmE1YmM1NmNkMjVjNDFiODBhODMyMGMwOTU0ZjM0ZDNjN2U5ZWE4Y2U0MGYwOTY3MWVlNGViNiIsInRhZyI6IiJ9','eyJpdiI6Im1Gb0I4YW8wYXdQTTNEZGFjT0lXOWc9PSIsInZhbHVlIjoiTENrVjR0aUVacjFoREVlOU1hL0ltQT09IiwibWFjIjoiNjdjZjc3OTMwYzk2YTA0NThkYWViYjg1NGVlODhjYzRhNWYwOTZiMzJjMzQ2ZDZkMjNiNTcxMGE1YzMwNDM2MiIsInRhZyI6IiJ9','eyJpdiI6IlpFOXBhOG1yNFdlYTZTajZwWnFrK0E9PSIsInZhbHVlIjoiaThMQlVUTTFXODk5MG9nd0NqZ25Fdz09IiwibWFjIjoiNWIzNGUwYTY3NGFjYzc0ODYzYmExMzAxY2ExOTYxZDA0MmFhYTZkMmI2NjkxMTg1YTQ4ZGE0OTdlMGViNWFmMyIsInRhZyI6IiJ9','eyJpdiI6IjB5NFJhOGdVNm9mc2VSdURtQVVYMFE9PSIsInZhbHVlIjoiZFF5ZzdzODVEZHo5RVZXSGRqSS9xQT09IiwibWFjIjoiZWIzMzhmMzU3NDJmNDNlNmI2N2VkNDYwOWUyODY1ODM5MTJjYTliNjliYmUxN2RkYzRlZTkzMDYwNDI4NmFkOSIsInRhZyI6IiJ9','eyJpdiI6IituNWFpNGdCbktIMFR0WmQydEZSK2c9PSIsInZhbHVlIjoiTENIaGtUR1F5YnhDSmRjZmVxcGFQUT09IiwibWFjIjoiMDVlZTIzMzZkMDIxNWQ4YjE1ZTNiZDU1MzUwM2MyOGNkZGZmYmI1ZThhMmE0OTc4Njg3MWE3ZjdiYjNiZTA3YSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(41,42,'eyJpdiI6IkFBS1k2T0RUdjRPc0FaS2ZIT0lMOEE9PSIsInZhbHVlIjoiTHBFczQvQjQwZmVYTVJ5dHlLYXVVZz09IiwibWFjIjoiN2Y3ZjRlZDM0MDg1NWQ3NTg1Njk0MjQ5ZjM3MDM4YzgzNmNkYmViZjhjN2VmM2JmMzk2YmExZjI2NjdjNjg0YSIsInRhZyI6IiJ9','eyJpdiI6IkdHWnNtbi9kK3VKVmRwTHNMTEpUcUE9PSIsInZhbHVlIjoia0lhWVlzVExCbzBDb1lwZ000c0xQZz09IiwibWFjIjoiYTY4MmVkMzE0ZDgxOGE0M2EzNGYxNDg5ZmQ0MDgwYzM5OTZjNDkyNGFjMzdmMTc5M2Q2NDQ3M2FkM2QwMWRmMSIsInRhZyI6IiJ9','eyJpdiI6Ill4UThCMHJybllFOW03aXVMTEoxcVE9PSIsInZhbHVlIjoiNjAzT0VQREVQc3pZK25JTmF3M0pFdz09IiwibWFjIjoiMGQyNjlmYWY2NGNiNWRmMGJmMDNjNmI1ZThjNmE4NGRlMjQwNzY3MmE1NTg0MmNiODYwNzRlNWI3OGU0YjYwNSIsInRhZyI6IiJ9','eyJpdiI6InRMbXEzZmYrdG5aWWhUTWF3TEo0Qmc9PSIsInZhbHVlIjoiZ0F4YUgxZ045LzQyYjNQck9jZVdjQT09IiwibWFjIjoiZjU4MTQzNTZiZGY1YmI5ODNmNDRlMGQ2MzVlZjA5NTQ1MjdhNWU4NDRiZmU5ODdjMWQwNjJmY2NjYWM5NzJiMCIsInRhZyI6IiJ9','eyJpdiI6ImF6blFsU3NGRzE1VlZBQ2ZkWjByaGc9PSIsInZhbHVlIjoiSTF2b2pQaWdmd2dVWEdmRHdsM0VxUT09IiwibWFjIjoiN2U1OTc1MWI2MWM5ZmExNDYwYzMxYjVjYTY2ZmI5NTIzMDAwNTU0OTVkOWEyMmM5YTM5NGVmYzc2ODAwZjE1ZiIsInRhZyI6IiJ9','eyJpdiI6IlBhSGpUcHFubzdMRWl0bFZFWUF2dkE9PSIsInZhbHVlIjoiSSthdHBKTzFQaVkzeXlTWW5tWnNWUT09IiwibWFjIjoiZWUyNDNmYWQzMmM1ZDhkZGUzMmRmMWUzMWYxYTk0YmNiMWE3YzQ0ZTQ3NmUxM2ZiMDQ4M2Q1ZjY0YWZhYzJmNyIsInRhZyI6IiJ9','eyJpdiI6Ik9NdFdheGovYzNJTXU0TW5yWFBmY1E9PSIsInZhbHVlIjoianZKTkxNc1lqVHZrKzBJWVk0MCt0Zz09IiwibWFjIjoiNDllZmJkZjhmNmU3NzJjZTMyNWEwZjFlYjYzNjhlOWYwODUzMWE2MmMzN2U5ZTc0Nzk3OGU0ZTAwNWNhMjgwMSIsInRhZyI6IiJ9','eyJpdiI6IkpGSGQ0QUN1c3Q0U0hCemVvVzBkUHc9PSIsInZhbHVlIjoiN2M3NE5ZcE9Pcy96NU94VFpJbSt3dz09IiwibWFjIjoiYTE0ZTkxNTNlNzQxNGNkZWQ5OTg0NGNhNGRlYWQyMjY1MmI0ZmYxN2JiZmQ3NGY0YjhmOWU0ODc5OWYyNzRkZSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(42,43,'eyJpdiI6Im1iZlVoYnRXZDNIRTN4QXR1YVBacEE9PSIsInZhbHVlIjoiUGFESzFmTzlMdUhTSmd1R01wNDd0dz09IiwibWFjIjoiMGI5MmE2ZDBmZjEyMDE4NjRjZmY1M2M4MmYwMzdiMmMyYWFjZDdjZDFjMTYxMjMzMDM1MDZmYTc5NWM4OGY5ZiIsInRhZyI6IiJ9','eyJpdiI6Im5SN1kxc1U0TFhBeThSR1BTdkUwUVE9PSIsInZhbHVlIjoiNzdHdW1BM2dxZmV4NEZsMm5lR0Rsdz09IiwibWFjIjoiMzBmNTRlNGVlZTkxYTM0NDVlYjZiZjJmOTBmNGJiNDUzYzg1YTQ4OWE5NmI3MGQxODBiZWFkZjc1YWE5MmMwYSIsInRhZyI6IiJ9','eyJpdiI6Ik1jb2JaM2xCbDJqZkdGdnVCSm1DaXc9PSIsInZhbHVlIjoibUdpcXVBRWZPaVkxeXRrQytjWWtHZz09IiwibWFjIjoiMWE4ZDRiYzkyNTFkNzE3Yzg0YmZkODhlNThkN2U4MjRkYTg0MzkyYzYxYmU0OTg3MDYwODgxZWI5NmJlMThlZSIsInRhZyI6IiJ9','eyJpdiI6IkZCRWpHWjVDRUdnSHhXbmdKZVlpK3c9PSIsInZhbHVlIjoibFFlZXBmcHFUemRiU0VPL3FLQzIwdz09IiwibWFjIjoiZWNmNDFkNjBmN2QxMDM3MjE3OGJhNTBhMjU0NTEyYmJjYzhkYTRmMDE2ZmE0M2QyYmYwYWZjOGFlNmNlYTQyNCIsInRhZyI6IiJ9','eyJpdiI6Im5KM0FQcjdUSlVxc0tIL3FoeUFjc0E9PSIsInZhbHVlIjoienZOZ1ZHeFNnOW1PaEFPZ3V2clJ1dz09IiwibWFjIjoiMDI5OGU4ODI1MTEyOWE5NjY3YjUyNDM3ZjQ0ZjQ0YTFhMDA3ODIwMzgwNjEwNWUxMTk0MmZkNzdiYWRmYWMyZCIsInRhZyI6IiJ9','eyJpdiI6InMvTTZXTi9yeGtQQ1A4UzZPTlA5T0E9PSIsInZhbHVlIjoid2NOc2dGTjh2WmdNaWJlMXFxUXU2QT09IiwibWFjIjoiYTE3ZjdkZDQwMWI2MmY1YjhkYTI3YWE2ZjNjMDc4NmRjNGQzMDZhMmY4M2RhZWIwMTIxOWJjOGJlNDkwZTljYSIsInRhZyI6IiJ9','eyJpdiI6Ill1d2dLKzR0S2ozaVg2MnBrWGZuM1E9PSIsInZhbHVlIjoid2lVaXRCS0diOTNnQkhBYlM1T3RVdz09IiwibWFjIjoiYzliMWQ5MmZmOTc2NGFhMTMyNWRlNGQ4ZjVkN2VkN2MxOGEzZjUyNmIwMzg2NDhmYTQzOWIxNjc0NmE2YmE1MyIsInRhZyI6IiJ9','eyJpdiI6IlVaRi9UaDF5UVhCMDhkUjB6TGNFaEE9PSIsInZhbHVlIjoiZHNVUzlsQnNlQjB6K2p6UGM0NlBNQT09IiwibWFjIjoiOTExZDA3NThkODAyMzVkZjcwNjI0ZWVjZjllYzRhZTM0YTJjZDZhMDM5YTA4ZTlmYTEyNDViZTg2NWExMDY2MCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(43,44,'eyJpdiI6IlEzelZMMGpuWUpTenFjbE9EZHo5c3c9PSIsInZhbHVlIjoiZVBzTlJ3VWFEYlRGTWRNNmFnc3k0QT09IiwibWFjIjoiYTE0NTJlMjhlZjliNDBmOTlmYWM4MWQwMGNhNTcyMjEwMTEwMjRiYTM5N2ExYWY4NTk5YmM5OWM4NWQwZGVkNCIsInRhZyI6IiJ9','eyJpdiI6IkpPOGFCM201RFREdGN2T05vdlBoVXc9PSIsInZhbHVlIjoicXV5ZWgzeDlXd3h3UWhOWEgxSHNpUT09IiwibWFjIjoiYzU4NjgwNjE0ODBkYTk4ZGZlNjJhMjIyYjQ3MzUyZThiNDlkYWE1MDcwZmIxYWJhZDY4YTY2MDU2MTNkY2M2NyIsInRhZyI6IiJ9','eyJpdiI6IkJEUkx3dy9Yc0I5RGJoRVAzQ3VmV3c9PSIsInZhbHVlIjoiaTZqSFNyMEZweWxsK3RHczhHdlFGZz09IiwibWFjIjoiNzdjM2NmYmU3YWM0ZGIzMGNjYzYwNDIyNTRhOTBiZGY5ODgwZmE5NmU4NWMwNjQ4OWMzMjM3M2IxZGY2OTIzMyIsInRhZyI6IiJ9','eyJpdiI6IlVYM2N4ZlZsODAyNitia0NkSUk1b3c9PSIsInZhbHVlIjoiVkxjVEtBSEZ0Z1Q2YmJTeW9nVjRVdz09IiwibWFjIjoiN2I4ZTBkNGM5NzRiM2NkYzdmY2ZmN2UxZDViMGRkNGZhMTMwM2JlZGJiYmU1ZDZjMzBkZWJmNWJiMGVhM2ViNSIsInRhZyI6IiJ9','eyJpdiI6ImRjUEsyM2pNNFlkWnNncy9hR2F0VHc9PSIsInZhbHVlIjoiOXJCVEM3WVlPNFRwUUJ4bFpSOFp3Zz09IiwibWFjIjoiMThhYWI1YTgyNzA5Y2JiOGZiYzMyNGNkZTc0MTU1OGY2NzFmODczZTc0NTk0Yjk2MjdkODQwZjMwYWNkZjM4ZiIsInRhZyI6IiJ9','eyJpdiI6InVPUFdaMDFFbmoybGZwMVdDK2RQY2c9PSIsInZhbHVlIjoidVltRWtSMWxXNldTN0QyelJlblRLQT09IiwibWFjIjoiYzE5M2JkY2JlOGNiMDQ4YjAxZTY0Yzc2ZjNjMWE4ZjE3NzM1ZDhhOTc4ZDU4ZjVlMmI0MTQ3ZTUxNjcxMWNhMSIsInRhZyI6IiJ9','eyJpdiI6IkFpcVZYWnNiWDVpMW5UZjB4eUFYQmc9PSIsInZhbHVlIjoiMjBEbldvR251a3BaM1BmdXhKTEtxUT09IiwibWFjIjoiMjA4N2M0YjA3YWU4NzI0ZjUyMTNmYTk2ZTIzNjEwOGYxZGVhNWRmMjljZDQ0MmU5MTJlYTliNzBlNmExNzU0MCIsInRhZyI6IiJ9','eyJpdiI6Ik0xS1AwcWd5Q0V5UDlGb2w1dHZxbWc9PSIsInZhbHVlIjoiN1NJZ3ZIQjNTMUMvcW5KNURYN2c4dz09IiwibWFjIjoiOGE0NmNhNWExZTBiNjg3ODY4NWRlMjdiZDhlMmFkNzQ3MmI1MWZlOWVjN2U4ZWYwY2EwOTAwNjZlOWVhNWJiMCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(44,45,'eyJpdiI6IjJMV29lM1hRYjI3czFBU29peENyMGc9PSIsInZhbHVlIjoic29WYmlDdVlUaXJwVlU1SnluVUxqQT09IiwibWFjIjoiNGVlZGNiYTBkMWMyN2E2MGM2MjA1NWQwNGZjMTI4ZGQ4M2IzMWFiZDNjNjBlYjQ2ODYxMGE3NzE1OTIyZGRjOCIsInRhZyI6IiJ9','eyJpdiI6ImUxZ2NJeW9pcU1pdmY5K3RHZy9nbHc9PSIsInZhbHVlIjoiL1Urck9jUnZTc0RZWnV1dXBvNGkvZz09IiwibWFjIjoiMjUwNTU2ZTAwMmE3NDRlMDVmOWUyMzdhYzExMWViNTE4Y2QzZGI1YzU5N2QyMTY4MjBkZGMxM2Q4MTRkMWU0OCIsInRhZyI6IiJ9','eyJpdiI6Im9VS0VRQ0xNQmp2NkxuQUR0cGQ0WGc9PSIsInZhbHVlIjoid3RBNFJCRUlwb1U1b2xGemJiNUIrQT09IiwibWFjIjoiOGMzYTMxY2FmM2I5ZjgwOGYxNDhlODA5YTkyZTgwNTlhZjZkMmM1YTYwNTY0Y2E0YmYyYzIxNjA1ZTZmMjM5NCIsInRhZyI6IiJ9','eyJpdiI6IjM2RVJmeitHMWFGK0VEeHg3TWx3cWc9PSIsInZhbHVlIjoiVTh0SHRBa3VoaEV0a2FZaXdZUWtlUT09IiwibWFjIjoiZmZjMGZkNGQ3NzNmNjExMTI5YTE5YTUxNzVkY2Q5MTgwMGE5MjMxYjkxZjIyZDA2NjIzYWQzOTYwZDZhMjEyMCIsInRhZyI6IiJ9','eyJpdiI6IlVkVVJSa2U3Tm90U2VIMEJjSURRYXc9PSIsInZhbHVlIjoiN2pVbHFQUExCVmpwK2kyMitlcVoxZz09IiwibWFjIjoiNDcyNzdjMzMyNzZiMTg2MTI0YTNlNDBmNTdkYTgwZmIwOTc4ZWY5NGQ5ODY2NDcyNmJjZTdkZjhhOGI2NTZjOSIsInRhZyI6IiJ9','eyJpdiI6ImNOOWl0b0srODF0VG9FYmJuYXpPcVE9PSIsInZhbHVlIjoiT2crVU1XSWI3TUtkUEJDU3JUb0NJZz09IiwibWFjIjoiYzBkZWVmNGM4MThhMDQzYWIwZThjY2NmM2ZjYTUzMjRkNDhmZDY5NDY2MWQwNGI2YmRkNjY1OWZhNTc2NmU5NiIsInRhZyI6IiJ9','eyJpdiI6InRjdWcxaG5SdEl4REp4NytVeWZ1YkE9PSIsInZhbHVlIjoiQmhBUHlVWXd6U2hxWmVBL2FGVVl0QT09IiwibWFjIjoiZDJlMzk4YTQ0MTVmMTI1MWUwMzI1YWI4NDg1Mjk1MzZkZWNhNThmN2Q5OTA2MDcyMzY1OTQ2MGE2ZTNlZWEzMCIsInRhZyI6IiJ9','eyJpdiI6InR2b0dZTXN1WGlWTjBkQlMzYWt0aEE9PSIsInZhbHVlIjoiSWNKUGlmUVV2czIvRG91dENoWlByQT09IiwibWFjIjoiNGQxMGU1MGM1MWM2NDg2N2NmYWRmNGNiMzk4YTY5N2Q4ZTcxMTZiNGE0ZmMwZDg0ZDk1MmY1NmM4MmNmMGU0NCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(45,46,'eyJpdiI6IjRzYWR3NlpUUUVwcjVMa0JGOG05YlE9PSIsInZhbHVlIjoiVUphd2taZ2MxSVBwUDE4cFhoM0RyUT09IiwibWFjIjoiYzY5MzY1M2M5YmQ1MzEyNjI4NWQyNGMwMjE5M2FmMzc4MTg1NjFkY2U1YTY4MWNiYWMxMDFkZTViNjNlZTc3MSIsInRhZyI6IiJ9','eyJpdiI6InA1RllWaVkzSkZTQ3VneW5SWkZFaWc9PSIsInZhbHVlIjoiTk1ZTXBIWWJLQ2IwbnVid0hCVmd5Zz09IiwibWFjIjoiYjBkMTNhNzlmMWZiZjZhMDY3NDMwMjc0NDYzNDExM2FmYmQ3NTMwOGMzYTYzMzIyY2E4YjdmNTk1ZDFiODNkYyIsInRhZyI6IiJ9','eyJpdiI6IlBOZmY0bUV1Q09NTW1vLyt3QWZ0WHc9PSIsInZhbHVlIjoiOXhpNGVzN2FDc3FrQy8rRE8zc0tFQT09IiwibWFjIjoiMDk3NTMxZWQ2OWVjZTVmYWYzZTFiNTc3YTIzODk3NzQ0MGVjZDZlOTQyMTU2NWE5NDIwZWZjMmQ3YmQ5YTFmNiIsInRhZyI6IiJ9','eyJpdiI6InBaSCs5QzFEOWlqS0VBMm9VUnVmQmc9PSIsInZhbHVlIjoieXVybFBIN0VVRDIyZ0VuakIzRk5GZz09IiwibWFjIjoiMmYxNThmMTI3M2Y4ZjkxNzQ2MDMyMTg3YmEwN2FlNGU0MDk4NTlkOWM2YWE4MmQ0MjM0NWZiNDdkNzk4YzcyNCIsInRhZyI6IiJ9','eyJpdiI6IkIwTkNrUFZkZmlwY3N2RDkwNzhTdnc9PSIsInZhbHVlIjoiaFJwcXZKcnhrbDBEYmUySkZYM3Vzdz09IiwibWFjIjoiMWJhMzQxZTM5NjA2MjM4MmM4OGUxZGIxYTY4NGZlMWU5MDY1YTRlYzNhMjJmYjk5MDg1OWI2NzgxYWM0NmQ2OSIsInRhZyI6IiJ9','eyJpdiI6IkkySE8yTUFzbDJoK1pBRHZPZHlBTHc9PSIsInZhbHVlIjoiaEhrOGlyeVpsdUJuQTJsU1ZFUmxaZz09IiwibWFjIjoiZjQwNzI3NjQ1Mjk4Y2Y4MzgwNzMxNzFkNTM0ZGI4OTEyY2U0ZTkxN2Y1YTU1ZjI1Mjc3NzQyY2NmOTMwYWU3NyIsInRhZyI6IiJ9','eyJpdiI6Iml0cW1wSmtGOGYzbXdwMzZscFZiS2c9PSIsInZhbHVlIjoiNFRWcHhwUGZzV3BUWWQ3UXR0UHRiZz09IiwibWFjIjoiNGE0YWNjZDliZmMyOWU1NjliNzk5MGUxNTJkZTQ3MDllOTljYzAxZTU3NTFjMDE5MWQ2Y2E0ZWJhNDZkZWVjYSIsInRhZyI6IiJ9','eyJpdiI6IjlDaVFTczlQR0UySDc2Wk9FN2tXS3c9PSIsInZhbHVlIjoiTGFMUFJPR3lscGxvMGFmeU1EMGt4QT09IiwibWFjIjoiZjYzODYyYWY2Y2I0NjJkM2ZlOTM4OWJkYmExZjdjMDljYjNlMGI0NzVkYzFjNjg3NmJiOTgxNzI4MTkzZTMxMiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(46,47,'eyJpdiI6InBJUmluazRiQjZhOWRIanVuNG5pa1E9PSIsInZhbHVlIjoidU1lRmNodnhGdTlrK09EYVJNZlBoQT09IiwibWFjIjoiZmRhZjE4ZDNlNTU0NDNjNTAzOTNmYTgyZmUyMmQ4NDZiZWZjZmIyNjNiMGEzMzVlZjljZWFjYzM3NDEzYjU4MiIsInRhZyI6IiJ9','eyJpdiI6Iml2UXhFWXZZd3g3ak5aTzZJV2U3RGc9PSIsInZhbHVlIjoiOFM3VGtobklsYTNCYUNGMWd4T2N2dz09IiwibWFjIjoiNTk0MWU0NGNiZjhjYjA5MWI1NGYwMWQ1NmRiN2U0MTkxOGRmMmQ4YzQyOTA1NTlmMzQ3ODZkMjFhNTZiZWIxOSIsInRhZyI6IiJ9','eyJpdiI6IitTc09WQjBkSnVCQVM4UnZnaCtkTlE9PSIsInZhbHVlIjoiSi9SRGdkbzBXM2N5ZXBlcVFiL0dkdz09IiwibWFjIjoiYTRlMTNmMGFlNjJlYTEyZmJmNTdkYTFmYmIyM2NlYmFmNGIwYjAwMjkzODI3ODJhNDA0NjY2ZWExMmEwMjdjMiIsInRhZyI6IiJ9','eyJpdiI6InNrWHVneHZCZGZueGRVUWdpY3hPOGc9PSIsInZhbHVlIjoialVjSWttVHkrWDFnSWVmUGluYk1Hdz09IiwibWFjIjoiNDU4NGNmODlmNTlhYzhmMzY1Y2I3OWRjN2U4Yzk1ZGQ0ZGFlY2RkNWUwMmFkZDNmZWQ0ZWYwN2NjYzA5YzY5NyIsInRhZyI6IiJ9','eyJpdiI6Im1oU1luUUI5SzNLMGRGbFJoMXovM3c9PSIsInZhbHVlIjoiZStHWHVmdkFNRERBZFpUcnczRnJNdz09IiwibWFjIjoiYTE3M2M1NjZiNmM1NmFjYzliMmNlNThjNDBkM2VjMjgwNWZmMGRhODA1ZGQwMzg0ZDZjMDE3YzRjZTNjNGYyYiIsInRhZyI6IiJ9','eyJpdiI6IjhUdnk1Y3RadWRmSWJaNzAzVnB6cHc9PSIsInZhbHVlIjoiN2FkaDVxTWMzTHFvVDZCbUg5OG9OQT09IiwibWFjIjoiNjJiYmFjY2VmNDg5ZTZlNTc3YzhmMmMxMTExODkzOTg0N2VhYzlkODY2NzI4NDgwZjg2NGJmMDY1MDU5NjZiYyIsInRhZyI6IiJ9','eyJpdiI6IjNEeFFvYU9rSkNJV3dCa0laSGRicVE9PSIsInZhbHVlIjoiZWdVQlBKZDFaRzBNMGtxYzU4dmRKZz09IiwibWFjIjoiYTdjMmUxNDgxZjRlNmUwNTQxMzNhOTJkMzhkOGZlOTU3MGY3YzJiYzMxZTg3MWIzMDQxOGUxNDU0MTNjYTg1MCIsInRhZyI6IiJ9','eyJpdiI6InFnWUwxU0dGOE9tYnc1cEtpTkZHd2c9PSIsInZhbHVlIjoiM0JNTTJtbEZUc1kyMzh1UnRCNEJrZz09IiwibWFjIjoiMzhmMjdlNWFlY2E0MmZhYTkzNjhiMzMwMDY2YjE1YjdhODY4YmRmN2Y0NjMxMTBiMzNiZTJjOWRkMWJkYTkyMiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(47,48,'eyJpdiI6IktVUzBZVkdyU1FNWndTRHdzdWdTWEE9PSIsInZhbHVlIjoicHpUTG1QVEltWHJ5SG40VXRlKzJPdz09IiwibWFjIjoiMDBhNzZiZDg5NDI2MDBhNTEzZmMzNjNmNGQ0MGEzM2UyYzMwNDU2Y2ZkN2UwZjc1NjFkMWIzMmYzY2RkMmI4NCIsInRhZyI6IiJ9','eyJpdiI6Ik1HVmhjTmErVVIwcEx5K0pWVHBGaHc9PSIsInZhbHVlIjoiN3ArMWl3aXNJcU1KTVVodEhLdzc1UT09IiwibWFjIjoiYTEyMjNlNDMxYWEwMjVlOWY3ZThhNTljZDUzYTFiZDA0NGU1MTAyMjNlYzYyNzAyZTc3NWYzNWQxZTYwZWU5ZSIsInRhZyI6IiJ9','eyJpdiI6IkVJRXJzZ3lZZHhLK1hZcGF3UHQ2V3c9PSIsInZhbHVlIjoiczZmUjJ3aUM0K2JmUlRsNHVkOXVBQT09IiwibWFjIjoiM2Y5ODAyODdhZjkzMDhjMzdmNGZmOTExNWQxNDgzODRmNTQxMmRhMDJhZWZmMzJkMGRmZDJhN2E0NGNhZjU1MCIsInRhZyI6IiJ9','eyJpdiI6IjBSVjh4T0o1aGN2L0VwbjVzaTVyeHc9PSIsInZhbHVlIjoiZTlxS3d6OGJQc2dSYmxtZGxXT0haQT09IiwibWFjIjoiNTc2MGIwNzBkMDdlYWRlODU0YTliMzQ1ZDMyOGEzMTZkMWFkM2Y3NDA1Mjc5Y2I3M2NiNTYyZDg2ZjMzOWViMSIsInRhZyI6IiJ9','eyJpdiI6InNUeWJlN2tQZXhwendhcE5lSEJOdmc9PSIsInZhbHVlIjoiTTRJZU9ZeDV4YW5MU2N6NEJpM2xhZz09IiwibWFjIjoiN2MyMWU4YmIyMGE3Zjc4ZjM1OWQ5NTNkZWZjNDM1Y2ViZTVjMTY4MGQ4N2QzYjk3ZTA4ODE4YzcyZGMzNDZjMSIsInRhZyI6IiJ9','eyJpdiI6InlFRUYrOVkzNnh2ZGJZK3E3ZWcrM2c9PSIsInZhbHVlIjoidE9IdmxUVU1HMnlsemhqbXkzOTh3UT09IiwibWFjIjoiNjg0NzhmZDM0YjNiODg4ZDE5NmJjNjI5NDM0MGQ0YWM2ZWYzNGM0MmJlODAzYzE0MmJjYmU5ZWZkNjU4OTNkNSIsInRhZyI6IiJ9','eyJpdiI6InhPOGhCcEVVV2V0UWJSYlRHY0w3eFE9PSIsInZhbHVlIjoiT2lBT3dOS285ajJlMzI1YysvSFNEQT09IiwibWFjIjoiMzY2ODczZTljYjgwOTFhYzhmMGFmMmM2N2VkMzg2MjFkM2Q3OTYxOTAyM2I0MzU5MTExMTBjN2RlNWQxOGY5MyIsInRhZyI6IiJ9','eyJpdiI6ImVHWFp5VUp1TlFEMWp0Y1lpcG9JREE9PSIsInZhbHVlIjoiTHRwa2MxVVNLU2JEQ01iREhLc2VKZz09IiwibWFjIjoiNWQ4NjJkMTQxMWM5OTQ2NjU4MDMyOTlmOWZlMTA3YTJmNzk1OWE2NDk1ZDVjZGNjY2FhODQzZDcxNzU1NzRiNSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(48,49,'eyJpdiI6Ink5SitjQ3k3VVcwbHR6eHpHSThRTWc9PSIsInZhbHVlIjoiQmhvNkxLY3I3bVI0YThQcTY0TEhDUT09IiwibWFjIjoiZmViNDE0YzEwNjA5NDlkNjZjZTE4Y2VlOGZiYjAzMmVhYTM3ZGZlZTA2MTMzOWE2OWY0Nzg1M2NhMmU5NWMyNSIsInRhZyI6IiJ9','eyJpdiI6IjUxdWMzMkU0SURzUS9CNlBmWUcwVHc9PSIsInZhbHVlIjoiV0lVcmVnMTlGdDNVM1U5MVlpYW13dz09IiwibWFjIjoiNWRlNThlNzJmOTllMWU3OGRjMmUwZDlmZDI3NWFmNGJjYzQ4YTg3ZTkxNGZkYzFkYzBjYjczMmYxNmI2MDI0OSIsInRhZyI6IiJ9','eyJpdiI6IlZHQkNLNjlhZmgxYlpLQVdSRkNxRVE9PSIsInZhbHVlIjoiQWJmdVd1d1htY2JlQUltbzhqN1dKUT09IiwibWFjIjoiMjg3M2EwM2U1MjgyNTBhYTJmMjE1OGY2MGIwYmQ2YzMxZGQ0OTUzMTYzMzQ0NTljODEyNGVhZGIyY2I5Mzg4MyIsInRhZyI6IiJ9','eyJpdiI6ImtjcHlqOFhnV1lSV0xMSko1NWFEclE9PSIsInZhbHVlIjoic3JSTGJLa2grVGxNRnFFZ1pLYU4yZz09IiwibWFjIjoiODEyMGU0MWNiNGJkOGQwYTY4MTZmNDE3MjM2MjQwMmVkYTFmMjA2NzZlMTk1ODU0NzBhM2FmMDExZjIzYzg0MCIsInRhZyI6IiJ9','eyJpdiI6Iityd2ppUWt6dVNVdWFaNVRsOE1GUGc9PSIsInZhbHVlIjoibnh6bFB1NUxxYXZPVHlZNFVwNEFhZz09IiwibWFjIjoiNDBkYWIyMDFkNTFjZDRkYTc0YjI4ZWJkM2UwOTBiN2FmOWI4MTA3OGE2ZDQ5ZjQzOGQ0NzVjNTJkN2M2ZmMyYyIsInRhZyI6IiJ9','eyJpdiI6IkhnNXR4dlQvNzZRSEpuQlptamhUUXc9PSIsInZhbHVlIjoiTjJ4UWlyNWJITldvT3I0eDUvbyttUT09IiwibWFjIjoiN2QxNDRmOGU5ZGY1NzMzODAyNjIyM2RjNjkzYTE4YzdiZmE3YjFmYjY3MTRjMzRjZjEyM2E2MTlkMDg5ZTdlNSIsInRhZyI6IiJ9','eyJpdiI6Ijk5eDQveENHVlNLWXVReHQvZWhtaFE9PSIsInZhbHVlIjoicGY3N29NZ3JrL2NvY1YreUNObHM1QT09IiwibWFjIjoiNGNjZjk4OTYxYWNiNGVhMWYwZmVjMDYyYjdjOGQ3MWNiNThkOGM2MDcxYzg5MjMyMjY5MDMwZGZmMzYyYzVjMCIsInRhZyI6IiJ9','eyJpdiI6IlllNDMzbitBOGg4bjNRS0JrWkxVVHc9PSIsInZhbHVlIjoiMXBjUW0zMVZsdFJtYWROeEtrM2h2UT09IiwibWFjIjoiMDkzYjNlZTA0N2ViNWQxY2NkYzg4YzBiNzY2YTAwZTkwNTA3ZGM5NTQ4ZjBkY2U3MDljMTVkYTE5NTU0Y2ZmMyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(49,50,'eyJpdiI6IldLR3NXK2pqQUlkSmhFSzRyZ1hYOGc9PSIsInZhbHVlIjoiMm9VYkxHUGN4amJ4dlRzRVZwaWhtQT09IiwibWFjIjoiMjhlYzI0ZTk5NzI4NjI5ZTNmZmQ0N2M5N2NiZjg0MmRkZjM4OGRhYTA0NzAyZjk5MjY2YThhZTFhMTdmNTg3YyIsInRhZyI6IiJ9','eyJpdiI6IjMxeTRtZ25KYk4ra1ZTLzgrZk4rMEE9PSIsInZhbHVlIjoiMVZTMEVXVmFZcWZxa2d5TkVwWldJZz09IiwibWFjIjoiNDllODU3ZTljNDU5Y2FiMmNmZDhlNDliN2NmOTQ1MzA1ODNhMjA5NzMzMzRhNzU3ZjI4ZDE0YmZiMTUyMmU0MiIsInRhZyI6IiJ9','eyJpdiI6IkRseXliS0ZDcU1aWm1FbUlyZTFYcVE9PSIsInZhbHVlIjoiQi8yL24yYzZZK2EvZXdCQXhzVmF4UT09IiwibWFjIjoiYTUzZmRiNzRjZjhkYWUyYzFjZTBhOTkwOGNjYWYxYzVhNWI1NDM1MGU3MTI1NWJhNDE0OGYyOTlkNGM4NWMwYiIsInRhZyI6IiJ9','eyJpdiI6IlI1cTJKMEl3YWdGbXNXTzJLMDlVdEE9PSIsInZhbHVlIjoiTGVIcVg5d3hTb3A2eERzbEwyRGNwZz09IiwibWFjIjoiOTkyYzY1MGY5M2E2N2UwMGU5MGUxY2MyZjY0NTZiYzRhZTJkMjRkNTdiYTFlOWRjODM5ODcwMDNlMWY0NmY0YiIsInRhZyI6IiJ9','eyJpdiI6ImRPR2JscFZEcnZaYmhwWVBnLzhLRFE9PSIsInZhbHVlIjoiYjRicWx4YnF3Ynl1bHRvZVpwZTdWdz09IiwibWFjIjoiNTdkMDA3NjMxMzI0ZWU0YmZhNjQ0ZjM1M2JlMTExYzI0N2QxYWNkZmYzNGZiZTExMTVkZDIwOTIzZmYzODNmMiIsInRhZyI6IiJ9','eyJpdiI6ImtrMmxkMXB1QmVQekkwUkljVjVYY3c9PSIsInZhbHVlIjoiMDEvNDlUMlJTczYrekdaeU8xSE9sZz09IiwibWFjIjoiOTM0NjlhNTllMmJhMGI2ZWFhYzExMTU1ODFiOWY4MTU1ZWYzMDYyYzM4MmI5NmZiNDUzMmQzOTUxZTJkMjRiMyIsInRhZyI6IiJ9','eyJpdiI6IkI2YmYxWkw1Q0N3elFLMGFUMDhhRkE9PSIsInZhbHVlIjoicEpQQTFTM01PcmV4N0daaGN4SVB2UT09IiwibWFjIjoiNjU1YmU0Zjg0ZWI4ODg0NTg4YmJhZjgwNzI3MGNmYWRjZThlZjFjMzk3ZDdlYmU2NzI0ZGIyMjYyZDg5Yzg5NyIsInRhZyI6IiJ9','eyJpdiI6ImlqS1FHSC9KLzA3TUdaMlJXYjdPc2c9PSIsInZhbHVlIjoidWpPY1phaDdqSjNldkVNVzF0Vys0dz09IiwibWFjIjoiMzZjMGY3NWFmZGFhZDZlYzA1Nzc1NzJjYjgxYTUwYzNmODZlNTNkZTkyZWUwZDc3MjNmMDZkMzE3ZTA5NDc0MyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(50,51,'eyJpdiI6IkFOWGZFUUMzcHNTQ1JJdHJGTHFramc9PSIsInZhbHVlIjoiVjdZZG44cGZ6VWoxa3kwUWR3WGJJdz09IiwibWFjIjoiZTZhZmNlMTc4ZTNhYTY3NWNkOGI2ZDM5ODQ1MGUzMDk1Mjg1ZDBhZTU2ZjRjMzE1OTBjMzEwM2E2NDJlZWRlYyIsInRhZyI6IiJ9','eyJpdiI6ImdabWJVakFqRFNVVFg5VmxkNHdHbFE9PSIsInZhbHVlIjoiT1lhOWZYckI0NlBwTXJrd1J1QjVkQT09IiwibWFjIjoiNzM2NGJjMjJmZTY2YTI1NzkzNmZjNGVhOWQ0ZjA3ODNiNzAzOTlmMWJmYmQwMjgyZGUwYjY2MmM4Y2RhNzk1NSIsInRhZyI6IiJ9','eyJpdiI6InBIQktIR0RpSHE5ZjVnYkJOaHk3UFE9PSIsInZhbHVlIjoidSszSEd6VFlkVWJmRXVlejkrK2pzZz09IiwibWFjIjoiZTFkMDJiMWFiMzczMTIwYWE4MWNjN2IxMDVhOWJhZGIxYWI4NmNjZjIzNzhhMjRiMTI4ODA1YTgyYTQ1OTc1OSIsInRhZyI6IiJ9','eyJpdiI6ImQzcWVpbHlTbnNHV3RuTlRQTjczMVE9PSIsInZhbHVlIjoiT0g0ckYwS0ZodGM5bWd0TTJoUnp1UT09IiwibWFjIjoiOWQ2YWEyMDg3MDQzOWI1NDg5YWY1MTAxNTIzMDE0MzgxMTZiZmRjOWRkNjBjNjc0ZGI4YzBjNzBlYzI4MzlhYyIsInRhZyI6IiJ9','eyJpdiI6InljZjNGTDRrVFR6b0ZITHpGSXRBc0E9PSIsInZhbHVlIjoiM3VjNk45RlQ1bFE0MFpXVFUwUU9LQT09IiwibWFjIjoiM2Y5Yjc4MWJiMzU2ZTdjMmI2ZjEyN2EwMmFmNWQ2MTgzOTA0ZDEyZjM1ODRiZGNiMjM4NWM4Zjg3ZGU0MjIzYSIsInRhZyI6IiJ9','eyJpdiI6IldEVHM2NTMwU2lOcEVtOXVudTgyTlE9PSIsInZhbHVlIjoiOHpneEJ5eitlc0RYQkFVV2xwalp3dz09IiwibWFjIjoiOGU0ZTc2OTA1NDgwYjllYTUyMzQ3OTg4ZWNmNmMyZWQ3MzQwOTVkNjYxYTFhYWNhNjJlNDhlYTBlNWM3ZGU2NyIsInRhZyI6IiJ9','eyJpdiI6ImRNamtZWmsrOXM2Ty9YTFErWk5kZXc9PSIsInZhbHVlIjoiZ2tvQ2tDVDJwL1NOeW4xS2VkSHgwZz09IiwibWFjIjoiNmExZDczYmE2NzAxOGFlZjk0YjZlMzI0MjdiM2Y5NDVhYTI3ZDg0MDUzMWZlMGE1NTA5YTEwYWQ1NmJmMGVmMCIsInRhZyI6IiJ9','eyJpdiI6Ik1EZ3VCZ21uams0MEF3b2dUWG1xTVE9PSIsInZhbHVlIjoiOXVUK3NzcEM2VEZNcWoycEhEQktrUT09IiwibWFjIjoiNmVhZTcwZTlhMzVmYmQ2YzA4N2Q4OWQ0OWJhYWFiZDU2YTllNjlkMjM1YzA3MGU2YzllYzU1YTAwNDIzZjQ1MCIsInRhZyI6IiJ9',0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(51,52,'eyJpdiI6Ii9ROXRXSHU2Nk1pR0x2ZFphTXFzQkE9PSIsInZhbHVlIjoiWjlhczkzNUU3Z1J4RlFMQnNhdmJhdz09IiwibWFjIjoiMzdhYjQ5MWM1ZDk2NzVmN2MwMjYyN2Y1NGQ2YTQ4Mjc0ZDllMGEyMzU4ZGFlMmVhN2E5ZWUxNmE4M2Q0MjUyNSIsInRhZyI6IiJ9','eyJpdiI6Ik5nQlFNZ1dpM25HZGJaV1FWNCtHY1E9PSIsInZhbHVlIjoiY2NWeGE3VDhHNGRwL0xpUVZ3TjdXUT09IiwibWFjIjoiMzA5NTYwZDJlNjIzNTU4M2YzZWQwMjcwZjJiYzgxMGNiZTc0ZDEyNGFmNjljMWVkMzA5MjZmOWEwYjU4MzhkOSIsInRhZyI6IiJ9','eyJpdiI6IkZmOXR0V0ZpSmd4Z2VDM0g1aC9ieXc9PSIsInZhbHVlIjoid1BQTzhCSzdrMllTRklXaEdTVjlUUT09IiwibWFjIjoiMDFhNzFkN2RkZDZlZTEzNDNiZTIxNjFmM2YxZDYyYWJkMmFlY2QzNmE4OWMwOTk4ZmMwMzE5ZGY3Yjc4NjBmZiIsInRhZyI6IiJ9','eyJpdiI6Ing1Z1hxTlQ2bTU1aDZQSmtPU3VscWc9PSIsInZhbHVlIjoicWN5eDQ3dHhMaDhZd2oxRXRSWkd2Zz09IiwibWFjIjoiOTY3NGQxMTIxYjg1M2IxNWQyNTk0ZDU4MWNlZTQwMjRiNWI4YTQwOThlMThiZGJkMTkzMjhmYWYyNmQ3NjZhMCIsInRhZyI6IiJ9','eyJpdiI6ImxQQ0VLOFRDb3FxMktSQTBFcWJoYlE9PSIsInZhbHVlIjoic3FWRG5nNmNqb0RIMVA5b2NuQlp3UT09IiwibWFjIjoiMDllZDIwNjAwMGY2ZWUzYmU0ZjdlZjRiOTZmNTNiNzhhOTdkYzg0YmU3OGE3MjEwMjNiMjI3MWM2MDk3ZTllMiIsInRhZyI6IiJ9','eyJpdiI6IllVLzA2ak1GdFJVVk5YbnhlYk5HQnc9PSIsInZhbHVlIjoiL0F4RURhclV2eS9WcWNsMGtEckpPUT09IiwibWFjIjoiZDgxOWU2NWMyM2I5MGU3YzIwMTQxMjIwMjc4M2ViOGFmOWZiMzFjYWYxOTA3ZDU3YmI2YjBjM2M5ODVmMDVmNCIsInRhZyI6IiJ9','eyJpdiI6IndUek11MmNiQk8rdEF1ZnNnS2NYZVE9PSIsInZhbHVlIjoiQXdtaWVNMTBEQUNDZ0M0OVd2YmNIUT09IiwibWFjIjoiMDgwZjVjZWQzNDAzMjVmNjQ5ZmE4MTJkZWUwOTE2NGE4N2E2ZDBjM2EyOGFlMDQ1Y2QwYzNjOTRkNzIyNzZlOSIsInRhZyI6IiJ9','eyJpdiI6ImwrdGZCektOSTY5cEFXR1lJNStBaGc9PSIsInZhbHVlIjoid2dNZWg4SFNDSTAvekhKU25jN3FrZz09IiwibWFjIjoiNTg0NzNjNGRhOWIxN2ZiOTE0ZDhjNmQ3OTVlZTVmZjJiM2I3YWQyY2Q3ODhiOGI2ZDE3YTgyZTEwZWFlODBjNyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(52,53,'eyJpdiI6IktYQVdROFFBcGc3d0szcGxWZWxEM2c9PSIsInZhbHVlIjoiN3NJMkxmUXIyT1pOZGJORVZEN0x4dz09IiwibWFjIjoiZTZiOGY5OWVlYThlNDA4NjdkMmE3OTY3MjQ3YTc4YWUwNTI5YzRmMDM5MjdkYjdlZDc4YTJjZGU5ZTE3Nzk5NyIsInRhZyI6IiJ9','eyJpdiI6InZiQVN6dGlITXRvZWFRMWtBbkNrWEE9PSIsInZhbHVlIjoicFd4MFh3WUtKRWRiOE9sdVRkcE5lUT09IiwibWFjIjoiYWVjMmEwNWJkNzA2Zjc0MmVkNjZjNGU5NTkxOWMyNWYyNmQ0MTk2OWIwZTFmYTEwODgxYWVhZmMxNDQ2ZWRkOCIsInRhZyI6IiJ9','eyJpdiI6ImlIU1A1SC90cTBuelNqSXFtdzhnWGc9PSIsInZhbHVlIjoibkF1OEl5NTNoOFNackJpRmlscnR5UT09IiwibWFjIjoiOGE2MDExMmI5MmJlNDk4NDExODVkZjE0N2ZhNmY0YmFhNGIyYThiYjk5ZDNkMWVjMjNhMjRiMjA0ZTM5ZGMxNiIsInRhZyI6IiJ9','eyJpdiI6ImQ0QVNsTkh3R0s2OTFVUWpCUVBaZEE9PSIsInZhbHVlIjoiaXJyR0ZtSU5IQUI1UFM3Q3I0cnQwQT09IiwibWFjIjoiZTZkN2JmNGMxODNiYmRlMTliZTA5MDUwMWMyZjFlMzFlOWRhNjYzOWFkZWM2NmQ4MWM3YjYwNjJlZDEyZDk2MiIsInRhZyI6IiJ9','eyJpdiI6IkxxVm5PT0VabzFFbXRqVTY3eWFjY3c9PSIsInZhbHVlIjoiV0VmbDVKTXI5N28vUXNmNnNlTVpRUT09IiwibWFjIjoiY2JkYjM3ZDI4YjY5MDAwNDc2YTExMTllOTkyOTY1NTNlNzdhM2E2MWFlY2ZhMjAyYjc0YTBlNDBkYTQ4NmM0MSIsInRhZyI6IiJ9','eyJpdiI6IjhuWU13cU9QZTBmMTRHUmVvQ2ZWSHc9PSIsInZhbHVlIjoiYTFEZGJFSjRRaktkQng3MDFwKytzUT09IiwibWFjIjoiMmZiYmM4NzkxMzhhMDc3Yzc3ODBkZTgwZjQwNjg5OWU5OWRkNjgwMTc0NTJjN2VmOTIzZWQyMGZlZmEzMTdlYiIsInRhZyI6IiJ9','eyJpdiI6ImllUnplZkZYMFFLVEYyazBKZFZBYkE9PSIsInZhbHVlIjoiQ1ZTRE5uUElEUVQ2aUpJanpaN1BRUT09IiwibWFjIjoiZmQxMGMzNWNlMDhiYzE4MGRhOTc3ODFjODk4ZDRlNDk0MGU0MmNlNzhjNjQ0ZGE1NmMzYTc2YzczZDk2YjE2ZiIsInRhZyI6IiJ9','eyJpdiI6IjVSS25TVy95KzV0bW1uYjcwclJMK0E9PSIsInZhbHVlIjoiY1czK2hXVzBZRUd5L01XYTZzbGJFUT09IiwibWFjIjoiYTVkNTA4ZWUyNzhkNTQ3OGIyZGI5NDlmMjcyMzI3ZGEzNjZkYWVkMTg0MzM3NGRiM2IwNjA1YmY5YjhhYmFmNiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(53,54,'eyJpdiI6InoyZ3g2QW4wdUY2VWFvUzY1RklUL0E9PSIsInZhbHVlIjoiSDc0cVFtOUVIMFc3U3hPUUhFLzltQT09IiwibWFjIjoiNTkzMDNhODMyNDAzZGNlNGVjNjY1NDljZTk2MzRlMjM1NGE0MTA1ZDk3YzZhZjgxOGRlNmY1YWQzOGVlYjBkMiIsInRhZyI6IiJ9','eyJpdiI6InFpejBPRU9FK2lpZG9hZm9wM0Z4Q2c9PSIsInZhbHVlIjoiNktCUHFmWS9pTVBpR1ViUXJhZjQ4UT09IiwibWFjIjoiM2ViMzRkMmJlN2JkOGIwZGZmYzMxMDQ2M2VjZDgxZjk4MDZjZjgwOTRhYTBhZjZiYmE0MGVjNTA1MDliNDI0MiIsInRhZyI6IiJ9','eyJpdiI6IjBwT1E4aVJIblpGR0tyN3VVbDJkTXc9PSIsInZhbHVlIjoiQWtOdlU5MytWSytLbk9saUIzV29GZz09IiwibWFjIjoiNWJjYTc0NTkxZGU1Y2IwZTJmNmQ1MTUyY2IzMjBlNGU1ZjFlZTM4ZDA3YmQ4YjU3YTA0NDc5NGYwZDdjMmI5ZSIsInRhZyI6IiJ9','eyJpdiI6InBORHVhY3Q5Rm1UYXZWYTI4aHZmUXc9PSIsInZhbHVlIjoiOVVmUlBnU3llN01Ma1BJaXhBOWduZz09IiwibWFjIjoiN2RjMTk0YjMwNjRhNTA2OTEwYTQ5MzgxZTUxYmFkMzZhYTZiYWU5MTZjYjE0OGM0NTI0ZmVlYmQyOWU5ODk1MiIsInRhZyI6IiJ9','eyJpdiI6IlVWUTBZZTVzM2kvTVlVSzhEcFdIVGc9PSIsInZhbHVlIjoiNU4xZVl0dWYyZ0dMaTFCWEdoR2F6QT09IiwibWFjIjoiYWM3MTEwMTk0ZTE3OWE0MWVhZDdjNTNlMzM1YmY1ZjUwOGMxNGY3ZGJkNWViYTQ0YTExNGVlZmMyYzE4MTI1OSIsInRhZyI6IiJ9','eyJpdiI6Ik9sd3oxbjlwc0swSUtOUTlGaisxa1E9PSIsInZhbHVlIjoibjR4aFNqODBZYzVCYTQvUlJjK25uUT09IiwibWFjIjoiYjM2ZTY1MDVkMDdhMmJhMTEyNmQxM2Q4OTM0NWNjNDI3OWZmZmU4NTQyNmY1MjFjNDZkNWQwMmQ0MDE4MzhhNyIsInRhZyI6IiJ9','eyJpdiI6IlhlZmV3VG1KUEt3aThRem9ESkp3RHc9PSIsInZhbHVlIjoicHBuSmNYU0UwQTU4ZUx1aDFISTRJZz09IiwibWFjIjoiMWNlMWExMDA0NmVjMTc3OTI3NTdhNmY2ZDU4OTliODdiNDIyMTY1OTE3OWVlNTFmYzRhZmY4YTFmM2NiNDhhNCIsInRhZyI6IiJ9','eyJpdiI6ImdzeE1sa3BqL0E5ZDE2TkcwcGducUE9PSIsInZhbHVlIjoic0tVVnoxWDhoTkNRTTU0cGV3b041Zz09IiwibWFjIjoiODkwZTdhNzg3MDBmNzMxOTFjMWFiN2NjZjViMDRlZjMwY2U3ODI5MjI3OGQwYTljNThlNjI0Zjc2ZmE0YzY3YyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(54,55,'eyJpdiI6IlZFVEJlYmZXejhON2pVT0NDRFNMa3c9PSIsInZhbHVlIjoiTnU2L0xlZ2VKTEdUd0xTL0o4aEc5dz09IiwibWFjIjoiYjg2NjQ1ZDkxMjExMGVlMTM2MzQ0NGEwMzZjNjdmOGU1NDFmNmY4OTdlOTI0NWYxMjAyMjEwN2FkMzc2Nzg1MSIsInRhZyI6IiJ9','eyJpdiI6IndvNHVqbG9xQmFEWENtOXJROHNzV1E9PSIsInZhbHVlIjoiRXFMMGtuSDVMVnRCMEtZWEd2M0dTQT09IiwibWFjIjoiYmE3MzI0NjBkMjNkYjgwMDliNTkwYTAyMjBlY2VmZjAxODJkZWZjM2QxYzVjMGI2OTNhNDQ4NDg3YTZlMDFiNSIsInRhZyI6IiJ9','eyJpdiI6IndPcCtWMkFoZ3VmVUEvR3VQVmgyVlE9PSIsInZhbHVlIjoiRGpRTUFsSnllbm9ycWhaOGFTY21YQT09IiwibWFjIjoiNjNjMmQ2MzRkMTAzYWQ3ZWE0N2U2ZGQ0MzU1NGJjM2Q5YzY3OTllOTc3ZGJmOTY2ZmQ2ODU5MjA1MmM1ODE3NyIsInRhZyI6IiJ9','eyJpdiI6IlV3WHdOVHBNeVFRcGY5MittL2hiRHc9PSIsInZhbHVlIjoiQkRwTEZUVkoyYmhHa3ZpL3BydVlGUT09IiwibWFjIjoiNWEyNjk3MWRmZDZkODk1NDYzMmM1MTNhNzM2ODZkOWI4ODBhMDQwYmExNzZiYWNmOTFmYzdlMzYwZmRhNjRmZSIsInRhZyI6IiJ9','eyJpdiI6Ind1ZTBpcDVPMUFJelA5SkxJNHQ2SWc9PSIsInZhbHVlIjoiN3g4ZXNhVnByZUx2akR1TGxZbE50QT09IiwibWFjIjoiODMwMDcyY2ExMDEyNGEyNjZkZGZjMTc5NjhlN2ExZmFlZDEwYjdiM2YwYzMwZDVmOTY2MDhhZGZkYjM2NzBlMSIsInRhZyI6IiJ9','eyJpdiI6ImRQVmVzajhkZ3dxZ1JKclZuRTloV1E9PSIsInZhbHVlIjoiZFc0S002Sk1zbGxKemoyTjliaGwzQT09IiwibWFjIjoiMTg4NjlmYTJiMTE0NzkyMzU3NTUwYjYzNjMzMzRlNWFjYzAwMmY3OWQ5YzhiZjIwNjRkMzUwNTcxMTYwNWFhYSIsInRhZyI6IiJ9','eyJpdiI6Ikp0NlF3a0gvMmNmOEpkQ1A1ZXY2dFE9PSIsInZhbHVlIjoiNWtscnFaVUx3Q0FXcTl5cVNXWkJIdz09IiwibWFjIjoiODJlYzIwMTRiZDg2ZjI5MWI3ZGZiNzBkYzc5NjBhNmMzNTZlYmIwZDgzODJkNzk5Njc3MDkxODI3MGIyNWI3OCIsInRhZyI6IiJ9','eyJpdiI6InZJaGxYZ2hVenhLME1BaE9WbFd1c2c9PSIsInZhbHVlIjoiUlVxRzE1MGltTmxKMVRheWpkRkkzUT09IiwibWFjIjoiNWI5MzZlNzMxMjRlNTRmNjMwNTE0ZGFmNTk1Njg2NWFlYWQ1MTc0OWZmOThjZDQxNGQ1ZDAxMjc3NDhlM2M1ZiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(55,56,'eyJpdiI6IlMwSmM1aTBJenlCVkFjTi81ZmV4OGc9PSIsInZhbHVlIjoia2VieHhLQUV2OVJkVnR2dktVSXYxQT09IiwibWFjIjoiYjA2MzE5ZDcxODBjMzJlNTEzNTY3MTgwMTQ5ZDgyNjQ3ZjJlM2ExMTYyZGYwY2U3ZGM5MzA1MmJmNzBjMDMwZSIsInRhZyI6IiJ9','eyJpdiI6Ik5paW40ekdSUlZxcENGMDIrakpvSWc9PSIsInZhbHVlIjoid25kVEs0TmZGVmZvZDJrdGRUb0d6UT09IiwibWFjIjoiMTYyOTlmYTVkMGU4MmUxMDM3MTI1ZTdhOTBiNjEyNTlhYjBkNjJmN2I2ZWUwMjYwNmMyYzIwNTU2OTA0MThhMiIsInRhZyI6IiJ9','eyJpdiI6IndTcjROSFJVWnFRWXh2MXVha0N5c3c9PSIsInZhbHVlIjoiT2Z3VjhQdjA0M2Z3b3FXUUVZak5hUT09IiwibWFjIjoiZDY4ODhlN2UxYmQyNWQ5MzYwZTI3MjcyOWVkZmY1ZGZiZDc3ZGEwMGJiNDRlYzk0OTQ4YTRjMDM0ODk5MDg5YyIsInRhZyI6IiJ9','eyJpdiI6ImNYVEdIM244TnVUemtrdzdLOG1pd0E9PSIsInZhbHVlIjoiRnVUSlUxRS9iWS9sVnVFVHdVd08ydz09IiwibWFjIjoiZjUzODEwNDc0OTU3NjRlYjY4ZmVjNjQ2MzA3NWY3N2Y0ODg4NDFkZjk2OGRkNWU1M2IwNTA3NzM1ODI1ZTcwNSIsInRhZyI6IiJ9','eyJpdiI6IjlhTHZ3M2IyZjcyUWNrNmRQQUIyNkE9PSIsInZhbHVlIjoidkx0eUhtUk5SZUNlaG1JWSt2a05DQT09IiwibWFjIjoiMGFlZGM1NzM2MDIwYmUxODM1NzE2YjM5M2RjMzJjYmFlZGE3M2FkNzg3MGY2MDYzZTUzYmU3OWE4ZTVlODM2OCIsInRhZyI6IiJ9','eyJpdiI6IjAxb3AzYkx3cWtjSkpUZFY5V2VOTnc9PSIsInZhbHVlIjoiRXV0ajRoeVNYTG1pSWVkTVpVb3g5Zz09IiwibWFjIjoiMjdhMWQ1NTBmMmI4MzhiNDEwNWUwNTg5NzdjMmNiNmI1MzY3Y2NjZTg2MTY1MjE3ZmU3ODY5MDMzZDUzMjBhOCIsInRhZyI6IiJ9','eyJpdiI6Im05c1hiRGVnbG5TcERPbDRTQzhlNGc9PSIsInZhbHVlIjoiNUx1ZGNHTE12TDR0NFI5elQyQXpWdz09IiwibWFjIjoiMzczYTBjOTI2ODZjNTUwYjA5YTVjNjYzMTQ3M2U3NzEyMTQ2MWI0NzNmMGQzMTlhMTAxNTJmOGU0OGMxMzdjYSIsInRhZyI6IiJ9','eyJpdiI6ImJrTG9qYWlqYnZNeGswMkVwNFg5Ync9PSIsInZhbHVlIjoidkhkZHBjYmhjZ0JoOG9pbmJnN0hudz09IiwibWFjIjoiNTJhMjM2MzEzZjUwNTA3NWNlMjFiYmY3MDJmODg5Njk4MjI3MjE1ZjVhNTcxNzBlOWI1ZjdjYzk1YjBjZWYwMSIsInRhZyI6IiJ9',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(56,57,'eyJpdiI6Ing4ZlRaL0VsMlMvVDFJWUpYczN0L2c9PSIsInZhbHVlIjoieDk0T2crTzZxVFVucHM2NmtnWVFRdz09IiwibWFjIjoiY2E2OGUzNTI3MzYwODdjOGM5N2YyZTUzZDBiNjIxNWRjYzA2MzU2NWJlOGJlMzgzNWJiZTlkNmM2YjU5ZDM1ZiIsInRhZyI6IiJ9','eyJpdiI6IlJHYnFSQkJvdGVtQTEzb2pjUUwzZVE9PSIsInZhbHVlIjoiWGY3WWhmeUdFSnZ6Z1ZKWHBXVWRYQT09IiwibWFjIjoiY2I2NWJkNjU0Y2RhMDc2YjFjNzFmZDNhYTdlMjFhY2RlNWZjMTk1NTY1MDM1YmE5YzEyYzhmYWU2ZjI1NTk2OSIsInRhZyI6IiJ9','eyJpdiI6IkdYSGliSitnOGY2VDYyMnlvN1pvYkE9PSIsInZhbHVlIjoiOXhWVlZ3dkkwU0tzRVhwNUFYMy9Ddz09IiwibWFjIjoiNmEwMDQ5NjBjM2QyNDQ5MmU2OTE0NDhlNjFjYzMwYTkyNDU5NWFhNWU0OTMxZmU4NGFlZjQ0MjQ1OWM1NGViNyIsInRhZyI6IiJ9','eyJpdiI6Imc0YjUxa09vVms4QXJ2Q2dtK2U3RFE9PSIsInZhbHVlIjoiVVFEQXhNQnkzaXhjUSt2Q0NlV1pFUT09IiwibWFjIjoiODIwMDUwMjEzMDgwNmUyNzkxM2E4ZWVmZWQ0YzZmN2UzNWJjZWQzYjVmYmJmMzhmY2VlNjhmMGUwN2Q5OGQ5OCIsInRhZyI6IiJ9','eyJpdiI6ImF3VTgxenVhQzJkaEgxREtSVDlmYlE9PSIsInZhbHVlIjoiY0ZMZ0drZko0RlRWRGNGaWxTM3lSQT09IiwibWFjIjoiMDIxYWVjYjMzNzE2YmI5ZDEzYWEwMzRhOTczZmE3YTE4OTRkOGE0NTRjYTc5NWViMDFlYTJkYmY5YWFlNTFmYiIsInRhZyI6IiJ9','eyJpdiI6ImFUNWtQcGduMzRwWVo1MjJiTWVqRnc9PSIsInZhbHVlIjoiNHNpb253T3pweXB6T0lUaGtPK1RsQT09IiwibWFjIjoiYzJhMzZiNGFkN2FjY2U0MmVlMjk1YzA2OGU5ZTJlZGU5OWVkNzYwYWI5ZWMyMGE5ODZiMWIyM2ExZjU0N2Y3ZiIsInRhZyI6IiJ9','eyJpdiI6IjZyS3ViMXF5b3g5czhoMzFEekJMZ2c9PSIsInZhbHVlIjoiMDFlSm14bU9pdW1PNHJGclJqejEydz09IiwibWFjIjoiODYxZDg5YWNjZDNhNDc0ZTQ4Zjg3NDY5MzhlN2JjYzIwNTlmNDIzYTI0MWY0YTIxZmJkYTA2YWNjYjIwN2ViZCIsInRhZyI6IiJ9','eyJpdiI6IlU1dlpTK1krWEV6ZHJrTWpxMUg5Vmc9PSIsInZhbHVlIjoidVhiUHNKb1BBUmU3d2RYcHRPc1N0UT09IiwibWFjIjoiMTA0NzdmZjcwMTE0NmYwNjU2MjIxZGY0M2IzZmE0YTIzOGI5NmE5NDEzNjRmMWFhMzA4Mjc5N2QzMWQyMWY0YiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(57,58,'eyJpdiI6ImwzMEJJaEFHZEdSWW5pemtySFB5a2c9PSIsInZhbHVlIjoiWEZlb2tURklYNUEzd250VUZ4a05jQT09IiwibWFjIjoiZGI0MWFlNmY5MzNmNGYxNTMyNDJhNmRiMWQ1YTJlNmE2NzkyNzRiZDNiMDFiZDM0YWZiNjMxODk3ZTM3MjVmYSIsInRhZyI6IiJ9','eyJpdiI6IktIYVViVWJKV0x6cjYrOHhRMFdvM1E9PSIsInZhbHVlIjoiRWMzMDFoV0ZiN29NWElmRTAxM254UT09IiwibWFjIjoiYmQ4ZGZlMTNlOGYxNmNlODJiNTJlN2Q1MzE4Y2E2ZjQwOWViYTExMjAzOTE4YTI5NjQwNDU2NmNlMzliODViNiIsInRhZyI6IiJ9','eyJpdiI6IlZKQXlpSUFiRG1IYTZHakgrZk1sWEE9PSIsInZhbHVlIjoicnl0aE1kTHpvZklWMS9oRWRyWHpDUT09IiwibWFjIjoiYzllMWIwZDZlMDI5YjY3MmVkMGE4ZmI1ZDY0NGNjMGY3YmE4NWUyN2U1Yjc5NjJlMWIwYThiM2I5MjUwNzM3NyIsInRhZyI6IiJ9','eyJpdiI6IjlndUNaZnhNQ0ZDcnlHdzJxUjl0MEE9PSIsInZhbHVlIjoiZisvUHQ0bHMwYjA1M2M3WGI3REt4Zz09IiwibWFjIjoiYjEyZDQ5YjBkNTQ2MmVlZTk0ZmQ4OTc0YWQzYzY0OGZkMDU0YzRlOTRlMjZlMGI4YTBmYzYwZmIyYmQ3MjllYyIsInRhZyI6IiJ9','eyJpdiI6InFZZGtrRURPdEcwRjlBYnZCdTdoSEE9PSIsInZhbHVlIjoiSUJreVhmWnE3akNzSVpsVitIdFIwdz09IiwibWFjIjoiZTg2NWRlYTE3ODliOTgyNjMxMGM0ZmU5MDQ2ZWNlM2ZlYjgwNDNhZmM0OGE3OGVjMjY4ODQ2MzdiM2ExZDA5YyIsInRhZyI6IiJ9','eyJpdiI6IkZzRFY5bHVFRTFXWkVPdTBUa0RBS0E9PSIsInZhbHVlIjoiUTV2c1pFb1RGdkdja3RZZjAxNXN3UT09IiwibWFjIjoiZDg5ZDE4YzYzMWViOTc3OWE2NGQyZWUxYzFhYmY3NjM0OTM4OTk1OTRkYmVhNTgxNDkwYWQ3YjZhMGYxNzA3ZiIsInRhZyI6IiJ9','eyJpdiI6IktEZWdIaGU0RWw4YjhQcU5XZkY0N2c9PSIsInZhbHVlIjoiMjNqU0JpUEtWYTRaeWJYS3A2cTMzQT09IiwibWFjIjoiZmU2OTI0MjFkZDNjYTk1Y2E3YjhlNzQzYzkxZWJjMzA2MWExNzMxOGM2MjkzZjE5YjU5ZTYwNDc3ODdjNGQ3MCIsInRhZyI6IiJ9','eyJpdiI6ImJmN0F0UmZjelBPdUlSWFhCY2UzMkE9PSIsInZhbHVlIjoiS2ErdDkxQWJMdGc2a3BWT0lNeEc5Zz09IiwibWFjIjoiOTAxNDZjMmUxYmRlYjM4Y2NmYWU4NDFkODc1NGY5M2Y3NTMyNWYxZjA4YWIyZjNmNzQ2YjEwZTEyMTk5M2IwYyIsInRhZyI6IiJ9',0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(58,59,'eyJpdiI6IktJNWxtdW1DWlk5UWVTNVBYWFJlQmc9PSIsInZhbHVlIjoiYUd2NFRrR0pxaEkzakJSeWJDN1FvUT09IiwibWFjIjoiMTc3NjMyNDQ5Y2E4ZTE5NDJmNzU4ZTIzMmVjNGM3ODMxNjI2MzZkYjRiYjcxMjM5YzBkODEyMmQ4ZDcxNTc4NyIsInRhZyI6IiJ9','eyJpdiI6InVRNkJ3WitWdkN1bE56bVVVSXZjTEE9PSIsInZhbHVlIjoiaFQ5SjA4VUNMYVh4dytPZDJ4d1VRZz09IiwibWFjIjoiM2IxZjlkN2E0NzFlZmY2NTAwN2Q3NGEzMDUzYjBkYmE0ZmUyYjUzY2Q5YmRjNmNhMGYyZWIwMTQwMDQwMWQwZiIsInRhZyI6IiJ9','eyJpdiI6IjhQRmMzdHNjWG1JZUhXMkRWT3Bxd2c9PSIsInZhbHVlIjoiMG51MEJFeGt5K3doNXhJUmNMdFRlUT09IiwibWFjIjoiY2QxMTk0YWNlNjkyNjI0Y2I4YTQzZDUzYWM0NWIyMGVjYmY5YzRiMTZkZmJhNGQwZWFjZDZiN2UxMjM4YWUwNyIsInRhZyI6IiJ9','eyJpdiI6Ik96TmNnSGg2cFZpbGFvU2R0ZlRlMkE9PSIsInZhbHVlIjoiVzBPeFRrOFoxcmVvZmxHMElNazlGZz09IiwibWFjIjoiNTYyNzQ1MjhlNjEzOTc4N2JhOTFmNWVjZTg5YjczY2MwZTBkMDc0MTI5YWJlM2IzYzhmNzUyNzQ1M2RmNmU5YiIsInRhZyI6IiJ9','eyJpdiI6Ikl0U3FPRTgyZ0ZGTTNPRFZIbUZpOVE9PSIsInZhbHVlIjoiL1JMc3QwaGpibEtZUlcvZStqKzhtdz09IiwibWFjIjoiYzI3YzJlZTI4Y2I2NWY4ZGZlMTA5ZmQ0Y2U4NThjMzQ5OWY4M2JkOTNkZmUzZjNiYzI4YmQ4NzkwMTk3MDRhYSIsInRhZyI6IiJ9','eyJpdiI6IlV6MVpnSGV6bGJKQmwrSVFnMzFIWEE9PSIsInZhbHVlIjoiQzRwcG95b3N6dEwwc3dhZXZua2FvZz09IiwibWFjIjoiOGIyN2MxZTU3M2NjNDE2YmY5ZDQ0YzgyMDA3MjhiMWU0MGNmZTBiMTQ2MGUwZWM4NGU0NTBjNDFlZGE4OGIzMiIsInRhZyI6IiJ9','eyJpdiI6InZZeDNwQXpaa25LUHFqcjU3KzdJd1E9PSIsInZhbHVlIjoiOUZmcUVRblg4bkJhMlRxbGxnTStDdz09IiwibWFjIjoiNDZmNTVhN2FhMzcyYjlkYWE5YWJmOTdlYzM5YTI4MDRiY2RmOWE2NTAxOWY4ZGMxOGQ2MzljYTNhZmJiYzhlOSIsInRhZyI6IiJ9','eyJpdiI6Iml5Rk1CYit5cHpWNDNNL0JNbjBuRVE9PSIsInZhbHVlIjoiVmpXc1lySUhsVHFDY0gwd2hDNnFwUT09IiwibWFjIjoiNDYwNDM0MTYwYzg3NzlhMmU5YzBhMDJjNjFkMmFhMTlmMzFlYjg4Y2MwNDVkOTNkODIwOTg4ZTAyODhjY2M5NiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(59,60,'eyJpdiI6Im5GYmpFWFV2RS9BZDhxeFcycXdhT1E9PSIsInZhbHVlIjoieFBpL25qVlliWTBuazVFK2lsSWc1Zz09IiwibWFjIjoiNzFkNzMzNzA3NzRhYzcyODJiZDU0NTkyYmNiMjJlZjljNzk0ZjI3MTBjMTRlYmYwMTIzNWMwNzQ4MDU5MDM0MyIsInRhZyI6IiJ9','eyJpdiI6InJzQldEZjBBaDRSbUs1Ty9GRWRuTUE9PSIsInZhbHVlIjoiWGtObTB3ZFF0M2JWY3p6M2htVTJ6QT09IiwibWFjIjoiNjE0Yzk1ZDViODM3Zjg5ZjEzMTVkN2FjZDc0MDQxOThhZDY2YmFkZTI1MmZkYmE0YmM3Yjg4YjUxNGEzYjdkZiIsInRhZyI6IiJ9','eyJpdiI6IjV6bUhRb29MUGNCQ1VabW5KcFRBNnc9PSIsInZhbHVlIjoiaEtUcmVmWTlOMGdzWi9lSkM0amNwQT09IiwibWFjIjoiN2E3MThhNWI5ZmRmNjM2MGIzMWRiOGM1ZTdiYWZhZjViZDJhZjhhZDRkZGM4OGU0MWNjZTcxN2YzZGEwYjAyZiIsInRhZyI6IiJ9','eyJpdiI6IjVYQXpvK3FHUW5hcHJQa0RCZGZSYXc9PSIsInZhbHVlIjoiTkhVblhFaFdaNnpQZ1ZzamdoTE1qUT09IiwibWFjIjoiZjNjODVlNTM3YmMyZGYyZDNhNzUxYTViMTdiNmMwZGFiYmRiMWEzNGU0MWNjNzM4ZTZhNDg4OTEyOTM1OTQ3MCIsInRhZyI6IiJ9','eyJpdiI6IjIzY1Z6a2gwZ2l3elU1MXFWZmV3RVE9PSIsInZhbHVlIjoiQnd3Rk50cEg5WnM3dzM1MkFFcG1sQT09IiwibWFjIjoiZTM0OWJjMWJkZGU1Nzg2NjQ2ODFkYzM5NDBkMzE2YjgxZGQ4NjRhMzMzYzZkZjljNzBmNzNhMzQ4MGEyZDY4YiIsInRhZyI6IiJ9','eyJpdiI6IlZlMUVPQitIa3Z0YTZMWExFc3pzWXc9PSIsInZhbHVlIjoiUS85TmZDem1vV1Q2cHF4K3VobHdJUT09IiwibWFjIjoiNTI2NDBlM2FjY2NmNTc1MzdmNDkwNGQxMDY0MmRlNzU5YzMxMmNkM2I0YjEzODJjZjllZDhmMzdjNDJmYTg4YiIsInRhZyI6IiJ9','eyJpdiI6IjhTM1paS3NyWjM0bjEwUWF3OUtjcWc9PSIsInZhbHVlIjoiU3llS0RkcmMvUDZURTVjck9ycS8rQT09IiwibWFjIjoiNWFlNWYxZDg5ZmI3NmI0YTFlYTEzN2EwMDYwMDlkNmQ0YTI4MzYyNzJiN2U0MTU5MzA1OGFmNmEzNTAyN2QyMyIsInRhZyI6IiJ9','eyJpdiI6InpmOW9hY05Ib3ZLQ0czNVNlUXlDSmc9PSIsInZhbHVlIjoieUhOUkVRdlpXU1FqRVpwK01VVXh5Zz09IiwibWFjIjoiNGRmMzA2ZGU0N2IzNzFjOWUzNDg3NjVhODM2YzY5MTNmNTFlNjJmNDBkNjY0NjRhNDRmM2MwNWYwNjM4YTIwNiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(60,61,'eyJpdiI6IjZITHUyNE5DSDFBeElqQ2lONWNWZkE9PSIsInZhbHVlIjoiamk5dVFYOGNieHduWHJRNUIzQWtIQT09IiwibWFjIjoiYzBjODNmMmVjNWYwY2QxMWIzNWUzNTkwNzhkMzM2M2MzZGRkOTdkZDc4MWJjYjJkZWIwN2ZmMjdiYmE5MjU3ZSIsInRhZyI6IiJ9','eyJpdiI6IkdjU3g3MmFaTExPVkVsS1ViK1NUWFE9PSIsInZhbHVlIjoiV3luQUcxWCtKeHlrUjNBckFuR1FJZz09IiwibWFjIjoiN2MyNzA1MGQyNjcwMzZhMmJlNWZhOWRjY2JhYzhjNjc0YjI4N2MyMGNlMDcwNGQ2NTQ4NDU4Mzk0MmVlMDQwNCIsInRhZyI6IiJ9','eyJpdiI6IlhMcjNnOHlBSHd6Qm45dWZlSmtGWXc9PSIsInZhbHVlIjoib3FzUUo5MHJuazlqcE04STR0SkEvQT09IiwibWFjIjoiY2E1ODUyNGI2YzhjMDlhZTZkMjdiN2M5MzMwNDFlNzczZGQ5ZDgwMGE4NWIzYTZjYTgyYmU3MmEyYjQ3ZDZjYSIsInRhZyI6IiJ9','eyJpdiI6Ing1N1E1MGppV1RnYTdMT20zbytVUnc9PSIsInZhbHVlIjoiMjFkd3h2Z3d2NUFBWnRYSCtPK3hsUT09IiwibWFjIjoiM2FlZjZkMGJiOTMwNTY2ODE1N2NmMzFiY2RmZGRjMmVhZDgzNGEwMmVhMDUzMjA5ZjNlMzFiMzc2YTJmNDQ5NSIsInRhZyI6IiJ9','eyJpdiI6InBrQmNZNHVNRVhTYnVYY3A1dDNXMEE9PSIsInZhbHVlIjoid0pScFlVM005bWM5THhBK1Nmbk9XUT09IiwibWFjIjoiZGY5OGQxMDkxYWNmOWIxMzJjYWNlYWQwNzM2ZTViMzc4YzBhMDgxODUwYjFjNzMwMDkzNmQxMGVhNjhlMTUyMiIsInRhZyI6IiJ9','eyJpdiI6InJ4dzA1K0ttbTRTbE1pcGFzTS9vUEE9PSIsInZhbHVlIjoiZmZuLzR0NGZvWjNyMExkKytoMFRkZz09IiwibWFjIjoiYWViNzI1ZWFiNzU3MjAzNzc3OTBkNzVmZGNlNDNjNTg3MWMxZjZmMDAxNjBjODkwNzdmYzNhMTAyYTNhNjA0ZiIsInRhZyI6IiJ9','eyJpdiI6ImdLOEF1eWVpeWhPMnZTTTZMVjErWGc9PSIsInZhbHVlIjoiVXJNZ2YrZ0p3dUUwOTQyMEJZeEFsdz09IiwibWFjIjoiZjcwZTNmNDhiNzEyY2U0YTQyMDQ1YjMzZTgzMDQ4ZGUzNDllYjc1NTMyYmY3NjIyNzAyZTlkZjMwNzI4OTk5NyIsInRhZyI6IiJ9','eyJpdiI6ImIxV3VSVE9MZVIwS3I1OUxFRnorUEE9PSIsInZhbHVlIjoid2F3QURFa3VzUUNNWWlYQzkvYnlvUT09IiwibWFjIjoiMTE0NzZkMzU0MzkyNmJkYjUxZjljMjllNWI3ZTVhZWIxNzNiZmQ2NzI5NzgzNTM2MTgyYTkyN2JhYzM1NDdlYiIsInRhZyI6IiJ9',0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(61,1,'eyJpdiI6IitPSy9iUlFoVlN3SjR2VG05bnRRb1E9PSIsInZhbHVlIjoiOHdXdE1oaHhnM2VJWTA0WGRNODEwQT09IiwibWFjIjoiYjI1Yjg2NThiMjQ0NTVjMTZhODEzNjFhZDgwMTVhNTcxNDZkN2YyNjM4MmM3ZGM3MjYwOGM3Y2Y4ODg1MTNhMCIsInRhZyI6IiJ9','eyJpdiI6IllIc1UwakwrOThJVEczTFhvYTdBMFE9PSIsInZhbHVlIjoiekN6cTY0R0I5NTRJZVhYRzI4S1hMdz09IiwibWFjIjoiMDNmNThmNGM4ZTQxM2MxZGYwMmVjOTc2ZTNkYmNmNzY5MDQyMzM0NTcxMTNlMTY0ZmIyNmNmMWU5OWMxNjQ5NiIsInRhZyI6IiJ9','eyJpdiI6IkFDbGNmSmk0UVpuNnU2NEtxV0FJUWc9PSIsInZhbHVlIjoiN1MxZU9keklFUUpsellaMUFOYzk4QT09IiwibWFjIjoiYjIzOWQ4OWE3YWMzY2M5YzgxYzc1MmU0YzcyOGNiMmRkNTY0ZGU1NjI3ZmUyNDk0ZmUyZDkzMTBhNDI3NDAzYyIsInRhZyI6IiJ9','eyJpdiI6IlIzQUdNeW9WY01lTm1GUXFIclA4c1E9PSIsInZhbHVlIjoiNlpERE5oQjBZejYzWkxNb1NDNTBNQT09IiwibWFjIjoiYWZjYjQ4OWE3YTFlZjY1N2VjMTU4NmMzYTdlOWQ3NzhiYmUxM2M4MDIyMmVlODhjNDBiNjA3ZGY1MzQ5MTNhNyIsInRhZyI6IiJ9','eyJpdiI6Ikw4d1YwUmVMVnJramxLd2RLbG50VVE9PSIsInZhbHVlIjoiaGYrMnltSzFaQ0JMZmc2QkhXK2lsQT09IiwibWFjIjoiZWZkMmUxZjkxMTUzNTVkN2FlZGE1Y2RjMTk4NWRjMTI0ZjllNjNlNjJiMWMyZGYxZDUwN2I1ZmQ1YjhmNDExOCIsInRhZyI6IiJ9','eyJpdiI6InBYY1ppWm1DODB3NHBZdHE1b2xXV3c9PSIsInZhbHVlIjoiZHV6aTJCd3FVaUJHRHU4SWY4bnhhQT09IiwibWFjIjoiODVmZmViNjEyYzZhMWNiMWYyMzljN2RjYzE4ZWU3ODk2ODNmYzE0YzFjZWZhODM2ODg1YzY4MDNhYmY5ZjkxOCIsInRhZyI6IiJ9','eyJpdiI6IjZYUmpxZ3NpK1lQTGZNMHZ2R0U2Snc9PSIsInZhbHVlIjoidlJaQkxGbDJnUnZKK2xFK2Q1eWlJdz09IiwibWFjIjoiOTMyZjIyMjE3ZTJjZDJlYzE4NmI3ZTk1MzgwZjBjYzMwYTcyMzEwNTQ1MGEyYjY1MTM3ZjliMWI2NjAzYjQ3NyIsInRhZyI6IiJ9','eyJpdiI6IlJLOVNmUmF4MGNvVHdkSllmTkxOUHc9PSIsInZhbHVlIjoiM2NWQ3drY0dObnVFVmI2Y2JTOE8xUT09IiwibWFjIjoiOWM0MGJlZTNmNjljMjVlMDllMjllYzZjMGQ5ZjhlYmI1NzYzNDYyZjBjY2U0YzEwMzNkNWE4YjUzYzBiMGM3MyIsInRhZyI6IiJ9',0,'2026-10-06 13:44:34','2026-10-10 14:52:16'),
(62,62,'eyJpdiI6InVVTG96ZG1XL2NnVGNvdENuN29YdFE9PSIsInZhbHVlIjoiT3phMlJyT1Npck5ZVmwxdTl6bnNDdz09IiwibWFjIjoiMTA2YWExODRmZDIwMzE3ZGNiYjFmYzMzMzQ4MjQ4YjcyMjk4M2M2YzlmOTVmNGFiM2Q2YjlmNzhjZTQ0MjAyZiIsInRhZyI6IiJ9','eyJpdiI6Ik8ybjVmNXlBaFdpWU9UT0tDOWJ3SGc9PSIsInZhbHVlIjoiTWppcGpDSFhzbHZSSmlRZ3Bvb09SQT09IiwibWFjIjoiZGEyN2Y5NjM4MDEzY2RhZWQ3ZjM1NjFmNTYxY2E3ZTAzMTMzODA2NzQ1YmM5NjFkMDA3ZGQ1OTc4NTJjYTQ0NiIsInRhZyI6IiJ9','eyJpdiI6Ikl6VTdZeFpORk8yOW5HTEpTUVFtOXc9PSIsInZhbHVlIjoiMG9YUHJNSWVKSXd5bmF0OUNjczJVdz09IiwibWFjIjoiYzdmMjA3ODEyMWY3NWQwNDZlNjZhYjcyMzVkM2ZjYjc5ZWUzODQ3YjA3NzMzNTNkY2Y4YjVjODllMWExNTdkYSIsInRhZyI6IiJ9','eyJpdiI6Ik5MSWxqRWhGWUlacjdPZkdEejJtOXc9PSIsInZhbHVlIjoiMTVUOVkxcDlyMXA4V0lmQ2dNZW5Qdz09IiwibWFjIjoiY2I0MWM4ZGJlZTJlNDMwZDNmZGQ0OTk4ZjNmMDkzZjI1ODRhN2I4OGY2ZmEwZjRmNjAwNmVmOWFkNzBkYjVkNiIsInRhZyI6IiJ9','eyJpdiI6Imtxb082NlZ5SllNcFIza2poeWswOGc9PSIsInZhbHVlIjoianVjQ2E1bXRJU1hraGNhTEU0bWFIUT09IiwibWFjIjoiNDg1N2QyNDRjM2I4M2RmN2M3MGE0NTdmOWYyYjFmNDE0ZmYwYjM0ODc1NDI4OGMwMzNiN2Y3YjE5ZTdjOGUzMiIsInRhZyI6IiJ9','eyJpdiI6IlpFUVgzM3l3Wkc5ZXNnSlZqUnFRSWc9PSIsInZhbHVlIjoiRFMvbHRnTnF5TGpxSkR1RFNHMVk3QT09IiwibWFjIjoiZTM2M2ZmYzEzMWQxYjQ3NGUyYzMzZTBjOTM3MGU2YmI4MjZkNmJjYmYyM2I0NTFkYTJmMzk3MTU2ZjRiOTI1MCIsInRhZyI6IiJ9','eyJpdiI6IldranAwL2hzWDlTRTM0V3ZtWkdjYXc9PSIsInZhbHVlIjoiUWdiRTk4UU9FWEE1eE5HWmVuNFhNQT09IiwibWFjIjoiMmJjM2Y0NGJmZGMwZTJjMTM4YTUzNjFmOTllNDY0YzJlM2QwYWI0YzMwYzE2MGVlOTRiOTJkYTYxZWM2YjMyMyIsInRhZyI6IiJ9','eyJpdiI6IlFRaDU1cG56ek82cXpoejU3ZUtiT0E9PSIsInZhbHVlIjoiQnBtMzRYVFY5b1NmZzBxZloxWnlvZz09IiwibWFjIjoiNTM3NjNlM2YxNWNhYTA5NTU3NWIxYThhZDEyZDQ2NGIzNDAwNWY1NWZlNWU0NmRmZGIxMmYzNzI3MWU0NTNiYiIsInRhZyI6IiJ9',0,'2026-10-22 03:50:26','2026-10-22 03:50:26');
/*!40000 ALTER TABLE `socioeconomic_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_certifications`
--

DROP TABLE IF EXISTS `student_certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_certifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `title` varchar(160) NOT NULL,
  `issuer` varchar(160) DEFAULT NULL,
  `issued_year` smallint(5) unsigned DEFAULT NULL,
  `issued_on` date DEFAULT NULL,
  `expires_on` date DEFAULT NULL,
  `credential_reference` varchar(120) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `legacy_source` varchar(60) DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_certifications_student_id_archived_at_index` (`student_id`,`archived_at`),
  CONSTRAINT `student_certifications_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_certifications`
--

LOCK TABLES `student_certifications` WRITE;
/*!40000 ALTER TABLE `student_certifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_certifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_skills`
--

DROP TABLE IF EXISTS `student_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_skills` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `name` varchar(120) NOT NULL,
  `legacy_source` varchar(60) DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_skills_student_id_archived_at_index` (`student_id`,`archived_at`),
  CONSTRAINT `student_skills_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_skills`
--

LOCK TABLES `student_skills` WRITE;
/*!40000 ALTER TABLE `student_skills` DISABLE KEYS */;
INSERT INTO `student_skills` VALUES
(1,2,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(2,2,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(3,2,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(4,3,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(5,3,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(6,3,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(7,4,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(8,4,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(9,5,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(10,5,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(11,6,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(12,6,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(13,7,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(14,7,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(15,8,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(16,8,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(17,9,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(18,9,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(19,10,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(20,10,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(21,10,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(22,11,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(23,11,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(24,11,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(25,12,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(26,12,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(27,12,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(28,13,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(29,13,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(30,14,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(31,14,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(32,15,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(33,15,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(34,16,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(35,16,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(36,17,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(37,17,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(38,18,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(39,18,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(40,19,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(41,19,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(42,19,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(43,20,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(44,20,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(45,20,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(46,21,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(47,21,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(48,21,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(49,22,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(50,22,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(51,23,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(52,23,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(53,24,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(54,24,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(55,25,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(56,25,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(57,26,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(58,26,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(59,27,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(60,27,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(61,28,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(62,28,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(63,28,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(64,29,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(65,29,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(66,29,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(67,30,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(68,30,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(69,30,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(70,31,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(71,31,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(72,32,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(73,32,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(74,33,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(75,33,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(76,34,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(77,34,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(78,35,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(79,35,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(80,36,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(81,36,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(82,37,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(83,37,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(84,37,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(85,38,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(86,38,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(87,38,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(88,39,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(89,39,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(90,39,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(91,40,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(92,40,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(93,41,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(94,41,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(95,42,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(96,42,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(97,43,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(98,43,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(99,44,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(100,44,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(101,45,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(102,45,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(103,46,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(104,46,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(105,46,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(106,47,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(107,47,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(108,47,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(109,48,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(110,48,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(111,48,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(112,49,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(113,49,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(114,50,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(115,50,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(116,51,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(117,51,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(118,52,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(119,52,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(120,53,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(121,53,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(122,54,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(123,54,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(124,55,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(125,55,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(126,55,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(127,56,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(128,56,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(129,56,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(130,57,'PHP','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(131,57,'SQL','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(132,57,'HTML','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(133,58,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(134,58,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(135,59,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(136,59,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(137,60,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(138,60,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(139,61,'communication','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(140,61,'research','skills_experiences.technical_skills',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(141,1,'Teamwork',NULL,NULL,'2026-10-10 14:52:36','2026-10-10 14:52:36'),
(142,1,'Organization',NULL,NULL,'2026-10-10 17:34:27','2026-10-10 18:01:22'),
(143,1,'Miau',NULL,NULL,'2026-10-10 18:01:02','2026-10-10 18:01:02');
/*!40000 ALTER TABLE `student_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_work_experiences`
--

DROP TABLE IF EXISTS `student_work_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_work_experiences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `experience_type` varchar(32) NOT NULL,
  `organization` varchar(160) DEFAULT NULL,
  `role_title` varchar(160) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_ongoing` tinyint(1) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `legacy_source` varchar(60) DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_work_experiences_student_id_archived_at_index` (`student_id`,`archived_at`),
  KEY `student_work_experiences_student_id_experience_type_index` (`student_id`,`experience_type`),
  CONSTRAINT `student_work_experiences_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_work_experiences`
--

LOCK TABLES `student_work_experiences` WRITE;
/*!40000 ALTER TABLE `student_work_experiences` DISABLE KEYS */;
INSERT INTO `student_work_experiences` VALUES
(1,3,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(2,4,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(3,7,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(4,8,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(5,11,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(6,12,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(7,15,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(8,16,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(9,19,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(10,20,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(11,23,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(12,24,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(13,27,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(14,28,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(15,31,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(16,32,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(17,35,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(18,36,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(19,39,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(20,40,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(21,43,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(22,44,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(23,47,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(24,48,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(25,51,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(26,52,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(27,55,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(28,56,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(29,59,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(30,60,'ojt_internship',NULL,'OJT',NULL,NULL,0,'200 hours','skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23'),
(31,1,'ojt_internship','OJT',NULL,NULL,NULL,0,NULL,'skills_experiences.internships',NULL,'2026-10-09 04:05:23','2026-10-09 04:05:23');
/*!40000 ALTER TABLE `student_work_experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `student_number` varchar(32) NOT NULL,
  `program_id` bigint(20) unsigned NOT NULL,
  `year_level` tinyint(3) unsigned NOT NULL,
  `adviser_id` bigint(20) unsigned DEFAULT NULL,
  `enrollment_year` smallint(5) unsigned DEFAULT NULL,
  `semesters_completed` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `consent_version` varchar(32) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `students_user_id_unique` (`user_id`),
  UNIQUE KEY `students_student_number_unique` (`student_number`),
  KEY `students_program_id_index` (`program_id`),
  KEY `students_adviser_id_index` (`adviser_id`),
  KEY `students_year_level_index` (`year_level`),
  CONSTRAINT `students_adviser_id_foreign` FOREIGN KEY (`adviser_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `students_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`),
  CONSTRAINT `students_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES
(1,5,'2024-00001',3,3,4,2023,1,'v1','2026-10-06 06:53:26','2026-10-06 13:42:30'),
(2,7,'SYN-0001',2,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:27','2026-10-06 06:53:27'),
(3,8,'SYN-0002',3,3,4,2024,4,'synthetic-v1','2026-10-06 06:53:28','2026-10-06 06:53:28'),
(4,9,'SYN-0003',4,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:28','2026-10-06 06:53:28'),
(5,10,'SYN-0004',5,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:28','2026-10-06 06:53:28'),
(6,11,'SYN-0005',6,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:29','2026-10-06 06:53:29'),
(7,12,'SYN-0006',7,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:29','2026-10-06 06:53:29'),
(8,13,'SYN-0007',8,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:29','2026-10-06 06:53:29'),
(9,14,'SYN-0008',9,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:30','2026-10-06 06:53:30'),
(10,15,'SYN-0009',1,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:30','2026-10-06 06:53:30'),
(11,16,'SYN-0010',2,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:30','2026-10-06 06:53:30'),
(12,17,'SYN-0011',3,4,4,2023,6,'synthetic-v1','2026-10-06 06:53:31','2026-10-06 06:53:31'),
(13,18,'SYN-0012',4,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:31','2026-10-06 06:53:31'),
(14,19,'SYN-0013',5,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:32','2026-10-06 06:53:32'),
(15,20,'SYN-0014',6,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:32','2026-10-06 06:53:32'),
(16,21,'SYN-0015',7,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:32','2026-10-06 06:53:32'),
(17,22,'SYN-0016',8,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:33','2026-10-06 06:53:33'),
(18,23,'SYN-0017',9,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:33','2026-10-06 06:53:33'),
(19,24,'SYN-0018',1,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:33','2026-10-06 06:53:33'),
(20,25,'SYN-0019',2,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:34','2026-10-06 06:53:34'),
(21,26,'SYN-0020',3,1,4,2026,0,'synthetic-v1','2026-10-06 06:53:34','2026-10-06 06:53:34'),
(22,27,'SYN-0021',4,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:34','2026-10-06 06:53:34'),
(23,28,'SYN-0022',5,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:35','2026-10-06 06:53:35'),
(24,29,'SYN-0023',6,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:35','2026-10-06 06:53:35'),
(25,30,'SYN-0024',7,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:36','2026-10-06 06:53:36'),
(26,31,'SYN-0025',8,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:36','2026-10-06 06:53:36'),
(27,32,'SYN-0026',9,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:36','2026-10-06 06:53:36'),
(28,33,'SYN-0027',1,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:37','2026-10-06 06:53:37'),
(29,34,'SYN-0028',2,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:37','2026-10-06 06:53:37'),
(30,35,'SYN-0029',3,2,4,2025,2,'synthetic-v1','2026-10-06 06:53:37','2026-10-06 06:53:37'),
(31,36,'SYN-0030',4,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:38','2026-10-06 06:53:38'),
(32,37,'SYN-0031',5,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:38','2026-10-06 06:53:38'),
(33,38,'SYN-0032',6,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:39','2026-10-06 06:53:39'),
(34,39,'SYN-0033',7,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:39','2026-10-06 06:53:39'),
(35,40,'SYN-0034',8,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:39','2026-10-06 06:53:39'),
(36,41,'SYN-0035',9,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:40','2026-10-06 06:53:40'),
(37,42,'SYN-0036',1,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:40','2026-10-06 06:53:40'),
(38,43,'SYN-0037',2,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:40','2026-10-06 06:53:40'),
(39,44,'SYN-0038',3,3,4,2024,4,'synthetic-v1','2026-10-06 06:53:41','2026-10-06 06:53:41'),
(40,45,'SYN-0039',4,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:41','2026-10-06 06:53:41'),
(41,46,'SYN-0040',5,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:41','2026-10-06 06:53:41'),
(42,47,'SYN-0041',6,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:42','2026-10-06 06:53:42'),
(43,48,'SYN-0042',7,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:42','2026-10-06 06:53:42'),
(44,49,'SYN-0043',8,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:42','2026-10-06 06:53:42'),
(45,50,'SYN-0044',9,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:43','2026-10-06 06:53:43'),
(46,51,'SYN-0045',1,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:43','2026-10-06 06:53:43'),
(47,52,'SYN-0046',2,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:43','2026-10-06 06:53:43'),
(48,53,'SYN-0047',3,4,4,2023,6,'synthetic-v1','2026-10-06 06:53:44','2026-10-06 06:53:44'),
(49,54,'SYN-0048',4,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:44','2026-10-06 06:53:44'),
(50,55,'SYN-0049',5,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:44','2026-10-06 06:53:44'),
(51,56,'SYN-0050',6,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:45','2026-10-06 06:53:45'),
(52,57,'SYN-0051',7,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:45','2026-10-06 06:53:45'),
(53,58,'SYN-0052',8,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:46','2026-10-06 06:53:46'),
(54,59,'SYN-0053',9,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:46','2026-10-06 06:53:46'),
(55,60,'SYN-0054',1,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:46','2026-10-06 06:53:46'),
(56,61,'SYN-0055',2,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:47','2026-10-06 06:53:47'),
(57,62,'SYN-0056',3,1,4,2026,0,'synthetic-v1','2026-10-06 06:53:47','2026-10-06 06:53:47'),
(58,63,'SYN-0057',4,2,6,2025,2,'synthetic-v1','2026-10-06 06:53:47','2026-10-06 06:53:47'),
(59,64,'SYN-0058',5,3,6,2024,4,'synthetic-v1','2026-10-06 06:53:48','2026-10-06 06:53:48'),
(60,65,'SYN-0059',6,4,6,2023,6,'synthetic-v1','2026-10-06 06:53:48','2026-10-06 06:53:48'),
(61,66,'SYN-0060',7,1,6,2026,0,'synthetic-v1','2026-10-06 06:53:48','2026-10-06 06:53:48'),
(62,69,'20230570',3,4,NULL,2026,1,'v2','2026-10-22 02:23:31','2026-10-22 03:57:54');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_grades`
--

DROP TABLE IF EXISTS `subject_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_grades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `grade_report_id` bigint(20) unsigned NOT NULL,
  `subject_code` varchar(32) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `units` decimal(4,2) NOT NULL,
  `midterm_grade` varchar(16) DEFAULT NULL,
  `final_exam_grade` varchar(16) DEFAULT NULL,
  `final_grade` varchar(16) NOT NULL,
  `remarks` varchar(32) NOT NULL,
  `is_failed` tinyint(1) NOT NULL DEFAULT 0,
  `is_incomplete` tinyint(1) NOT NULL DEFAULT 0,
  `is_major_subject` tinyint(1) NOT NULL DEFAULT 0,
  `needs_review` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_grades_grade_report_id_index` (`grade_report_id`),
  KEY `subject_grades_subject_code_index` (`subject_code`),
  CONSTRAINT `subject_grades_grade_report_id_foreign` FOREIGN KEY (`grade_report_id`) REFERENCES `grade_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_grades`
--

LOCK TABLES `subject_grades` WRITE;
/*!40000 ALTER TABLE `subject_grades` DISABLE KEYS */;
INSERT INTO `subject_grades` VALUES
(1,1,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(2,1,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(3,1,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(4,1,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(5,1,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(6,2,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(7,2,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(8,2,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(9,2,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(10,2,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(11,3,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(12,3,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(13,3,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(14,3,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(15,3,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(16,4,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(17,4,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(18,4,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(19,4,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(20,4,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:28','2026-10-06 06:53:28'),
(21,5,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(22,5,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(23,5,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(24,5,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(25,5,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(26,6,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(27,6,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(28,6,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(29,6,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(30,6,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(31,7,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(32,7,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(33,7,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(34,7,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(35,7,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(36,8,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(37,8,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(38,8,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(39,8,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(40,8,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(41,9,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(42,9,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(43,9,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(44,9,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(45,9,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(46,10,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(47,10,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(48,10,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(49,10,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(50,10,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(51,11,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(52,11,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(53,11,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(54,11,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(55,11,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(56,12,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(57,12,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(58,12,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(59,12,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(60,12,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(61,13,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(62,13,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(63,13,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(64,13,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(65,13,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(66,14,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(67,14,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(68,14,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(69,14,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(70,14,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(71,15,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(72,15,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(73,15,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(74,15,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(75,15,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(76,16,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(77,16,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(78,16,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(79,16,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(80,16,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(81,17,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(82,17,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(83,17,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(84,17,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(85,17,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(86,18,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(87,18,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(88,18,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(89,18,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(90,18,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(91,19,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(92,19,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(93,19,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(94,19,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(95,19,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(96,20,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(97,20,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(98,20,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(99,20,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(100,20,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(101,21,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(102,21,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(103,21,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(104,21,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(105,21,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(106,22,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(107,22,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(108,22,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(109,22,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(110,22,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(111,23,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(112,23,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(113,23,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(114,23,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(115,23,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(116,24,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(117,24,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(118,24,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(119,24,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(120,24,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(121,25,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(122,25,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(123,25,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(124,25,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(125,25,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(126,26,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(127,26,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(128,26,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(129,26,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(130,26,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(131,27,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(132,27,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(133,27,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(134,27,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(135,27,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(136,28,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(137,28,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(138,28,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(139,28,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(140,28,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(141,29,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(142,29,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(143,29,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(144,29,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(145,29,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(146,30,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(147,30,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(148,30,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(149,30,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(150,30,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(151,31,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(152,31,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(153,31,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(154,31,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(155,31,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(156,32,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(157,32,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(158,32,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(159,32,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(160,32,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(161,33,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(162,33,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(163,33,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(164,33,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(165,33,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(166,34,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(167,34,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(168,34,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(169,34,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(170,34,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(171,35,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(172,35,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(173,35,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(174,35,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(175,35,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(176,36,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(177,36,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(178,36,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(179,36,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(180,36,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(181,37,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(182,37,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(183,37,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(184,37,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(185,37,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(186,38,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(187,38,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(188,38,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(189,38,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(190,38,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(191,39,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(192,39,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(193,39,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(194,39,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(195,39,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(196,40,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(197,40,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(198,40,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(199,40,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(200,40,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(201,41,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(202,41,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(203,41,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(204,41,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(205,41,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(206,42,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(207,42,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(208,42,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(209,42,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(210,42,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(211,43,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(212,43,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(213,43,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(214,43,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(215,43,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(216,44,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(217,44,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(218,44,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(219,44,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(220,44,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(221,45,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(222,45,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(223,45,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(224,45,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(225,45,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(226,46,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(227,46,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(228,46,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(229,46,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(230,46,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(231,47,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(232,47,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(233,47,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(234,47,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(235,47,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(236,48,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(237,48,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(238,48,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(239,48,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(240,48,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(241,49,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(242,49,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(243,49,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(244,49,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(245,49,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(246,50,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(247,50,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(248,50,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(249,50,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(250,50,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(251,51,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(252,51,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(253,51,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(254,51,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(255,51,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(256,52,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(257,52,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(258,52,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(259,52,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(260,52,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(261,53,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(262,53,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(263,53,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(264,53,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(265,53,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(266,54,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(267,54,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(268,54,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(269,54,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(270,54,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(271,55,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(272,55,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(273,55,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(274,55,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(275,55,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(276,56,'CCS 106','Applications Development',5.00,'2.75','2.75','2.75','PASSED',0,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(277,56,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(278,56,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(279,56,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(280,56,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(281,57,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(282,57,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(283,57,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(284,57,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(285,57,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(286,58,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(287,58,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(288,58,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(289,58,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(290,58,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(291,59,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(292,59,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(293,59,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(294,59,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(295,59,'IS 106','IS Major Elective 1',3.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(296,60,'CCS 106','Applications Development',5.00,'1.75','1.75','1.75','PASSED',0,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(297,60,'GEE 002','Living in the IT Era',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(298,60,'PATHFIT 4','Sports and Fitness',2.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(299,60,'PR 002','Quantitative Methods',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(300,60,'IS 106','IS Major Elective 1',3.00,'5.00','5.00','5.00','FAILED',1,0,1,0,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(325,62,'CCS 118','MULTIMEDIA SYSTEMS CORPUZ, KAMIL JADE A BSIS 3-A-SOUTH',3.00,'1.00','1.75','1.50','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(326,62,'GEE 003','GENDER AND SOCIETY STA. MARIA, MARIA LOURDES G BSIS 3-A-SOUTH',3.00,'1.50','1.00','1.25','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(327,62,'IS 102','ENTERPRISE RESOURCE PLANNING VARONA, MARCELO E. BSIS 3-A-SOUTH',3.00,'1.50','1.25','1.25','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(328,62,'IS 103','DATABASE SYSTEM ENTERPRISE LLENA, CATHERINE P BSIS 3-A-SOUTH',5.00,'1.75','INC','INC','INCOMPLETE',0,1,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(329,62,'IS 104','IS INNOVATIONS & NEW TECHNOLOGIES MACARAEG, TEODORO JR A BSIS 3-A-SOUTH',3.00,'1.75','1.75','1.75','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(330,62,'IS 105','ENTERPRISE ARCHITECTURE VARONA, MARCELO E. BSIS 3-A-SOUTH',3.00,'1.25','1.25','1.25','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(331,62,'IS 106','IS MAJOR ELECTIVE YU, EDUARDO II R. 3 BSIS 3-A-SOUTH',1.00,'2.00','5.00','5.00','FAILED',1,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(332,62,'RES 001','METHODS OF RESEARCH LLENA, CATHERINE P BSIS 3-A-SOUTH',3.00,'1.50','1.50','1.50','PASSED',0,0,0,0,'2026-10-06 20:50:02','2026-10-06 20:50:02'),
(341,63,'CCS 104','DATA STRUCTURES AND ALGORITHMS',3.00,'1.25','1.25','1.25','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(342,63,'CCS 105','INFORMATION MANAGEMENT',5.00,'1.25','1.75','1.50','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(343,63,'CCS 112','OPERATING SYSTEM & APPLICATION',3.00,'1.25','2.25','2.00','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(344,63,'CCS 125','SYSTEM ANALYSIS AND DESIGN',3.00,'1.50','1.25','1.25','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(345,63,'GEC 005','PURPOSIVE COMMUNICATION',3.00,'1.25','1.00','1.00','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(346,63,'GEC 007','SCIENCE, TECHNOLOGY & SOCIETY',3.00,'1.25','1.25','1.25','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(347,63,'IS 101','FINANCIAL MANAGEMENT',3.00,'2.00','1.75','1.75','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(348,63,'PATHFIT 3','DANCE AND FITNESS',2.00,'1.25','1.00','1.00','PASSED',0,0,0,0,'2026-10-09 05:13:08','2026-10-09 05:13:08'),
(356,64,'CCS 106','APPLICATIONS DEVELOPMENT AND EMERGING TECHNOLOGIES',5.00,'2.50','2.25','2.25','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(357,64,'CCS 110','COMPUTER GRAPHICS 1',3.00,'2.25','1.00','1.50','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(358,64,'CCS 116','WEB DEVELOPMENT 2',5.00,'1.25','1.25','1.25','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(359,64,'GEE 002','LIVING IN THE IT ERA',3.00,'1.50','1.00','1.25','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(360,64,'GEE 005','READING VISUAL ART',3.00,'1.00','1.00','1.00','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(361,64,'PATHFIT 4','SPORTS AND FITNESS',2.00,'1.00','1.00','1.00','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54'),
(362,64,'PR 002','QUANTITATIVE METHODS',3.00,'1.75','1.00','1.25','PASSED',0,0,0,0,'2026-10-22 03:57:54','2026-10-22 03:57:54');
/*!40000 ALTER TABLE `subject_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'student',
  `college_id` bigint(20) unsigned DEFAULT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `program_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `consented_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_college_id_foreign` (`college_id`),
  KEY `users_program_id_foreign` (`program_id`),
  KEY `users_role_index` (`role`),
  KEY `users_is_active_index` (`is_active`),
  KEY `users_department_id_foreign` (`department_id`),
  CONSTRAINT `users_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Ada Admin','admin@edupredict.test','2026-10-06 06:53:24','$2y$12$n5ikIY41ktJFjJ.18gSXUuyT5ongDFcAsw/dASnhqqfwFR8eA03O2','administrator',NULL,NULL,NULL,1,NULL,'2026-10-22 03:08:34',0,NULL,'2026-10-06 06:53:24','2026-10-22 03:08:34'),
(2,'Diego Dean','dean@edupredict.test','2026-10-06 06:53:25','$2y$12$o4pEeBByMR3ZIhb0B.war.MmWFNZWOHuZU8vSq4eeG8k9qls6U6aK','dean',5,NULL,NULL,1,NULL,'2026-10-20 14:46:36',0,NULL,'2026-10-06 06:53:25','2026-10-20 14:46:36'),
(3,'Hana Head','depthead@edupredict.test','2026-10-06 06:53:25','$2y$12$CRI5nuAtFJrWZI3vlibK6ORKKl7pVR.V2NsTtb5G2TmA/9BjL0KF2','department_head',5,3,3,1,NULL,'2026-10-20 14:47:17',0,NULL,'2026-10-06 06:53:25','2026-10-20 14:47:17'),
(4,'Faye Faculty','faculty@edupredict.test','2026-10-06 06:53:25','$2y$12$1Dzod8d5zlsWvJ6Kv7hA/.40v2ytT4/Jl.B5cFsvbEbYuOi0pQlQK','faculty',1,NULL,3,0,NULL,'2026-10-08 19:26:52',0,NULL,'2026-10-06 06:53:25','2026-10-10 18:01:51'),
(5,'Sam Student','student@edupredict.test','2026-10-06 06:53:26','$2y$12$MR0qv3Rh3Ds95lf7KxcFD.YAysPv2vP6XjatTiT84zCe7ou9//0ea','student',NULL,NULL,NULL,1,'2026-10-06 06:53:26','2026-10-22 02:54:13',0,NULL,'2026-10-06 06:53:26','2026-10-22 02:54:13'),
(6,'Omar Other (synthetic faculty)','faculty.other@edupredict.test','2026-10-06 06:53:27','$2y$12$5xQSNS1vH/gl..yzmWp.vOi7jou2hYO9eM9N82HaRgOJK0b5f.IUq','faculty',2,NULL,4,1,NULL,NULL,0,NULL,'2026-10-06 06:53:27','2026-10-06 06:53:27'),
(7,'Mara Bautista','synthetic1@edupredict.test','2026-10-06 06:53:27','$2y$12$y7u9WbmPHWFCNXgCsb6vz.Bey5y4w20AliKRCNgxX..ToYGh/3eqS','student',NULL,NULL,NULL,1,'2026-10-06 06:53:27','2026-10-19 15:49:03',0,NULL,'2026-10-06 06:53:27','2026-10-19 15:49:03'),
(8,'Nico Reyes','synthetic2@edupredict.test','2026-10-06 06:53:28','$2y$12$DD.ZDO.JyeGIgg2zz3KMfu/dqnlLJ/pYsyBSRVQ0odew/nY8RdqIu','student',NULL,NULL,NULL,1,'2026-10-06 06:53:28','2026-10-11 23:46:53',0,NULL,'2026-10-06 06:53:28','2026-10-11 23:46:53'),
(9,'Bea Navarro','synthetic3@edupredict.test','2026-10-06 06:53:28','$2y$12$fqpHpLtyVc1UhGMq/NrkGOPdPJz1nUPPOBytGWuQUo4WZTQmmM6/q','student',NULL,NULL,NULL,1,'2026-10-06 06:53:28','2026-10-22 02:55:42',0,NULL,'2026-10-06 06:53:28','2026-10-22 02:55:42'),
(10,'Carlo Lim','synthetic4@edupredict.test','2026-10-06 06:53:28','$2y$12$3WQri4mEJGT3ztxCYZNPcOe7JtefUtlxX7rCa9O6ELUAYdkwArpz6','student',NULL,NULL,NULL,0,'2026-10-06 06:53:28',NULL,0,NULL,'2026-10-06 06:53:28','2026-10-22 01:59:50'),
(11,'Rico Dela Cruz','synthetic5@edupredict.test','2026-10-06 06:53:29','$2y$12$SQO3bgb2w337Y7.ykd8fPesPat9OorcJO9yvGUD.HpPHsmlLDdb8G','student',NULL,NULL,NULL,1,'2026-10-06 06:53:29',NULL,0,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(12,'Paolo Cruz','synthetic6@edupredict.test','2026-10-06 06:53:29','$2y$12$Nyp0.2DSTYFDJTR9eddPweDFu1ZIFUz54MkkGi9uGVruZ16bO9sYG','student',NULL,NULL,NULL,1,'2026-10-06 06:53:29',NULL,0,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(13,'Synthetic7 Student','synthetic7@edupredict.test','2026-10-06 06:53:29','$2y$12$OxUKEMg74Aj9GxkGrCFId.OXODPhk/C8nBu715YdsD.ItCUdbjzNm','student',NULL,NULL,NULL,1,'2026-10-06 06:53:29',NULL,0,NULL,'2026-10-06 06:53:29','2026-10-06 06:53:29'),
(14,'Synthetic8 Student','synthetic8@edupredict.test','2026-10-06 06:53:30','$2y$12$SEH56U0WcXAR23gP/DrK0OI.lleRXVM81oZrjwYHd3LjGy7PpXS1.','student',NULL,NULL,NULL,1,'2026-10-06 06:53:30',NULL,0,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(15,'Synthetic9 Student','synthetic9@edupredict.test','2026-10-06 06:53:30','$2y$12$/rBkboi5VJXCmEPnYyyF1e3KnB.vPxTgsn38r9XpkbWORA.B9z5L6','student',NULL,NULL,NULL,1,'2026-10-06 06:53:30',NULL,0,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(16,'Liza Ramos','synthetic10@edupredict.test','2026-10-06 06:53:30','$2y$12$thuu0F3OZ7WtoHXf1bnkQOs3iib3RlkAaqvZn.1aoBxslR3hqp8TC','student',NULL,NULL,NULL,1,'2026-10-06 06:53:30',NULL,0,NULL,'2026-10-06 06:53:30','2026-10-06 06:53:30'),
(17,'Synthetic11 Student','synthetic11@edupredict.test','2026-10-06 06:53:31','$2y$12$tg8JWkVs4NK1R0xeOS3YS.Wzo16yaIWpa53xMPyomdCnJ.VG/SXgS','student',NULL,NULL,NULL,1,'2026-10-06 06:53:31',NULL,0,NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(18,'Synthetic12 Student','synthetic12@edupredict.test','2026-10-06 06:53:31','$2y$12$o3djKMhJ657tul5nTQYkIep1ucuMBKZGDpL/4Apg4PrfmS5s5C.vi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:31',NULL,0,NULL,'2026-10-06 06:53:31','2026-10-06 06:53:31'),
(19,'Synthetic13 Student','synthetic13@edupredict.test','2026-10-06 06:53:32','$2y$12$wwgodf7Fp0ixkf6g/y0JT.AOo6CdLFJoScHQFSUbBiE3gkyaQsyai','student',NULL,NULL,NULL,1,'2026-10-06 06:53:32',NULL,0,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(20,'Synthetic14 Student','synthetic14@edupredict.test','2026-10-06 06:53:32','$2y$12$EfgzAFzlKRYZJQ/7hpFCYuKdEp.7jg8.w1n5ul3ePaHS3ZkjkOIdq','student',NULL,NULL,NULL,1,'2026-10-06 06:53:32',NULL,0,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(21,'Synthetic15 Student','synthetic15@edupredict.test','2026-10-06 06:53:32','$2y$12$A59tBjTifkc07ug44eEume.8uBn2WDnef7JZfyCsfmJoZIUyTcgt.','student',NULL,NULL,NULL,1,'2026-10-06 06:53:32',NULL,0,NULL,'2026-10-06 06:53:32','2026-10-06 06:53:32'),
(22,'Synthetic16 Student','synthetic16@edupredict.test','2026-10-06 06:53:33','$2y$12$HrsK4D3f6eY0FkvPiBGuteVlNk6Hr.RwSuP4ojqnrWQkCvkWI96Fi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:33',NULL,0,NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(23,'Synthetic17 Student','synthetic17@edupredict.test','2026-10-06 06:53:33','$2y$12$pmon5XvtmrdKcA9LdDhITekE9vRXsMZYdoOZ5pngyfoqsr9.jYdSe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:33',NULL,0,NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(24,'Synthetic18 Student','synthetic18@edupredict.test','2026-10-06 06:53:33','$2y$12$dCPust5QAF8lKSguRacn/.WVW4T0uBKk3NA4aIfGjowNoMlYTmhNu','student',NULL,NULL,NULL,1,'2026-10-06 06:53:33',NULL,0,NULL,'2026-10-06 06:53:33','2026-10-06 06:53:33'),
(25,'Synthetic19 Student','synthetic19@edupredict.test','2026-10-06 06:53:34','$2y$12$xz2whzMDzuic08f5vgbokuP2dwf3FI6fJeUSBvEeo31bwY9A.0gnu','student',NULL,NULL,NULL,1,'2026-10-06 06:53:34',NULL,0,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(26,'Synthetic20 Student','synthetic20@edupredict.test','2026-10-06 06:53:34','$2y$12$HSJBGZeBv7VhmpMV.3c9geW9OU6SgzzEM5SB/aF0pibUcILDDTtBe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:34',NULL,0,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(27,'Synthetic21 Student','synthetic21@edupredict.test','2026-10-06 06:53:34','$2y$12$r3LDm8nzMvv6FPV4AWezMOeW2QJYeBoHq1.wDNsE4e5YOxsm1I/XO','student',NULL,NULL,NULL,1,'2026-10-06 06:53:34',NULL,0,NULL,'2026-10-06 06:53:34','2026-10-06 06:53:34'),
(28,'Synthetic22 Student','synthetic22@edupredict.test','2026-10-06 06:53:35','$2y$12$.RpeSjKX0WWVf3ZupHGFR.hBBv9LcJDF2iFtRZlp7xqxSFpxsCXE6','student',NULL,NULL,NULL,1,'2026-10-06 06:53:35',NULL,0,NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(29,'Synthetic23 Student','synthetic23@edupredict.test','2026-10-06 06:53:35','$2y$12$jAufSR/fL35uFSIQ920oQeR0H29dBlfa035nS/1d0i.QES4Al8Psu','student',NULL,NULL,NULL,1,'2026-10-06 06:53:35',NULL,0,NULL,'2026-10-06 06:53:35','2026-10-06 06:53:35'),
(30,'Synthetic24 Student','synthetic24@edupredict.test','2026-10-06 06:53:36','$2y$12$wrOD3Yi1tl1Ph7EuTkPMveEUiH6Sb9Y2GegVWFXNBMxN0g/6M6VNS','student',NULL,NULL,NULL,1,'2026-10-06 06:53:36',NULL,0,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(31,'Synthetic25 Student','synthetic25@edupredict.test','2026-10-06 06:53:36','$2y$12$LDTuFHaxQIRyDhmWI0Azc.K5xm3LU3VbZnvA3GpACik0wQUGyDQFi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:36',NULL,0,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(32,'Synthetic26 Student','synthetic26@edupredict.test','2026-10-06 06:53:36','$2y$12$zvgodk1fPoY5QfNnwHu02eRKGmk6mrmhGjS3g.CYWKBlLYJ/AtJai','student',NULL,NULL,NULL,1,'2026-10-06 06:53:36',NULL,0,NULL,'2026-10-06 06:53:36','2026-10-06 06:53:36'),
(33,'Synthetic27 Student','synthetic27@edupredict.test','2026-10-06 06:53:37','$2y$12$afQI66ltU3CNHL.dYJLLM.tcZGhv6a4yCE0ifRgQQy4oPpWja8hDG','student',NULL,NULL,NULL,1,'2026-10-06 06:53:37',NULL,0,NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(34,'Synthetic28 Student','synthetic28@edupredict.test','2026-10-06 06:53:37','$2y$12$3tgH51ciS5axLbg80rYfl.2kseJ0U0O/Vv8k4XQmEr1uEsvDa4nnS','student',NULL,NULL,NULL,1,'2026-10-06 06:53:37',NULL,0,NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(35,'Synthetic29 Student','synthetic29@edupredict.test','2026-10-06 06:53:37','$2y$12$CBeRWs6wo/ekyGZC/p72/OwrCJQ4o/2sbc/d7UmJWIOnIWqUgYQdG','student',NULL,NULL,NULL,1,'2026-10-06 06:53:37',NULL,0,NULL,'2026-10-06 06:53:37','2026-10-06 06:53:37'),
(36,'Synthetic30 Student','synthetic30@edupredict.test','2026-10-06 06:53:38','$2y$12$Bhl9PDBOBhFKnnNtppVqwOxjojlGaxFpUI0gpL.8OhdSeOLZ.UNzy','student',NULL,NULL,NULL,1,'2026-10-06 06:53:38',NULL,0,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(37,'Synthetic31 Student','synthetic31@edupredict.test','2026-10-06 06:53:38','$2y$12$EdlErWTOZoD/kjncgPYNMuBi9n6QIAr0bJSYCfgDexsB/DQevqPSa','student',NULL,NULL,NULL,1,'2026-10-06 06:53:38',NULL,0,NULL,'2026-10-06 06:53:38','2026-10-06 06:53:38'),
(38,'Synthetic32 Student','synthetic32@edupredict.test','2026-10-06 06:53:39','$2y$12$tLLJxn5WkRcBCZvsVKldCuVrgHyEqepnASZl5Fomlgm0I/XXyFTtW','student',NULL,NULL,NULL,1,'2026-10-06 06:53:39',NULL,0,NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(39,'Synthetic33 Student','synthetic33@edupredict.test','2026-10-06 06:53:39','$2y$12$.6jaILKi2Zdtof5Zc7zgCOGtCEHA1yQ056holNFM6.Ay73fljl3oe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:39',NULL,0,NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(40,'Synthetic34 Student','synthetic34@edupredict.test','2026-10-06 06:53:39','$2y$12$58wD5p/Z2BJjcodgtmDgDeLiFXzoAf7eaAf6jkyjvxVN//v2PaHZi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:39',NULL,0,NULL,'2026-10-06 06:53:39','2026-10-06 06:53:39'),
(41,'Synthetic35 Student','synthetic35@edupredict.test','2026-10-06 06:53:40','$2y$12$Kj0BR6U9N3PhciCShIzP4eEjfGYOZt9QGrGouG9XemKSCX3SQIPlm','student',NULL,NULL,NULL,1,'2026-10-06 06:53:40',NULL,0,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(42,'Synthetic36 Student','synthetic36@edupredict.test','2026-10-06 06:53:40','$2y$12$tF2OcnyB29fFvmA2VBpvaueIOKKkYyJIXnG7yKD6nePdnxRlbeFFq','student',NULL,NULL,NULL,1,'2026-10-06 06:53:40',NULL,0,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(43,'Synthetic37 Student','synthetic37@edupredict.test','2026-10-06 06:53:40','$2y$12$iyrOTUrwWp1EmhpNfq972eJi3FRO2afEpeEyxg.ibCHCaum2EGCSG','student',NULL,NULL,NULL,1,'2026-10-06 06:53:40',NULL,0,NULL,'2026-10-06 06:53:40','2026-10-06 06:53:40'),
(44,'Synthetic38 Student','synthetic38@edupredict.test','2026-10-06 06:53:41','$2y$12$Hul2XDmuo8kpXAVEJZKmiOxchMfkPv0Nu6Z8ValL/CQ6ucQDlTfOC','student',NULL,NULL,NULL,1,'2026-10-06 06:53:41',NULL,0,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(45,'Synthetic39 Student','synthetic39@edupredict.test','2026-10-06 06:53:41','$2y$12$bkvUR9Ok1mZJH87yDUvO4ODJnTHCwamo6Kd5S/JlVrFFWxQgebho.','student',NULL,NULL,NULL,1,'2026-10-06 06:53:41',NULL,0,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(46,'Synthetic40 Student','synthetic40@edupredict.test','2026-10-06 06:53:41','$2y$12$N7nEIkZlU2lSuZMBYROaOO6gwU6bI33Pkg//9j4iawbvNqzWfqa6S','student',NULL,NULL,NULL,1,'2026-10-06 06:53:41',NULL,0,NULL,'2026-10-06 06:53:41','2026-10-06 06:53:41'),
(47,'Synthetic41 Student','synthetic41@edupredict.test','2026-10-06 06:53:42','$2y$12$xxUW48ow0Z/smdYDK8/A5.vTX9NCPtxfFlGHJKX.eJjW3rqRDs5oG','student',NULL,NULL,NULL,1,'2026-10-06 06:53:42',NULL,0,NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(48,'Synthetic42 Student','synthetic42@edupredict.test','2026-10-06 06:53:42','$2y$12$YRKE990HYMWBWkFAp/zZ/eM8Ct8wyG/Gjt5M30PVtFq0qJgiSkQya','student',NULL,NULL,NULL,1,'2026-10-06 06:53:42',NULL,0,NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(49,'Synthetic43 Student','synthetic43@edupredict.test','2026-10-06 06:53:42','$2y$12$7AL0Q20pq1hFb1yZTOXxX.cXOw50wedTKs4ewkCzsfpX37TfD9Ubu','student',NULL,NULL,NULL,1,'2026-10-06 06:53:42',NULL,0,NULL,'2026-10-06 06:53:42','2026-10-06 06:53:42'),
(50,'Synthetic44 Student','synthetic44@edupredict.test','2026-10-06 06:53:43','$2y$12$WjIyBkAqNc9WotMxOrYHBuRoAXTt1FTlonrM6SeuszB53AbFOlAo2','student',NULL,NULL,NULL,1,'2026-10-06 06:53:43',NULL,0,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(51,'Synthetic45 Student','synthetic45@edupredict.test','2026-10-06 06:53:43','$2y$12$SfSpZ5/xX6mlEmyfrpzMueui0XlaPoApKAJv9a0OxKfqQwSVL3pqi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:43',NULL,0,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(52,'Synthetic46 Student','synthetic46@edupredict.test','2026-10-06 06:53:43','$2y$12$zBigjEKrhwjgUH7ttvUM2eo9jwCqqef0/CVofOEkrKFGncjpAmlrq','student',NULL,NULL,NULL,1,'2026-10-06 06:53:43',NULL,0,NULL,'2026-10-06 06:53:43','2026-10-06 06:53:43'),
(53,'Synthetic47 Student','synthetic47@edupredict.test','2026-10-06 06:53:44','$2y$12$XxNYnvAZEJ8vat6ZWQGtdOQjVirf3Ncr6VIzmqqzhBB4Ko405MjE.','student',NULL,NULL,NULL,1,'2026-10-06 06:53:44',NULL,0,NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(54,'Synthetic48 Student','synthetic48@edupredict.test','2026-10-06 06:53:44','$2y$12$1ynwToLzwZIpe5B0A.Qyme71/Au9hk20e30Lh76HfjuIj05BjRaOK','student',NULL,NULL,NULL,1,'2026-10-06 06:53:44',NULL,0,NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(55,'Synthetic49 Student','synthetic49@edupredict.test','2026-10-06 06:53:44','$2y$12$DyhB7cTBRqJRT6WS4i9OzOYcrfQ6LnEFFfdfW36z/Uv.GZhDWVMKe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:44',NULL,0,NULL,'2026-10-06 06:53:44','2026-10-06 06:53:44'),
(56,'Synthetic50 Student','synthetic50@edupredict.test','2026-10-06 06:53:45','$2y$12$DH2HVPlpONHAmb2/vZ1x4Ox2QQntbza0OFkugaGnfFJPPfBzOl33S','student',NULL,NULL,NULL,1,'2026-10-06 06:53:45',NULL,0,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(57,'Synthetic51 Student','synthetic51@edupredict.test','2026-10-06 06:53:45','$2y$12$WEn/YpyFHBPTGtbtf9b18uFTfnARqN0Wnpzp8vaPT/UQocARAy5rW','student',NULL,NULL,NULL,1,'2026-10-06 06:53:45',NULL,0,NULL,'2026-10-06 06:53:45','2026-10-06 06:53:45'),
(58,'Synthetic52 Student','synthetic52@edupredict.test','2026-10-06 06:53:46','$2y$12$EiL5nIz6zLEJWBf9KCI0IezuO2rt/NAPQy8O//yTMGXQjphkU54t6','student',NULL,NULL,NULL,1,'2026-10-06 06:53:46',NULL,0,NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(59,'Synthetic53 Student','synthetic53@edupredict.test','2026-10-06 06:53:46','$2y$12$O0y94jIw2XFlvYTuO5hJAe87x1P8apRmO78ylZ7Dicc24ZscZ41Pe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:46',NULL,0,NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(60,'Synthetic54 Student','synthetic54@edupredict.test','2026-10-06 06:53:46','$2y$12$X5O1iRV8uMqpo7DIcgyVFulhQ2ekyBiBUc.R0WkhM0Fymm8MOfJNe','student',NULL,NULL,NULL,1,'2026-10-06 06:53:46',NULL,0,NULL,'2026-10-06 06:53:46','2026-10-06 06:53:46'),
(61,'Synthetic55 Student','synthetic55@edupredict.test','2026-10-06 06:53:47','$2y$12$MVCHiLiClW.vLSNmi.VhueGmJi.Ufhou7nFX3wkaFe9QpXXXDi2D2','student',NULL,NULL,NULL,1,'2026-10-06 06:53:47',NULL,0,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(62,'Synthetic56 Student','synthetic56@edupredict.test','2026-10-06 06:53:47','$2y$12$KYaGEKxd2dQmtDIrTMk7K.6vpcQZUXoRjngAaVv7LxF29kIEfYHdW','student',NULL,NULL,NULL,1,'2026-10-06 06:53:47',NULL,0,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(63,'Synthetic57 Student','synthetic57@edupredict.test','2026-10-06 06:53:47','$2y$12$CReDWzfug66qhzULEz0k/ezXyxKE7LGCweLZxaTEfd6lVpLBoeU.u','student',NULL,NULL,NULL,1,'2026-10-06 06:53:47',NULL,0,NULL,'2026-10-06 06:53:47','2026-10-06 06:53:47'),
(64,'Synthetic58 Student','synthetic58@edupredict.test','2026-10-06 06:53:48','$2y$12$dA/ol/fbZBbERAjSNNj8CeJUv8Ylgf9BGnYJ8BpF//p7XH3HYnTY6','student',NULL,NULL,NULL,1,'2026-10-06 06:53:48',NULL,0,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(65,'Synthetic59 Student','synthetic59@edupredict.test','2026-10-06 06:53:48','$2y$12$LW2aXiGjaHRCq2GoYZi8Ne3RndwtwV.iFrzzM34qTMh6ksN6eaSmi','student',NULL,NULL,NULL,1,'2026-10-06 06:53:48',NULL,0,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(66,'Synthetic60 Student','synthetic60@edupredict.test','2026-10-06 06:53:48','$2y$12$9bTT4/XyDZ3wiNf.iGH7..Nfng7sgZ1RuCNBG8VP1pYkqHjuZkjMK','student',NULL,NULL,NULL,1,'2026-10-06 06:53:48',NULL,0,NULL,'2026-10-06 06:53:48','2026-10-06 06:53:48'),
(67,'kitkatz','keithandrea258@gmail.com',NULL,'$2y$12$QN9fa6FoMF3oD4agqzvjBuR.7YpWmAQcDqF9fGySFs.md9shUd/nm','department_head',5,3,NULL,1,NULL,NULL,1,NULL,'2026-10-10 17:30:58','2026-10-10 17:31:58'),
(68,'Xyra','xyra123@gmail.com',NULL,'$2y$12$3xKmaPbQdkt7a5Uht.c16e6wAtrtVHq31LbE/sC4hdo5zM0lPKrPO','dean',5,NULL,NULL,1,NULL,NULL,1,NULL,'2026-10-10 17:32:30','2026-10-10 17:32:30'),
(69,'Keith Andrea Calma','kitandreacalma@gmail.com',NULL,'$2y$12$SmKnV1Q0.Bye0.o1RMjE9uIVKoKIF4fJVVv0Cglr9yDw.ddewmnnm','student',NULL,NULL,NULL,1,'2026-10-22 02:23:30','2026-10-22 03:15:42',0,NULL,'2026-10-22 02:23:31','2026-10-22 03:15:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'edupredict'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-21 20:14:33
